<?php $__env->startSection('title','Approvisionnement'); ?>
<?php $__env->startSection('content'); ?>


<div class="container px-6 mx-auto grid">

        <h2 class="my-6 text-2xl font-semibold text-gray-700 dark:text-gray-200">

        </h2>
        <h2 class="text-3xl font-semibold text-green-800 border-b-4 border-green-700 pb-3 mb-6">

            LISTE APPROVISIONNEMENT

        </h2>
        <!-- CTA -->
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('approvisionnement.create')): ?>
            <a href="<?php echo e(Route('approvisionnements.create')); ?>"
                class="flex items-center justify-between p-4 mb-8 text-sm font-semibold text-white bg-green-600 rounded-lg shadow-md focus:outline-none focus:shadow-outline-green"
                >

                Ajouter

            </a>
        <?php endif; ?>
        <!-- Cards -->
        <!-- New Table -->
        <div class="w-full overflow-hidden rounded-lg shadow-xs" style="background-color: #ffffff;">

                    <!-- New Table -->


                    <div class="w-full overflow-hidden rounded-lg shadow-xs" style="background-color: #ffffff;">
        <div class="w-full overflow-x-auto">
        <div class="w-full overflow-hidden rounded-lg shadow-xs bg-white">

            <div class="w-full overflow-x-auto">
                <div class="w-full overflow-hidden rounded-lg shadow-xs bg-white">
                    <div class="w-full overflow-x-auto">
                        <table class="w-full whitespace-no-wrap bg-white">
                            <thead>
                                <tr
                                    class="text-sm font-bold tracking-wide text-left text-green-600 uppercase border-b border-gray-200 bg-white">
                                    <th class="px-4 py-3">Date</th>
                                    <th class="px-4 py-3">fournisseur</th>
                                    <th class="px-4 py-3">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $approvs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $approv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr class="text-gray-700 dark:text-gray-400">
                                        <td class="px-4 py-3">
                                            <?php echo e($approv->date); ?>

                                        </td>
                                        <td class="px-4 py-3 text-sm">
                                            <?php echo e($approv->fournisseur->nom); ?>

                                        </td>
                                        <td class="px-4 py-3 text-sm">
                                            <div style="display: flex; gap: 10px;">
                                                
                                                <!-- Bouton Supprimer -->
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('approvisionnement.delete')): ?>
                                                    <form action="<?php echo e(route('approvisionnements.destroy', $approv)); ?>"
                                                        method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('delete'); ?>
                                                        <button
                                                            class="px-3 py-1 rounded-md focus:outline-none focus:shadow-outline-purple"
                                                            style="background-color: red; color: white;"
                                                            onclick="confirmDelete(event, this.form) ">
                                                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                                                <path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
                                                              </svg>

                                                        </button>


                                                    </form>


                                                <?php endif; ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('approvisionnement.view')): ?>
                                                <a href="<?php echo e(route('approvisionnements.show', $approv)); ?>"
                                                class="px-3 py-1 rounded-md focus:outline-none focus:shadow-outline-purple"
                                                style="background-color: rgb(66, 97, 8); color: white;"
                                                title="Voir plus"
                                                >
                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                                  </svg>

                                                </a>
                                                <?php endif; ?>

                                            </div>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="4" class="px-4 py-3 text-center text-gray-500">pas de categorie</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>

                        </table>

                    <div>
                        <?php echo e($approvs->links()); ?>

                    </div>


                    <script src="<?php echo e(asset('assets/js/sweetalert2.min.js')); ?>"></script>

                    <script>
                        function confirmcreate(event) {
                            event.preventDefault();
                            Swal.fire({
                                title: 'Êtes-vous sûr ?',
                                text: "Voulez vous Créer !",
                                icon: 'warning',
                                showCancelButton: true,
                                confirmButtonColor: '#3085d6',
                                cancelButtonColor: '#d33',
                                confirmButtonText: 'Oui, créer !',
                                cancelButtonText: 'Non '
                            }).then((result) => {
                                if (result.isConfirmed) {

                                    window.location.href = event.target.href;
                                }
                            });
                        }

                        function confirmmisee(event) {
                            event.preventDefault();
                            Swal.fire({
                                title: 'Êtes-vous sûr ?',
                                text: "Voulez vous mettre à jour  !",
                                icon: 'warning',
                                showCancelButton: true,
                                confirmButtonColor: '#3085d6',
                                cancelButtonColor: '#d33',
                                confirmButtonText: 'Oui, mettre à jour !',
                                cancelButtonText: 'Non '
                            }).then((result) => {
                                if (result.isConfirmed) {

                                    window.location.href = event.target.href;
                                }
                            });
                        }

                        function confirmDelete(event, form) {
                            event.preventDefault();
                            Swal.fire({
                                title: 'Êtes-vous sûr ?',
                                text: "Vous ne pourrez pas annuler cette action !",
                                icon: 'warning',
                                showCancelButton: true,
                                confirmButtonColor: '#3085d6',
                                cancelButtonColor: '#d33',
                                confirmButtonText: 'Oui, supprimer !',
                                cancelButtonText: 'Annuler'
                            }).then((result) => {
                                if (result.isConfirmed) {
                                    Swal.fire({
                                        title: 'Supprimé!',
                                        text: 'La ligne a été supprimée.',
                                        icon: 'success'
                                    }).then((result) => {
                                            if (result.isConfirmed) {
                                                form.submit();
                                            }

                                    });
                                }
                            });
                        }
                    </script>
                <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rachad/CMS/pharmacie/resources/views/approvisionnements/index.blade.php ENDPATH**/ ?>