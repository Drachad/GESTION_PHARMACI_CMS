<?php echo app('Illuminate\Foundation\Vite')('resources/js/id.js'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mx-auto px-6 py-4 bg-white rounded-lg shadow-md">
        <!-- Bouton Retour sous forme de croix -->
        <a href="<?php echo e(route('approvisionnements.index')); ?>" class="text-red-600 text-3xl font-bold cursor-pointer">&times;</a>

        <h2 class="text-3xl font-semibold text-green-800 border-b-4 border-green-700 pb-3 mb-6">
            Modifier l'approvisionnement
        </h2>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger bg-red-100 border border-red-300 text-red-700 rounded-lg p-4 mb-4">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('approvisionnements.update', $approvisionnement->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <!-- Champs principaux -->
            <div class="form-group mb-6">
                <label for="fournisseur_id" class="font-bold text-green-800 text-lg">Fournisseur</label>
                <div class="flex space-x-4">
                    <input list="produits" name="produit_nom" id="produit-input" value="<?php echo e(old('produit_nom', $approvisionnement->fournisseur->nom)); ?>" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 transition duration-200 ease-in-out text-base shadow-sm" placeholder="Rechercher un fournisseur...">
                    
                    <!-- Datalist pour les options -->
                    <datalist id="produits">
                        <?php $__currentLoopData = $fournisseurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fournisseur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($fournisseur->nom); ?>" data-id="<?php echo e($fournisseur->id); ?>"></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </datalist>

                    <!-- Champ caché pour stocker l'ID du fournisseur sélectionné -->
                    <input type="hidden" name="hidden_id" id="produit-id" value="<?php echo e(old('produit_id', $approvisionnement->fournisseur_id)); ?>">
                    <a href="<?php echo e(route('fournisseurs.create')); ?>" class="text-white bg-blue-500 hover:bg-blue-600 font-bold py-4 px-6 rounded-lg transition duration-300 ease-in-out text-center shadow-sm">+</a>
                </div>
                
                <p class="text-sm text-gray-500 mt-2">
                    Pas de fournisseur correspondant ? <a href="<?php echo e(route('fournisseurs.create')); ?>" class="text-green-500 hover:text-green-700 font-medium transition duration-300 ease-in-out">Créer un nouveau fournisseur</a>.
                </p>
            </div>

            <hr class="border-gray-300 mb-6">

            <!-- Tableau des lignes d'approvisionnement -->
            <h4 class="text-xl font-semibold mb-4 text-green-700">Lignes d'approvisionnement</h4>

            <table class="w-full border-collapse bg-gray-100 rounded-lg overflow-hidden">
                <thead>
                    <tr class="bg-green-600 text-white text-sm uppercase">
                        <th class="px-4 py-3">Produit</th>
                        <th class="px-4 py-3">Prix</th>
                        <th class="px-4 py-3">Quantité</th>
                        <th class="px-4 py-3">Date de péremption</th>
                        <th class="px-4 py-3">Actions</th>
                    </tr>
                </thead>
                <tbody id="ligne-approvisionnement-table">
                    <?php $__currentLoopData = $approvisionnement->lignes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $ligne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="ligne-approvisionnement" data-index="<?php echo e($index); ?>">
                            <td class="px-4 py-2">
                                <select name="refs_id[]" class="form-control border-green-300 rounded-lg p-2 w-full">
                                    <option value="">Sélectionner un produit</option>
                                    <?php $__currentLoopData = $references; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reference): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($reference->id); ?>" <?php echo e(old('refs_id.'.$index, $ligne->ligneProduit->reference_id) == $reference->id ? 'selected' : ''); ?>>
                                            <?php echo e($reference->nom_complet); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                            <td class="px-4 py-2">
                                <input type="number" name="prixs[]" class="form-control border-green-300 rounded-lg p-2 w-full" value="<?php echo e(old('prixs.'.$index, $ligne->ligneProduit->prix)); ?>">
                            </td>
                            <td class="px-4 py-2">
                                <input type="number" name="quantite[]" class="form-control border-green-300 rounded-lg p-2 w-full" value="<?php echo e(old('quantite.'.$index, $ligne->ligneProduit->quantite)); ?>">
                            </td>
                            <td class="px-4 py-2">
                                <input type="date" name="date_peremption[]" class="form-control border-green-300 rounded-lg p-2 w-full" value="<?php echo e(old('date_peremption.'.$index, $ligne->ligneProduit->date_peremption)); ?>">
                            </td>
                            <td class="px-4 py-2">
                                <button type="button" class="btn btn-danger bg-red-600 text-white rounded-lg px-4 py-2 hover:bg-red-700">Supprimer</button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <button type="button" id="add-ligne" class="btn btn-secondary bg-gray-600 text-white rounded-lg px-4 py-2 mt-4 hover:bg-gray-700">Ajouter une ligne</button>

            <button type="submit" class="btn bg-green-600 text-white rounded-lg px-4 py-2 mt-4 hover:bg-green-700">Mettre à jour</button>
        </form>
    </div>

    <script>
        let ligneIndex = <?php echo e($approvisionnement->lignes->count()); ?>;

        document.getElementById('add-ligne').addEventListener('click', function() {
            let table = document.getElementById('ligne-approvisionnement-table');
            let newRow = table.insertRow();
            newRow.classList.add('ligne-approvisionnement');
            newRow.setAttribute('data-index', ligneIndex);

            newRow.innerHTML = `
                <td class="px-4 py-2">
                    <select name="refs_id[]" class="form-control border-green-300 rounded-lg p-2 w-full">
                        <option value="">Sélectionner un produit</option>
                        <?php $__currentLoopData = $references; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reference): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($reference->id); ?>"><?php echo e($reference->nom_complet); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </td>
                <td class="px-4 py-2">
                    <input type="number" name="prixs[]" class="form-control border-green-300 rounded-lg p-2 w-full">
                </td>
                <td class="px-4 py-2">
                    <input type="number" name="quantite[]" class="form-control border-green-300 rounded-lg p-2 w-full">
                </td>
                <td class="px-4 py-2">
                    <input type="date" name="date_peremption[]" class="form-control border-green-300 rounded-lg p-2 w-full">
                </td>
                <td class="px-4 py-2">
                    <button type="button" class="btn btn-danger bg-red-600 text-white rounded-lg px-4 py-2 hover:bg-red-700">Supprimer</button>
                </td>
            `;

            ligneIndex++;
        });

        document.addEventListener('click', function(e) {
            if (e.target && e.target.classList.contains('remove-ligne')) {
                let row = e.target.closest('tr');
                row.remove();
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rachad/CMS/pharmacie/resources/views/approvisionnements/edit.blade.php ENDPATH**/ ?>