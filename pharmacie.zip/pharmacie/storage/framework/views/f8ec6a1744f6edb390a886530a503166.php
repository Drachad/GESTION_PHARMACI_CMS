<?php $__env->startSection('title', 'les statistiques '); ?>

<?php $__env->startSection('content'); ?>

    <main class="h-full overflow-y-auto">
        <div class="container px-6 mx-auto grid">
            <h2 class="my-6 text-2xl font-semibold text-gray-700 dark:text-gray-200">
                Dashboard
            </h2>
            <!-- CTA -->
            <a class="flex items-center justify-between p-4 mb-8 text-sm font-semibold text-purple-100 bg-purple-600 rounded-lg shadow-md focus:outline-none focus:shadow-outline-purple"
                href="#">
                <div class="flex items-center">
                    <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                        <path
                            d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z">
                        </path>
                    </svg>
                    <span>STATISTIQUES DE LA PHARMACIE </span>
                </div>
                <span>View more &RightArrow;</span>
            </a>
            <!-- Cards -->

            <div class="container mx-auto px-4 py-8">
                <h1 class="text-2xl font-bold mb-4">Inventaire côté <?php echo e($typeInventaire); ?> </h1>


                <!-- Graphique -->
                <div class="mb-8">
                    <canvas id="inventoryChart"></canvas>
                </div>

                <!-- Table des résultats -->
                <table class="min-w-full divide-y divide-gray-200">
                    <thead>
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Produit</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Référence</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Prix
                            </th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Quantité</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php $__currentLoopData = $resultats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap"><?php echo e($item->produit->nom ?? 'Non disponible'); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap"><?php echo e($item->reference_id); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap"><?php echo e($item->prix); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap"><?php echo e($item->quantite ?? 'Non disponible'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                <!-- Pagination -->
                <div class="mt-4">
                    <?php echo e($resultats->links()); ?>

                </div>
            </div>

            <script src="<?php echo e(asset('assets/js/chart.js')); ?>"></script>

            <script>
                // Configuration du graphique en barre
                const ctx = document.getElementById('inventoryChart').getContext('2d');

                // Initialiser le graphique en barre
                new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: <?php echo json_encode($chartData['labels'], 15, 512) ?>, // Labels des produits
                        datasets: [{
                            label: '<?php echo e(ucfirst($typeInventaire)); ?>', // Étiquette du type d'inventaire
                            data: <?php echo json_encode($chartData['datasets'][0]['data'], 15, 512) ?>, // Données correspondantes
                            backgroundColor: 'rgba(54, 162, 235, 0.5)',
                            borderColor: 'rgba(54, 162, 235, 1)',
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        scales: {
                            y: {
                                beginAtZero: true
                            }
                        },
                        plugins: {
                            legend: {
                                display: true,
                                position: 'top'
                            }
                        }
                    }
                });
            </script>






    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rachad/CMS/pharmacie/resources/views/layouts/components/contenu.blade.php ENDPATH**/ ?>