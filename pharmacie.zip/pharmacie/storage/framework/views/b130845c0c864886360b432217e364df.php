<?php $__env->startSection('title', 'Modification Référence'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex justify-center items-center min-h-screen bg-gray-100">
    <div class="form-container bg-white rounded-lg shadow-lg p-8 max-w-lg w-full relative">
        <!-- Bouton Retour sous forme de croix -->
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('reference.view')): ?>
        <a href="<?php echo e(route('references.index')); ?>" class="close-button text-red-500 hover:text-red-700 text-2xl absolute top-3 right-3 transition duration-200 ease-in-out" onclick="confirmUpdate(event)">&times;</a>
        <?php endif; ?>

        <h2 class="text-3xl font-bold text-green-600 mb-6 text-center">Modifier la Référence</h2>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger bg-red-100 border border-red-300 text-red-700 rounded-lg p-4 mb-4">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('reference.edit')): ?>
        <form id="referenceupdate" action="<?php echo e(route('references.update', $reference->id)); ?>" method="POST" class="space-y-5">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <input type="hidden" name="redirect_to" value="<?php echo e(url()->previous()); ?>">

            <div class="form-group">
                <label for="nom" class="block text-gray-700 font-semibold mb-1">Nom</label>
                <input type="text" id="nom" name="nom" value="<?php echo e(old('nom', $reference->nom)); ?>" placeholder="Nom de la référence" required class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 transition duration-200 ease-in-out text-base shadow-sm">
            </div>

            <div class="form-group">
                <label for="produit" class="block text-gray-700 font-semibold mb-1">Produit</label>
                <div class="flex space-x-4">
                    <select id="produit_id" name="produit_id" class="form-control border-green-300 rounded-lg p-2 w-full">
                        <option value="">Sélectionner un produit</option>
                        <?php $__currentLoopData = $produits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($produit->id); ?>" <?php echo e((old('produit_id') ?? $reference->produit_id) == $produit->id ? 'selected' : ''); ?>>
                                <?php echo e($produit->nom); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('produits.create')): ?>
                    <a href="<?php echo e(route('produits.create')); ?>" class="text-white bg-blue-500 hover:bg-blue-600 font-bold py-2 px-4 rounded-lg transition duration-300 ease-in-out text-center shadow-sm" onclick="confirmcreate(event)">+</a>
                    <?php endif; ?>
                </div>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('produits.create')): ?>
                <p class="text-sm text-gray-500 mt-2">
                    Pas de produit correspondant ? <a href="<?php echo e(route('produits.create')); ?>" class="text-green-500 hover:text-green-700 font-medium transition duration-300 ease-in-out" onclick="confirmcreate(event)">Créer un nouveau produit</a>.
                </p>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label for="quantite_seuil" class="block text-gray-700 font-semibold mb-1">Quantité Seuil</label>
                <input type="number" id="quantite_seuil" name="quantite_seuil" value="<?php echo e(old('quantite_seuil', $reference->alerte->quantite_seuil)); ?>" placeholder="Quantité seuil" required min="0" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 transition duration-200 ease-in-out text-base shadow-sm">
            </div>

            <button type="button" id="submitButton" class="w-full bg-green-500 text-white font-semibold py-3 rounded-lg hover:bg-green-600 transition duration-200 ease-in-out text-base">
                Modifier Référence
            </button>
        </form>
        <?php endif; ?>
    </div>
</div>

<script src="<?php echo e(asset('assets/js/sweetalert2.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
        $('#produit_id').select2({
            placeholder: "Sélectionnez un produit",
            allowClear: true,
            width: '100%',
            minimumResultsForSearch: 0,
            language: {
                noResults: function() {
                    // Retourner le lien HTML pour la création d'un nouvel article
                    return $('<span>').append(
                        $('<a>', {
                            href: '<?php echo e(route('produits.create')); ?>',
                            text: 'produit n\'est pas trouvé créer un nouveau',
                            class: 'text-blue-500 hover:underline',
                            target: '_blank'
                        })
                    );
                }
            }
        });
    });
</script>
<script>
    document.getElementById('submitButton').addEventListener('click', function(event) {
        event.preventDefault();
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Vous allez enregistrer cette référence !",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, enregistrer !',
            cancelButtonText: 'Annuler'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('referenceupdate').submit();
            }
        });
    });

    function confirmUpdate(event) {
        event.preventDefault();
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Voulez-vous Annuler !",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, Annuler !',
            cancelButtonText: 'Non '
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = event.target.href;
            }
        });
    }

    function confirmcreate(event) {
        event.preventDefault();
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Voulez-vous Créer !",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, créer !',
            cancelButtonText: 'Non '
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = event.target.href;
            }
        });
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rachad/CMS/pharmacie/resources/views/references/edit.blade.php ENDPATH**/ ?>