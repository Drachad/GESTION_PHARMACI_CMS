<?php $__env->startSection('title','Modifier profile '); ?>
<?php $__env->startSection('content'); ?>


    <div class="background-image"></div>

    <div class="form-container mx-5" class="bg-gray-100 dark:bg-gray-100 relative min-h-screen flex items-center justify-center"
    >
        <!-- Bouton de fermeture -->
        <button class="close-button" onclick="window.location.href='<?php echo e(route('profile.action')); ?>';">&times;</button>


        <header class="mb-8 text-center">
            <h2 class="text-3xl font-semibold text-gray-900 dark:text-white">
                Informations du Profil
            </h2>
            <p class="text-gray-700 dark:text-gray-400">
                Mettez à jour les informations de profil et l'adresse email de votre compte.
            </p>

        </header>

        <form id="send-verification" method="post" action="<?php echo e(route('verification.send')); ?>">
            <?php echo csrf_field(); ?>
        </form>

        <form id="update-profile-form" method="post" action="<?php echo e(route('profile.update')); ?>"  enctype="multipart/form-data" class="space-y-6">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <div class="flex items-center justify-start mt-6">
                <button
                    type="submit"
                    class="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-1 px-3 rounded-lg transition duration-200 text-xs"
                >
                    Enregistrer
                </button>
            </div>

            <div>
                <label for="name" class="block text-sm font-medium text-gray-700 dark:text-gray-100">
                    Nom
                </label>
                <input
                    id="name"
                    name="name"
                    type="text"
                    class="mt-2 block w-full px-1 py-1 border border-gray-100 dark:border-gray-100 rounded-lg shadow-sm dark:bg-gray-700 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-300"
                    value="<?php echo e(old('name', $user->name)); ?>"
                    required
                    autofocus
                    autocomplete="name"
                    placeholder="Entrez votre nom"
                />
                <span id="name-error" class="text-red-500 text-sm mt-2 hidden"></span>
            </div>
            <!-- Image de Profil -->
            

            <div class="mt-4">
                <label for="email" class="block text-sm font-medium text-gray-700 dark:text-gray-300">
                    Email
                </label>
                <input
                    id="email"
                    name="email"
                    type="email"
                    class="mt-2 block w-full px-2 py-1 border border-gray-100 dark:border-gray-100 rounded-lg shadow-sm dark:bg-gray-700 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-300"
                    value="<?php echo e(old('email', $user->email)); ?>"
                    required
                    autocomplete="username"
                    placeholder="Entrez votre adresse email"
                />
                <span id="email-error" class="text-red-500 text-sm mt-2 hidden"></span>

                <div id="verification-message" class="text-sm mt-4 text-gray-800 dark:text-gray-200 hidden">
                    Votre adresse email n'est pas vérifiée.
                    <button
                        onclick="document.getElementById('send-verification').submit();"
                        class="underline text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-200 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800"
                    >
                        Cliquez ici pour renvoyer l'email de vérification.
                    </button>
                </div>
                <p id="verification-link-sent" class="mt-2 font-medium text-sm text-green-600 dark:text-green-400 hidden">
                    Un nouveau lien de vérification a été envoyé à votre adresse email.
                </p>
            </div>

            <p
                id="status-message"
                class="text-sm text-green-600 dark:text-green-400 text-center mt-4 hidden"
            >
                Enregistré.
            </p>
        </form>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('update-profile-form');
            const nameInput = document.getElementById('name');
            const emailInput = document.getElementById('email');

            const nameError = document.getElementById('name-error');
            const emailError = document.getElementById('email-error');
            const statusMessage = document.getElementById('status-message');
            const verificationMessage = document.getElementById('verification-message');
            const verificationLinkSent = document.getElementById('verification-link-sent');

            form.addEventListener('submit', function(event) {
                event.preventDefault(); // Empêche l'envoi par défaut du formulaire

                let hasError = false;

                // Valider le nom
                if (nameInput.value.trim() === '') {
                    nameError.textContent = 'Le nom est requis.';
                    nameError.classList.remove('hidden');
                    hasError = true;
                } else {
                    nameError.classList.add('hidden');
                }

                // Valider l'email
                if (emailInput.value.trim() === '') {
                    emailError.textContent = 'L\'email est requis.';
                    emailError.classList.remove('hidden');
                    hasError = true;
                } else if (!validateEmail(emailInput.value)) {
                    emailError.textContent = 'L\'email est invalide.';
                    emailError.classList.remove('hidden');
                    hasError = true;
                } else {
                    emailError.classList.add('hidden');
                }

                if (!hasError) {
                    // Soumettre le formulaire ou faire une requête AJAX
                    form.submit(); // Ou utilisez une requête AJAX

                    // Afficher le message de succès
                    statusMessage.classList.remove('hidden');
                    setTimeout(() => {
                        statusMessage.classList.add('hidden');
                    }, 2000);
                }
            });

            // Fonction de validation d'email
            function validateEmail(email) {
                const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                return re.test(email);
            }

            // Simulation de la vérification de l'email (à adapter à votre logique)
            const userEmailVerified = false; // Remplacer par $user->hasVerifiedEmail()
            if (!userEmailVerified) {
                verificationMessage.classList.remove('hidden');
            }

            // Simulation de l'état du lien de vérification envoyé (à adapter à votre logique)
            const verificationLinkSentStatus = false; // Remplacer par session('status') === 'verification-link-sent'
            if (verificationLinkSentStatus) {
                verificationLinkSent.classList.remove('hidden');
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rachad/CMS/pharmacie/resources/views/profile/partials/update-profile-information-form.blade.php ENDPATH**/ ?>