<!DOCTYPE html>
<html lang="fr">

<head>
    <title>Pharmacie CMS</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI';
        }

        ::selection {
            color: #000;
            background: #fff;
        }

        nav {
            position: fixed;
            background: #2e8b57;
            width: 100%;
            padding: 10px 0;
            z-index: 12;
        }

        nav .menu {
            max-width: 1250px;
            margin: auto;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 20px;
        }

        .menu .logo {
            display: flex;
            align-items: center;
            overflow: hidden;
        }

        .menu .logo img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-right: 10px;
        }

        .menu .logo span {
            text-decoration: none;
            color: #fff;
            font-size: 35px;
            font-weight: 600;
            display: inline-block;
            animation: move 5s infinite alternate;
            white-space: nowrap;
        }

        @keyframes move {
            0% {
                transform: translateX(0);
            }

            100% {
                transform: translateX(100px);
            }
        }

        .menu ul {
            display: inline-flex;
        }

        .menu ul li {
            list-style: none;
            margin-left: 7px;
        }

        .menu ul li:first-child {
            margin-left: 0px;
        }

        .menu ul li a {
            text-decoration: none;
            color: #fff;
            font-size: 18px;
            font-weight: 500;
            padding: 8px 15px;
            border-radius: 5px;
            transition: all 0.3s ease;
        }

        .menu ul li a:hover {
            background: #2e8b57;
            color: white;
        }

        .carousel img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            object-position: center;
            position: absolute;
            opacity: 0;
            transition: opacity 1s ease-in-out;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
            /* Ajoute un box shadow */
        }

        .carousel img, .carousel video {
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center;
    position: absolute;
    opacity: 0;
    transition: opacity 1s ease-in-out;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.5); /* Ajoute un box shadow */
}


.carousel img.active, .carousel video.active {
    opacity: 1;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.5); /* Ajoute un box shadow */
}


        .center {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 100%;
            padding: 0 20px;
            text-align: center;
            animation: fadeIn 3s ease-in-out;
            /* Animation de l'entrée */
        }

        .center .title {
            color: #ecf2f5;
            font-size: 3vw;
            font-weight: 600;
            animation: slideIn 3s ease-in-out;
            /* Animation du texte */
        }

        .center .sub_title {
            color: #fff;
            font-size: 2vw;
            font-weight: 600;
            animation: slideIn 3s 1s ease-in-out;
            /* Animation du texte avec un délai */
        }

        @keyframes fadeIn {
            0% {
                opacity: 0;
            }

            100% {
                opacity: 1;
            }
        }

        @keyframes slideIn {
            0% {
                transform: translateY(-50px);
                opacity: 0;
            }

            100% {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .center .btns {
            margin-top: 20px;
            animation: fadeInUp 2s ease-in-out;
        }

        @keyframes fadeInUp {
            0% {
                transform: translateY(50px);
                opacity: 0;
            }

            100% {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .center .btns button {
            height: 55px;
            width: 170px;
            border-radius: 5px;
            border: none;
            margin: 0 10px;
            border: 2px solid white;
            font-size: 20px;
            font-weight: 500;
            padding: 0 10px;
            cursor: pointer;
            outline: none;
            transition: all 0.3s ease;
        }

        .center .btns button:first-child {
            color: #2e8b57;
            background: none;
        }

        .btns button:first-child:hover {
            background: #2e8b57;
            color: white;
        }

        .center .btns button:last-child {
            background: #2e8b57;
            color: white;
        }

        @media (max-width: 768px) {
            nav .menu .logo span {
                font-size: 25px;
            }

            .menu ul li a {
                font-size: 16px;
            }

            .center .title {
                font-size: 5vw;
            }

            .center .sub_title {
                font-size: 3vw;
            }
        }
    </style>
</head>

<body>
    <nav>
        <div class="menu">
            <div class="logo">
                <img src="<?php echo e(asset('pharmacie_des_mimosas3.jpg')); ?>" alt="Logo">
                <span>Pharmacie Daroul couran's CMS</span>
            </div>
            <ul>
                <li><a href="<?php echo e(route('login')); ?>">Connexion</a></li>
                <li><a href="<?php echo e(route('register')); ?>">S'inscrire</a></li>

            </ul>
        </div>
    </nav>

    <div class="carousel">
        <img src="<?php echo e(asset('pharmacie_des_mimosas3.jpg')); ?>" class="active">
        <video src="<?php echo e(asset('pharma.mp4')); ?>" autoplay muted loop></video>
        <img src="<?php echo e(asset('pharma1.jpeg')); ?>">
        <img src="<?php echo e(asset('pharma2.jpeg')); ?>">
        <img src="<?php echo e(asset('pharma3.jpeg')); ?>">
    </div>

    <div class="center">
        <div class="title">La nature est l'art de Dieu.</div>
        <div class="sub_title">Dante Alighieri</div>
        
    </div>

    <script>
        // Script pour la galerie d'images et vidéos
        let slides = document.querySelectorAll('.carousel img, .carousel video');
        let currentSlide = 0;

        setInterval(() => {
            slides[currentSlide].classList.remove('active');
            currentSlide = (currentSlide + 1) % slides.length;
            slides[currentSlide].classList.add('active');
        }, 5000);
    </script>
</body>

</html>


<?php echo app('Illuminate\Foundation\Vite')('resources/js'); ?>
<?php /**PATH /home/rachad/CMS/pharmacie/resources/views/welcome.blade.php ENDPATH**/ ?>