<?php $__env->startSection('title', 'Alertes de stock'); ?>
<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold text-center text-gray-800 mb-6">Alertes de Stock</h1>

    <div class="bg-white shadow-md rounded-lg overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-800 text-white">
                    <tr>
                        <th class="px-4 py-3 text-left text-sm font-semibold">Référence ID</th>
                        <th class="px-4 py-3 text-left text-sm font-semibold">Quantité</th>
                        <th class="px-4 py-3 text-left text-sm font-semibold">Seuil</th>
                        <th class="px-4 py-3 text-left text-sm font-semibold">Notification</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__currentLoopData = $alertes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alerte): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="px-4 py-4 whitespace-nowrap"><?php echo e($alerte->references->nom_complet); ?></td>
                        <td class="px-4 py-4 whitespace-nowrap"><?php echo e($alerte->quantite); ?></td>
                        <td class="px-4 py-4 whitespace-nowrap"><?php echo e($alerte->quantite_seuil); ?></td>
                        <td class="px-4 py-3 whitespace-nowrap text-gray-700"><?php echo e($alerte->notification); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="mt-8 text-center">
        <a href="<?php echo e(route('approvisionnements.create')); ?>" class="inline-block bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Faire L'approvisionnement</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rachad/CMS/pharmacie/resources/views/alertes/index.blade.php ENDPATH**/ ?>