<?php $__env->startSection('title', 'Détails du rôle'); ?>

<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.view')): ?>
<div class="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
    <div class="max-w-3xl mx-auto">
        <div class="bg-white dark:bg-gray-800 shadow-md rounded-lg overflow-hidden">
            <div class="p-6 sm:p-8">
                <h1 class="text-3xl font-bold mb-6 text-center text-gray-900 dark:text-white">
                    Détails du rôle : <?php echo e($role->name); ?>

                </h1>

                <div class="space-y-6">
                    <div class="bg-gray-50 dark:bg-gray-700 p-4 rounded-md">
                        <p class="text-lg font-semibold text-gray-900 dark:text-gray-100">
                            <span class="font-bold">Nom :</span> <?php echo e($role->name); ?>

                        </p>
                    </div>

                    <div class="bg-gray-50 dark:bg-gray-700 p-4 rounded-md">
                        <h2 class="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">Permissions :</h2>
                        <ul class="list-disc pl-5 space-y-1">
                            <?php $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="text-gray-800 dark:text-gray-200"><?php echo e($permission->name); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>

                <div class="mt-8 flex flex-wrap justify-center space-x-4">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.edit')): ?>


                    <a  href="<?php echo e(route('roles.edit', $role)); ?>"
                       class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition duration-300 ease-in-out transform hover:scale-105" onclick="confirmUpdate(event)">
                        Modifier
                    </a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.view')): ?>


                    <a href="<?php echo e(route('roles.index')); ?>"
                       class="bg-gray-600 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded-lg transition duration-300 ease-in-out transform hover:scale-105">
                        Retour à la liste
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>


<script src="<?php echo e(asset("assets/js/sweetalert2.min.js")); ?>"></script>

<script>
    function removeRow(button) {
        button.closest('tr').remove();
    }

    function confirmUpdate(event) {
        event.preventDefault();
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Voulez vous mettre à jour !",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, mettre à jour !',
            cancelButtonText: 'Annuler'
        }).then((result) => {
            if (result.isConfirmed) {

                window.location.href = event.target.href;
            }
        });
    }
    
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rachad/CMS/pharmacie/resources/views/roles/show.blade.php ENDPATH**/ ?>