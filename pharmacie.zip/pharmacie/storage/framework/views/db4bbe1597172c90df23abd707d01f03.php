<?php $__env->startSection('title', 'Modifier un rôle'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto py-8 px-4 sm:px-6 lg:px-8">
        <header class="mb-6">
            <h1 class="text-2xl font-bold text-gray-900 dark:text-white">Modifier le rôle : <?php echo e($role->name); ?></h1>
        </header>

        <?php if($errors->any()): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                <strong class="font-bold">Erreur!</strong>
                <ul class="list-disc pl-5 mt-2">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.edit')): ?>


        <form id="role-form" method="POST" action="<?php echo e(route('roles.update', $role)); ?>" class="space-y-6">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div>
                <label for="name" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Nom du rôle</label>
                <input type="text" id="name" name="name" value="<?php echo e($role->name); ?>"
                    class="mt-2 block w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                    required>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">Permissions</label>
                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex items-center mt-2">
                        <input type="checkbox" id="permission_<?php echo e($permission->id); ?>" name="permissions[]"
                            value="<?php echo e($permission->id); ?>" <?php echo e($role->hasPermissionTo($permission) ? 'checked' : ''); ?>

                            class="mr-2 rounded border-gray-300 dark:border-gray-600 text-blue-600 focus:ring-blue-500">
                        <label for="permission_<?php echo e($permission->id); ?>" class="text-gray-900 dark:text-gray-100"><?php echo e($permission->name); ?></label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="flex items-center justify-between mt-6">
                <button type="submit" id="update-role-btn"
                    class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition-colors duration-300">
                    Mettre à jour
                </button>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.view')): ?>

                <button type="button" onclick="confirmeAnnuler('<?php echo e(route('roles.index')); ?>')" class="ml-4 bg-gray-600 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded-lg transition-colors duration-300">Annuler</button>
                <?php endif; ?>
            </div>
        </form>
        <?php endif; ?>
    </div>
    <script src="<?php echo e(asset("assets/js/sweetalert2.min.js")); ?>"></script>
    <script>
        document.getElementById('role-form').addEventListener('submit', function(event) {
            event.preventDefault(); // Empêcher le formulaire de se soumettre immédiatement

            Swal.fire({
                title: 'Êtes-vous sûr?',
                text: "Vous êtes sur le point de mettre à jour ce rôle.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Oui, mettre à jour!',
                cancelButtonText: 'Annuler'
            }).then((result) => {
                if (result.isConfirmed) {
                    this.submit(); // Soumettre le formulaire après confirmation
                }
            });
        });
        function confirmeAnnuler(url) {
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Voulez-vous annuler les modifications ?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, annuler !',
            cancelButtonText: 'Non, revenir'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = url;
            }
        });
    }
        <?php if(session('success')): ?>
            Swal.fire({
                icon: 'success',
                title: 'Succès',
                text: '<?php echo e(session('success')); ?>',
            });
        <?php endif; ?>

        <?php if(session('error')): ?>
            Swal.fire({
                icon: 'error',
                title: 'Erreur',
                text: '<?php echo e(session('error')); ?>',
            });
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rachad/CMS/pharmacie/resources/views/roles/edit.blade.php ENDPATH**/ ?>