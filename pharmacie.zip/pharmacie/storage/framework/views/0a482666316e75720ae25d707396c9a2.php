<?php $__env->startSection('title', 'Modifier Vente'); ?>

<?php $__env->startSection('content'); ?>

<div class="container mx-auto mt-8 px-4">
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ventes.edit')): ?>

    <form id="editVenteForm" action="<?php echo e(route('ventes.update', $vente->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-6">
            <label for="patient_id" class="block text-gray-700">Patient (optionnel)</label>
            <select name="patient_id" id="patient_id" class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                <option value="">Sélectionnez un patient</option>
                <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($patient->id); ?>" <?php echo e($patient->id == $vente->patient_id ? 'selected' : ''); ?>>
                        <?php echo e($patient->nom); ?> <?php echo e($patient->prenom); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="bg-white p-6 rounded-md mb-4 shadow-lg">
            <h2 class="text-xl font-semibold mb-4">Modifier les produits de la vente</h2>
            <div class="flex flex-col gap-4 md:flex-row">
                <div class="flex-1">
                    <label for="produit" class="block text-sm font-medium text-gray-700">Produit</label>
                    <select id="produit" class="w-full px-4 py-2 border border-gray-300 rounded-lg ">

                            <?php $__currentLoopData = $produits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stockProduit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($stockProduit->reference_id); ?>"
                                        data-prix="<?php echo e($stockProduit->prix); ?>"
                                        data-quantite="<?php echo e($stockProduit->quantite); ?>">
                                    <?php echo e($stockProduit->references->nom_complet); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>
                </div>

                <div class="flex-1">
                    <label for="quantite" class="block text-sm font-medium text-gray-700">Quantité</label>
                    <input type="number" id="quantite" class="w-full px-2 py-0.5 border border-gray-300 rounded-lg">
                </div>

                <div class="flex items-end">
                    <button id="ajouterLigne" type="button" class="bg-green-500 text-white px-2 py-0.5 rounded-md">
                        +
                    </button>
                </div>
            </div>
        </div>

        <div class="bg-white p-6 rounded-md shadow-md">
            <h2 class="text-xl font-semibold mb-4">Liste des produits</h2>
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="text-left py-3 px-4">Produit</th>
                            <th class="text-left py-3 px-4">Prix</th>
                            <th class="text-left py-3 px-4">Quantité</th>
                            <th class="text-left py-3 px-4">Total</th>
                            <th class="text-left py-3 px-4">Actions</th>
                        </tr>
                    </thead>
                   <tbody id="ligneVenteBody">
                        <?php $__currentLoopData = $vente->ligneDeVentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ligne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-produit-id="<?php echo e($ligne->produit_id); ?>">
                            
                            <td class="w-1/3 text-left py-3 px-4 sm:w-auto">
                                <?php echo e($ligne->ligneProduit->references->nom_complet ?? 'N/A'); ?> <!-- Access the full name of the reference -->
                            </td>
                            <td class="w-1/6 text-left py-3 px-4 sm:w-auto"><?php echo e($ligne->prix); ?></td>
                            <td class="w-1/6 text-left py-3 px-4 sm:w-auto"><?php echo e($ligne->quantite); ?></td>
                            <td class="w-1/6 text-left py-3 px-4 sm:w-auto"><?php echo e(($ligne->prix*$ligne->quantite)); ?> FCFA</td>
                            <td class="w-1/6 text-left py-3 px-4 sm:w-auto">
                                <div class="flex items-center justify-end space-x-2">
                                    <button class="bg-blue-500 text-white  px-2 py-1 rounded-md modifier-ligne">Modifier</button>
                                    <button class="bg-red-500 text-white px-2 py-1 rounded-md supprimer-ligne">Supprimer</button>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="mt-6">
            <button id="soumettreVente" type="button" class="bg-green-500 text-white px-4 py-2 rounded-md w-full md:w-auto">
                Valider la vente
            </button>
        </div>
    </form>
    <?php endif; ?>
</div>

<input type="hidden" id="productOptions" value="<?php echo e($produits->toJson()); ?>">

<?php echo app('Illuminate\Foundation\Vite')('resources/js/modification-vente.js', ['defer' => true]); ?>

<script src="<?php echo e(asset('assets/js/sweetalert2.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
        $('#produit').select2({
            placeholder: "Sélectionnez une référence",
            allowClear: true,
            width: '100%',
            minimumResultsForSearch: 0
        });

        $('#patient_id').select2({
            placeholder: "Sélectionnez un Patient",
            allowClear: true,
            width: '100%',
            minimumResultsForSearch: 0
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rachad/CMS/pharmacie/resources/views/ventes/edit.blade.php ENDPATH**/ ?>