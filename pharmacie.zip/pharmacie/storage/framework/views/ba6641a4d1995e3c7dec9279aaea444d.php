

\documentclass[11pt,a4paper]{article}
\usepackage[utf8]{inputenc}
\usepackage{amsmath}
\usepackage{amsfonts}
\usepackage{amssymb}
\usepackage{graphicx}
\usepackage[left=0.5cm,right=2cm,top=2cm,bottom=2cm]{geometry}

\usepackage{array}
\usepackage[table,xcdraw]{xcolor}
\usepackage{ragged2e}
\usepackage{tikz} % Ajouter le package tikz

% Définir des couleurs personnalisées
\definecolor{green}{RGB}{0,128,0}
\definecolor{blue}{RGB}{0,0,255}

\begin{document}

\begin{justify} % Justifier tout le document
\begin{flushleft}
\begin{minipage}{0.2\textwidth}
\begin{tikzpicture}
\clip (0,0) circle (1.5cm); % Découpe l'image en cercle avec un rayon de 1.5 cm
\node[anchor=center] at (0,0) {\includegraphics[width=3cm, height=3cm, keepaspectratio]{croix.png}};
\end{tikzpicture}
\end{minipage}
\hfill
\begin{minipage}{0.3\textwidth}
\centering
\textbf{PHARMACIE CMS DAROUL COURAN } \
CENTRE MEDICO SOCIAL  \
Kouloundé \quad CONTACTS : +(228) 93561240 \
SOKODÉ, TOGO
\end{minipage}
\end{flushleft}
\vspace{1cm}
% Invoice title and details
\begin{center}
\textbf{\Large FACTURE}
\end{center}
\vspace{0.5cm}

\begin{flushleft}
Nom du Vendeur : <?php echo e($vente->user->name); ?> \\
Date: <?php echo e($vente->date); ?> \\
Nom du client : <?php echo e($vente->patient ? $vente->patient->nom : 'Pas spécifié'); ?>

\end{flushleft}

\vspace{0.5cm}

\centering % Centrer le tableau

\begin{tabular}{|p{2.5cm}|p{7cm}|p{3cm}|p{3cm}|p{2.5cm}|}
    \hline
    \rowcolor{green}\color{white}Quantité & \color{white}Produit &  \color{white}Prix Unitaire & \color{white}Total \\
    <?php $__currentLoopData = $vente->ligneDeVentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ligne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($ligne->quantite); ?> & <?php echo e($ligne->ligneProduit->references->nom_complet); ?>

     & <?php echo e($ligne->prix); ?> & <?php echo e($ligne->quantite * $ligne->prix); ?> \\
    \hline
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    \multicolumn{3}{|r|}{\textbf{Somme totale}}  & <?php echo e(number_format($vente->total, 2)); ?> FCFA \\
    \hline
\end{tabular}
\end{justify}

\end{document}
<?php /**PATH /home/rachad/CMS/pharmacie/resources/views/latex/template_facture.blade.php ENDPATH**/ ?>