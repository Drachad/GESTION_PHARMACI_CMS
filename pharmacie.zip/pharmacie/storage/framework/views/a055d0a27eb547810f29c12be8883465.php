<?php $__env->startSection('title','Details Approvisionnement'); ?>



<?php $__env->startSection('content'); ?>

    
<div class="container px-6 mx-auto grid">
        <h2 class="my-6 text-2xl font-semibold text-gray-700 dark:text-gray-200">
        </h2>
        <h2 class="text-3xl font-semibold text-green-800 border-b-4 border-green-700 pb-3 mb-6">

            DETAILS APPROVISIONNEMENT
        </h2>
        <!-- CTA -->
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('approvisionnement.view')): ?>


            <a href="<?php echo e(Route('approvisionnements.index')); ?>"
                class="flex items-center justify-between p-4 mb-8 text-sm font-semibold text-white bg-green-600 rounded-lg shadow-md focus:outline-none focus:shadow-outline-green"
                >
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M9 15 3 9m0 0 6-6M3 9h12a6 6 0 0 1 0 12h-3" />
                  </svg>
                  
            </a>

        <?php endif; ?>


        <!-- Cards -->
        <!-- New Table -->
        <div class="w-full overflow-hidden rounded-lg shadow-xs" style="background-color: #ffffff;">
        <div class="w-full overflow-hidden rounded-lg shadow-xs" style="background-color: #ffffff;">
        <div class="w-full overflow-x-auto">
        <div class="w-full overflow-hidden rounded-lg shadow-xs bg-white">

            <div class="w-full overflow-x-auto">
                <div class="w-full overflow-hidden rounded-lg shadow-xs bg-white">
                    <div class="w-full overflow-x-auto">
                        <table class="w-full whitespace-no-wrap bg-white">
                            <thead>
                                <tr
                                    class="text-sm font-bold tracking-wide text-left text-green-600 uppercase border-b border-gray-200 bg-white">
                                    <th class="px-4 py-3">Produit</th>
                                    <th class="px-4 py-3">reference</th>
                                    <th class="px-4 py-3">prixUnitaire</th>
                                    <th class="px-4 py-3">quantité</th>
                                    <th class="px-4 py-3">date peremption</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $lignes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ligne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr class="text-gray-700 dark:text-gray-400">
                                        <td class="px-4 py-3">
                                            <?php echo e($ligne->ligneProduit->Produit->nom); ?>

                                        </td>
                                        <td class="px-4 py-3 text-sm">
                                            <?php echo e($ligne->ligneProduit->references->nom); ?>

                                        </td> 
                                        <td class="px-4 py-3 text-sm">
                                            <?php echo e($ligne->ligneProduit->prix); ?>

                                        </td> 
                                        <td class="px-4 py-3 text-sm">
                                            <?php echo e($ligne->quantite); ?>

                                        </td>
                                        <td class="px-4 py-3 text-sm">
                                            <?php echo e($ligne->ligneProduit->date_peremption); ?>

                                        </td>
                                           
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="4" class="px-4 py-3 text-center text-gray-500">pas de produit</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>

                        </table>

                    <div>
                        <?php echo e($lignes->links()); ?>

                    </div>


                    <script src="<?php echo e(asset('assets/js/sweetalert2.min.js')); ?>"></script>

                    <script>
                        function confirmcreate(event) {
                            event.preventDefault();
                            Swal.fire({
                                title: 'Êtes-vous sûr ?',
                                text: "Voulez vous retourner !",
                                icon: 'warning',


                                showCananycelButton: true,
                                confirmButtonColor: '#3085d6',
                                cananycelButtonColor: '#d33',
                                confirmButtonText: 'Oui, retour !',
                                cananycelButtonText: 'Non '


                            }).then((result) => {
                                if (result.isConfirmed) {

                                    window.location.href = event.target.href;
                                }
                            });
                        }

                        function confirmmisee(event) {
                            event.preventDefault();
                            Swal.fire({
                                title: 'Êtes-vous sûr ?',
                                text: "Voulez vous mettre à jour  !",
                                icon: 'warning',


                                showCananycelButton: true,
                                confirmButtonColor: '#3085d6',
                                cananycelButtonColor: '#d33',
                                confirmButtonText: 'Oui, mettre à jour !',
                                cananycelButtonText: 'Non '


                            }).then((result) => {
                                if (result.isConfirmed) {

                                    window.location.href = event.target.href;
                                }
                            });
                        }

                        function confirmDelete(event, form) {
                            event.preventDefault();
                            Swal.fire({
                                title: 'Êtes-vous sûr ?',
                                text: "Vous ne pourrez pas annuler cette action !",
                                icon: 'warning',

                                showCananycelButton: true,
                                confirmButtonColor: '#3085d6',
                                cananycelButtonColor: '#d33',
                                confirmButtonText: 'Oui, supprimer !',
                                cananycelButtonText: 'Annuler'


                            }).then((result) => {
                                if (result.isConfirmed) {
                                    Swal.fire({
                                        title: 'Supprimé!',
                                        text: 'La ligne a été supprimée.',
                                        icon: 'success'
                                    }).then((result) => {
                                            if (result.isConfirmed) {
                                                form.submit();
                                            }
                                
                                    });
                                }
                            });
                        }
                    </script>
                <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rachad/CMS/pharmacie/resources/views/approvisionnements/show.blade.php ENDPATH**/ ?>