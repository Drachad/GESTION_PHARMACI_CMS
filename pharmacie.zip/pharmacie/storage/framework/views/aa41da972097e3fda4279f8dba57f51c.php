<?php $__env->startSection('title','Creation d une categorie'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex justify-center items-center min-h-screen bg-gray-100">
    <div class="form-container bg-white rounded-lg shadow-lg p-8 max-w-md w-full relative">


        <!-- Bouton Retour sous forme de croix -->
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('categories.view')): ?>



        <a href="<?php echo e(route('categories.index')); ?>" class="close-button text-red-500 hover:text-red-700 text-2xl absolute top-3 right-3 transition duration-200 ease-in-out" onclick="confirmUpdate(event)">&times;</a>
        <?php endif; ?>
        <h2 class="text-3xl font-bold text-green-600 mb-6 text-center">Créer une nouvelle catégorie</h2>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('categories.create')): ?>


        <form id="categoriecreate" action="<?php echo e(route('categories.store')); ?>" method="POST" class="space-y-5">

            <?php echo csrf_field(); ?>
            <input type="hidden" name="redirect_to" value="<?php echo e(url()->previous()); ?>">

            <div class="form-group">
                <label for="nom" class="block text-gray-700 font-semibold mb-1">Nom</label>

                <input type="text" id="nom" name="nom" placeholder="Nom de la catégorie" required 

                       class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 transition duration-200 ease-in-out text-base shadow-sm">
            </div>

            <div class="form-group">
                <label for="description" class="block text-gray-700 font-semibold mb-1">Description</label>

                <textarea id="description" name="description" rows="3" placeholder="Description de la catégorie" 

                          class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 transition duration-200 ease-in-out text-base shadow-sm"></textarea>
            </div>

            <div class="form-group">

               

                <button type="submitButton" 
                        class="w-full bg-green-500 text-white font-semibold py-3 rounded-lg hover:bg-green-600 transition duration-200 ease-in-out text-base">
                    Créer Catégorie
                </button>
            </div>
        </form>
        <?php endif; ?>
    </div>
</div>

<script src="<?php echo e(asset('assets/js/sweetalert2.min.js')); ?>"></script>
<script>
    document.getElementById('submitButton').addEventListener('click', function(event) {
        event.preventDefault();
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Vous allez enregistrer cette catégorie !",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, valider !',
            cancelButtonText: 'Annuler'
        }).then((result) => {
            if (result.isConfirmed) {
                Swal.fire({
                    title: 'catégorie enregistré',
                    icon: 'success'
                }).then(() => {
                    document.getElementById('categoriecreate').submit();
                });
            }
        });
    });

    function confirmUpdate(event) {
        event.preventDefault();
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Voulez vous Annuler !",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, Annuler!',
            cancelButtonText: 'Ne pas Annuler'
        }).then((result) => {
            if (result.isConfirmed) {

                window.location.href = event.target.href;
            }
        });
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rachad/CMS/pharmacie/resources/views/categories/create.blade.php ENDPATH**/ ?>