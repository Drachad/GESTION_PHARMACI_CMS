<?php $__env->startSection('title', 'Supprimer un compte'); ?>

<?php $__env->startSection('content'); ?>

    <style>
        .hidden {
            display: none;
        }

        .close-button {
            position: absolute;
            top: 10px;
            right: 10px;
            background: transparent;
            border: none;
            cursor: pointer;
            font-size: 24px;
            color: gray;
        }

        .close-button:hover {
            color: black;
        }
    </style>



    <div class="container mx-auto py-8">
        <header>
            <h2 class="text-lg font-medium text-gray-900 dark:text-gray-100">
                Supprimer le compte
            </h2>
            <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
                Une fois votre compte supprimé, toutes ses ressources et données seront définitivement supprimées. Avant
                de supprimer votre compte, veuillez télécharger toutes les données ou informations que vous souhaitez
                conserver.
            </p>
        </header>

        <button id="delete-account-button" class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded mt-6">
            Supprimer le compte
        </button>
        <a href="<?php echo e(route('profile.action')); ?>">
            <button id="delete-account-button"
                class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded mt-6">
                Quitter
            </button>
        </a>
        <!-- Modal -->
        <div id="confirm-deletion-modal" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full hidden">
            <div class="relative top-1/4 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white dark:bg-gray-800">

                
                <button class="close-button" id="close-modal-button">&times;</button>
                <form id="delete-account-form" method="post" action="<?php echo e(route('profile.destroy')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <input type="hidden" name="password" value="<?php echo e(__('Password')); ?>">
                    <input type="hidden" name="delete" value="delete">

                    <h2 class="text-lg font-medium text-gray-900 dark:text-gray-100">
                        Etes-vous sûr de vouloir supprimer votre compte ?
                    </h2>

                    <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
                        Une fois votre compte supprimé, toutes ses ressources et données seront définitivement
                        supprimées. Veuillez saisir votre mot de passe pour confirmer que vous souhaitez supprimer
                        définitivement votre compte.
                    </p>

                    <div class="mt-6">
                        <label for="password" class="sr-only">Mot de passe</label>
                        <input id="password" name="password" type="password"
                            class="mt-1 block w-3/4 border border-gray-300 rounded-md shadow-sm dark:text-gray-800"
                            placeholder="Password" required />
                        <span id="password-error" class="text-red-500 text-sm mt-2 hidden"></span>
                    </div>

                    <div class="mt-6 flex justify-end">
                        <button type="button" id="cancel-button"
                            class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded">
                            Annuler
                        </button>
                    </div>
                    <div class="mt-6 flex justify-end">
                        <button type="submit"
                            class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded ms-3">
                            Supprimer le compte
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
       
        document.addEventListener('DOMContentLoaded', function() {
            const deleteAccountButton = document.getElementById('delete-account-button');
            const confirmDeletionModal = document.getElementById('confirm-deletion-modal');
            const cancelButton = document.getElementById('cancel-button');
            const closeModalButton = document.getElementById('close-modal-button');
            const passwordInput = document.getElementById('password');
            const passwordError = document.getElementById('password-error');

            deleteAccountButton.addEventListener('click', function() {
                confirmDeletionModal.classList.remove('hidden');
            });

            cancelButton.addEventListener('click', function() {
                confirmDeletionModal.classList.add('hidden');
            });

            closeModalButton.addEventListener('click', function() {
                confirmDeletionModal.classList.add('hidden');
            });

            
            const deleteAccountForm = document.getElementById('delete-account-form');
            deleteAccountForm.addEventListener('submit', function(event) {
                event.preventDefault(); 

                if (passwordInput.value === '') {
                    passwordError.textContent = 'Password is required.';
                    passwordError.classList.remove('hidden');
                    return;
                } else {
                    passwordError.classList.add('hidden');
                }

              
                deleteAccountForm.submit();
            });
        });
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelector('form[action="<?php echo e(route('profile.delete-account')); ?>"]').addEventListener(
                'submit',
                function(e) {
                    if (!confirm('Êtes-vous sûr de vouloir supprimer votre compte ?')) {
                        e.preventDefault();
                    }
                });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rachad/CMS/pharmacie/resources/views/profile/partials/delete-user-form.blade.php ENDPATH**/ ?>