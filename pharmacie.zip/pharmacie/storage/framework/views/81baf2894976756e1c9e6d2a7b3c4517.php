<?php $__env->startSection('content'); ?>
    <div class="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <!-- Header -->
        <div class="flex items-center justify-between mb-6">
            <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
                <?php echo e(__('Éditer le Profil')); ?>

            </h2>
            <!-- Bouton Retour à l'Accueil -->
            <a href="<?php echo e(route('welcome')); ?>"
               class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition duration-200">
                <?php echo e(__('Retour à l\'Accueil')); ?>

            </a>
        </div>

        <!-- Main Content -->
        <div class="bg-gray-100 dark:bg-gray-900 p-6 rounded-lg">

            <div class="max-w-4xl mx-auto space-y-6">
                <!-- Formulaire de mise à jour des informations de profil -->
                <div class="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6">
                    <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">
                        <?php echo e(__('Mettre à jour les informations du profil')); ?>

                    </h3>
                    <?php echo $__env->make('profile.partials.update-profile-information-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

                <!-- Formulaire de mise à jour du mot de passe -->
                <div class="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6">
                    <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">
                        <?php echo e(__('Mettre à jour le mot de passe')); ?>

                    </h3>
                    <?php echo $__env->make('profile.partials.update-password-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

                <!-- Formulaire de suppression de l'utilisateur -->
                <div class="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6">
                    <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">
                        <?php echo e(__('Supprimer le compte')); ?>

                    </h3>
                    <?php echo $__env->make('profile.partials.delete-user-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rachad/CMS/pharmacie/resources/views/profile/edit.blade.php ENDPATH**/ ?>