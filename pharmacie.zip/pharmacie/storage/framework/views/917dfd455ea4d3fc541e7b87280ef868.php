<?php $__env->startSection('title','Modifier mot de passe'); ?>
<?php $__env->startSection('content'); ?>


<div class="background-image"></div>

<div class="container">
    <div class="form-container mx-4">
        <button class="close-button" onclick="window.history.back();">&times;</button>

        <header class="mb-6 text-center">
            <h2 class="text-2xl font-semibold text-gray-900 dark:text-white mb-2">
                Mettre à jour le mot de passe
            </h2>
            <p class="text-gray-600 dark:text-gray-400">
                Assurez-vous que votre compte utilise un mot de passe long et aléatoire pour rester sécurisé.
            </p>
        </header>

        <form id="update-password-form" method="post" action="<?php echo e(route('profile.update')); ?>" class="space-y-4">
            <?php echo csrf_field(); ?>
            <?php echo method_field('patch'); ?>

            <div>
                <label for="update_password_current_password" class="block text-sm font-medium text-gray-700 dark:text-gray-300">
                    Mot de passe actuel
                </label>
                <input
                    id="update_password_current_password"
                    name="current_password"
                    type="password"
                    class="mt-2 block w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm dark:bg-gray-700 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-300"
                    autocomplete="current-password"
                    placeholder="Entrez votre mot de passe actuel"
                    required
                />
                <span id="current-password-error" class="text-red-500 text-sm mt-2 hidden"></span>
            </div>

            <div>
                <label for="update_password_password" class="block text-sm font-medium text-gray-700 dark:text-gray-300">
                    Nouveau mot de passe
                </label>
                <input
                    id="update_password_password"
                    name="password"
                    type="password"
                    class="mt-2 block w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm dark:bg-gray-700 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-300"
                    autocomplete="new-password"
                    placeholder="Entrez un nouveau mot de passe"
                    required
                />
                <span id="password-error" class="text-red-500 text-sm mt-2 hidden"></span>
            </div>

            <div>
                <label for="update_password_password_confirmation" class="block text-sm font-medium text-gray-700 dark:text-gray-300">
                    Confirmer le mot de passe
                </label>
                <input
                    id="update_password_password_confirmation"
                    name="password_confirmation"
                    type="password"
                    class="mt-2 block w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm dark:bg-gray-700 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-300"
                    autocomplete="new-password"
                    placeholder="Confirmez votre nouveau mot de passe"
                    required
                />
                <span id="password-confirmation-error" class="text-red-500 text-sm mt-2 hidden"></span>
            </div>

            <div class="flex items-center justify-between mt-4">
                <button
                    type="submit"
                    class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition duration-200"
                >
                    Enregistrer
                </button>
            </div>

            <p
                id="status-message"
                class="text-sm text-green-600 dark:text-green-400 text-center mt-4 hidden"
            >
                Enregistré.
            </p>
        </form>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const form = document.getElementById('update-password-form');
        const currentPasswordInput = document.getElementById('update_password_current_password');
        const newPasswordInput = document.getElementById('update_password_password');
        const confirmPasswordInput = document.getElementById('update_password_password_confirmation');

        const currentPasswordError = document.getElementById('current-password-error');
        const passwordError = document.getElementById('password-error');
        const passwordConfirmationError = document.getElementById('password-confirmation-error');
        const statusMessage = document.getElementById('status-message');

        form.addEventListener('submit', function(event) {
            event.preventDefault(); // Empêche l'envoi par défaut du formulaire

            let hasError = false;

            // Valider le mot de passe actuel
            if (currentPasswordInput.value.trim() === '') {
                currentPasswordError.textContent = 'Le mot de passe actuel est requis.';
                currentPasswordError.classList.remove('hidden');
                hasError = true;
            } else {
                currentPasswordError.classList.add('hidden');
            }

            // Valider le nouveau mot de passe
            if (newPasswordInput.value.trim() === '') {
                passwordError.textContent = 'Le nouveau mot de passe est requis.';
                passwordError.classList.remove('hidden');
                hasError = true;
            } else {
                passwordError.classList.add('hidden');
            }

            // Valider la confirmation du mot de passe
            if (confirmPasswordInput.value !== newPasswordInput.value) {
                passwordConfirmationError.textContent = 'Les mots de passe ne correspondent pas.';
                passwordConfirmationError.classList.remove('hidden');
                hasError = true;
            } else {
                passwordConfirmationError.classList.add('hidden');
            }

            if (!hasError) {
                // Soumettre le formulaire
                form.submit();

                // Afficher le message de succès
                statusMessage.classList.remove('hidden');
                setTimeout(() => {
                    statusMessage.classList.add('hidden');
                }, 2000);
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rachad/CMS/pharmacie/resources/views/profile/partials/update-password-form.blade.php ENDPATH**/ ?>