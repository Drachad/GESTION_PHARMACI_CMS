<!DOCTYPE html>
<html class="{ 'theme-dark': dark }" x-data="data()" lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link href="" rel="stylesheet" />
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>
    <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>

    <link href="<?php echo e(asset('assets/css/select2.min.css')); ?>" rel="stylesheet" />
    <script src="<?php echo e(asset('assets/js/select2.min.js')); ?>"></script>

    <link rel="stylesheet" href="<?php echo e(asset("assets/css/tailwind.output.css")); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset("assets/css/talwind.min.css")); ?>">

</head>

<body>
    <div class="flex h-screen bg-gray-50 dark:bg-gray-900" class="{ 'overflow-hidden': isSideMenuOpen }">
        <!-- Desktop sidebar -->
        <?php echo $__env->make('layouts.components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Mobile sidebar -->
        <!-- Backdrop -->

        <!-- Superposition -->
        <div x-show="isSideMenuOpen" x-transition:enter="transition ease-in-out duration-150"
            x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100"
            x-transition:leave="transition ease-in-out duration-150" x-transition:leave-start="opacity-100"
            x-transition:leave-end="opacity-0"
            class="fixed inset-0 z-10 flex items-end bg-black bg-opacity-50 sm:items-center sm:justify-center"
            style="display: none;"> <!-- Ajoutez style="display: none;" pour le débogage -->
        </div>

        <?php echo $__env->make('layouts.components.sidebar_mobile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="flex flex-col flex-1 w-full">

            <?php echo $__env->make("layouts.components.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <main class="h-full overflow-y-auto">
               <?php echo $__env->yieldContent('content'); ?>

            </main>

        </div>
    </div>
</body>
<style>

</style>
<script src="<?php echo e(asset("assets/js/alpine.min.js")); ?>" defer></script>

<script src="<?php echo e(asset("assets/js/init-alpine.js")); ?>"></script>
<link rel="stylesheet" href="<?php echo e(asset("assets/css/chart.min.css")); ?>" />
<script src="<?php echo e(asset("assets/js/chart.min.js")); ?>" defer></script>
<script src="<?php echo e(asset("assets/js/charts-lines.js")); ?>" defer></script>
<script src="<?php echo e(asset("assets/js/charts-pie.js")); ?>" defer></script>


</html>
<?php /**PATH /home/rachad/CMS/pharmacie/resources/views/layouts/base.blade.php ENDPATH**/ ?>