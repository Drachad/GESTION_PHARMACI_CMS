<?php $__env->startSection('title', 'Inventaire'); ?>

<?php $__env->startSection('content'); ?>



<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold text-gray-800 mb-8">Générer l'Inventaire</h1>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('inventaire')): ?>

    <?php if($errors->any()): ?>
    <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">
        <ul class="list-disc pl-5">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
    <form  id="inventaireform" action="<?php echo e(route('genererInventairePDF')); ?>" method="post" class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
        <?php echo csrf_field(); ?>

        

            <div class="flex-1 mb-4 md:mb-0">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="start_date">
                    Date de début:
                </label>
                <input type="date" id="start_date" name="date_debut" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
            </div>

            <div class="flex-1">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="end_date">
                    Date de fin:
                </label>
                <input type="date" id="date_fin" name="date_fin" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
            </div>
        </div>

        <div class="flex items-center justify-center">
            <button type="button" id="submitButton" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline w-full md:w-auto" >
                Voir l'inventaire
            </button>
        </div>
    </form>
    <?php else: ?>
    <div class="alert alert-danger">
        Vous n'avez pas la permission d'accéder à cette section.
    </div>
    <?php endif; ?>
</div>
<script src="<?php echo e(asset("assets/js/sweetalert2.min.js")); ?>"></script>
<script>
      document.getElementById('submitButton').addEventListener('click', function(event) {
        event.preventDefault();
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Vous allez enregistrer ce patient !",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, enregistrer !',
            cancelButtonText: 'Annuler'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('inventaireform').submit();
            }
        });
    });

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rachad/CMS/pharmacie/resources/views/inventaire/index.blade.php ENDPATH**/ ?>