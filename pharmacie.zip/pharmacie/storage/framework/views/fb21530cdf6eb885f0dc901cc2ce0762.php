<?php $__env->startSection('content'); ?>
<div class="container px-6 mx-auto grid">
    <h2 class="my-6 text-2xl font-semibold text-gray-700 dark:text-gray-200" style="color: #4CAF50;">
        <!-- Titre ou autre texte ici -->
    </h2>
    <h2 class="text-3xl font-semibold text-green-800 border-b-4 border-green-700 pb-3 mb-6">
        STOCK DES PRODUITS
    </h2>

    <!-- Formulaire de recherche -->
    <div class="mb-4">
        <form action="<?php echo e(route('stockProduits.index')); ?>" method="GET">
            <div class="flex flex-col sm:flex-row items-center">
                <input
                    type="text"
                    name="search"
                    value="<?php echo e(request('search')); ?>"
                    placeholder="Rechercher un produit ou une référence"
                    class="px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-600 focus:border-transparent w-full sm:w-1/3"
                >
                <button
                    type="submit"
                    class="ml-0 sm:ml-2 mt-2 sm:mt-0 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700">
                    Rechercher
                </button>
            </div>
        </form>
    </div>

    <!-- Tableau des produits -->
    <div class="w-full overflow-hidden rounded-lg shadow-xs bg-white">
        <div class="w-full overflow-x-auto">
            <table class="w-full whitespace-no-wrap bg-white">
                <thead>
                    <tr class="text-sm font-bold tracking-wide text-left text-green-600 uppercase border-b border-gray-200 bg-white">
                        <th class="px-4 py-3">Produit</th>
                        <th class=" px-6 py-3">Référence</th>
                        <th class=" px-6 py-3 ">Quantité</th>
                        <th class=" px-6 py-3">Prix Unitaire</th>
                        <th class=" px-6 py-3">Date Peremption</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $stockProduits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stockProduit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $reference = $references[$stockProduit->reference_id] ?? null;
                        ?>
                        <?php if($reference): ?>
                            <tr class="text-lg text-gray-800 bg-white hover:bg-gray-100">
                                <td class="px-4 py-3">
                                    <?php echo e($reference->Produit->nom); ?>

                                </td>
                                <td class="px-3 py-6">
                                    <?php echo e($reference->nom); ?>

                                </td>
                                <td class="px-3 py-6">
                                    <?php echo e($stockProduit->quantite_total); ?>

                                </td>
                                <td class="px-3 py-6">
                                    <?php echo e($stockProduit->prix); ?>

                                </td>
                                <td class="px-3 py-6">
                                    <?php echo e($stockProduit->date_peremption); ?>

                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="px-4 py-3 text-center text-gray-500">Pas de produit</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Pagination -->
    <div class="mt-4">
        <?php echo e($stockProduits->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rachad/CMS/pharmacie/resources/views/stock_produit/index.blade.php ENDPATH**/ ?>