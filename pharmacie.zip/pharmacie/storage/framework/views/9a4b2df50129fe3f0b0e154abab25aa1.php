\documentclass{article}
\usepackage[utf8]{inputenc}
\usepackage{amsmath}
\usepackage{geometry}
\geometry{a4paper, margin=1in}
\usepackage{graphicx}
\usepackage{longtable}

\title{Inventaire du <?php echo e($dateDebut); ?> au <?php echo e($dateFin); ?>}
\author{Ton Hôpital}
\date{\today}

\begin{document}

\maketitle

\section*{Inventaire des Références}

\begin{longtable}{| l | l | l | l | l |}
\hline
\textbf{Référence} & \textbf{Produit} & \textbf{Quantité Approvisionnée} & \textbf{Quantité Vendue} & \textbf{Stock Restant} \\
\hline
<?php $__currentLoopData = $references; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reference): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($reference['nom_reference']); ?> & 
<?php echo e($reference['produit']); ?> & 
<?php echo e($reference['quantite_approvisionnee']); ?> & 
<?php echo e($reference['quantite_vendue']); ?> & 
<?php echo e($reference['stock_restant']); ?> \\
\hline
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
\end{longtable}

\end{document}
<?php /**PATH /home/rachad/CMS/pharmacie/resources/views/latex/inventaire_stock.blade.php ENDPATH**/ ?>