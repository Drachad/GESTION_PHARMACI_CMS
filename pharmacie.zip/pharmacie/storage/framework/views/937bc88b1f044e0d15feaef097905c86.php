<?php $__env->startSection('title', 'Actions de Profil'); ?>
<?php $__env->startSection('content'); ?>

    <!-- Header -->
    <header class="bg-white dark:bg-gray-100 shadow sm:rounded-lg">
        <div class="max-w-8xl mx-auto py-3 px-2 sm:px-3 lg:px-5">
            <h2 class="font-semibold text-gray-800 dark:text-gray-100 leading-tight">
                <?php echo e(__('Actions de Profil')); ?>

            </h2>
        </div>
    </header>

    <!-- Main Content -->
    <div class="py-6 bg-gray-100 dark:bg-gray-100">
        <div class="max-w-7xl mx-auto px-2 sm:px-6 lg:px-8 space-y-6">
            <!-- Mettre à jour les Informations du Profil -->
            <div class="p-4 sm:p-6 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                <div class="max-w-md mx-auto">
                    <a href="<?php echo e(route('profile.edit')); ?>" class="w-full inline-block text-center bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded transition duration-200">
                        <?php echo e(__('Mettre à Jour les Informations du Profil')); ?>

                    </a>
                </div>
            </div>

            <!-- Mettre à jour le Mot de Passe -->
            <div class="p-4 sm:p-6 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                <div class="max-w-md mx-auto">
                    <a href="<?php echo e(route('profile.change-password')); ?>" class="w-full inline-block text-center bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded transition duration-200">
                        <?php echo e(__('Mettre à Jour le Mot de Passe')); ?>

                    </a>
                </div>
            </div>

            <!-- Supprimer le Compte -->
            <div class="p-4 sm:p-6 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                <div class="max-w-md mx-auto">
                    <a href="<?php echo e(route('profile.delete-account')); ?>" class="w-full inline-block text-center bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded transition duration-200">
                        <?php echo e(__('Supprimer le Compte')); ?>

                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bouton Retour à l'Accueil -->
    <div class="flex justify-center mt-8">
        <a href="<?php echo e(route('welcome')); ?>" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition duration-200">
            <?php echo e(__('Retour à l\'Accueil')); ?>

        </a>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rachad/CMS/pharmacie/resources/views/profile/actions.blade.php ENDPATH**/ ?>