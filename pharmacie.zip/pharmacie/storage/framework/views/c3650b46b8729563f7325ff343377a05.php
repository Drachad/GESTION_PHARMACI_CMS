

   <?php /**PATH /home/rachad/CMS/pharmacie/resources/views/layouts/app.blade.php ENDPATH**/ ?>