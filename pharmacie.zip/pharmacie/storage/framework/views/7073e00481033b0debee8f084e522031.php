<?php $__env->startSection('title','Liste Patients'); ?>

<?php $__env->startSection('content'); ?>
<div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div >
            <div class="p-6   border-gray-200">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('patients.create')): ?>
                <a href="<?php echo e(route('patients.create')); ?>"
                    class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mb-4 inline-block">
                    Ajouter un patient
                </a>
                <?php endif; ?>

                <table class="w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Nom
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Prénom
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Contact
                            </th>
                            <th scope="col" class="relative px-6 py-3">
                                <span class="sr-only">Actions</span>
                            </th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <?php echo e($patient->nom); ?>

                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <?php echo e($patient->prenom); ?>

                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <?php echo e($patient->contact); ?>

                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('patients.view')): ?>


                                <a href="<?php echo e(route('patients.show', $patient)); ?>"
                                    class="text-indigo-600 hover:text-indigo-900 mr-2">Voir</a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('patients.edit')): ?>


                                    <a href="<?php echo e(route('patients.edit', $patient)); ?>"
                                    class="text-yellow-600 hover:text-yellow-900 mr-2">Modifier</a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('patients.delete')): ?>


                                    <form action="<?php echo e(route('patients.destroy', $patient)); ?>" method="POST"
                                    class="inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="button"
                                        class="text-red-600 hover:text-red-900" onclick="confirmDelete(this)">Supprimer</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="pagination">
                    <?php echo e($patients->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<script src="<?php echo e(asset('assets/js/sweetalert2.min.js')); ?>"></script>


<script>
    function confirmDelete(button) {
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Vous ne pourrez pas annuler cette action !",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, supprimer !',
            cancelButtonText: 'Annuler'
        }).then((result) => {
            if (result.isConfirmed) {
                Swal.fire({
                    title: 'Supprimé!',
                    text: 'La ligne a été supprimée.',
                    icon: 'success'
                }).then(() => {
                    button.closest('form').submit();
                });
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rachad/CMS/pharmacie/resources/views/patients/index.blade.php ENDPATH**/ ?>