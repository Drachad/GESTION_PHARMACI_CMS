<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventaire du <?php echo e($dateDebut); ?> au <?php echo e($dateFin); ?></title>
    <style>
        body {
            margin: 0.5cm 1.5cm 1.5cm 0.5cm;
            font-family: "Helvetica Neue", Arial, sans-serif;
            color: #333;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-bottom: 20px;
            border-bottom: 2px solid #ccc;
            margin-bottom: 20px;
        }
        .logo {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            overflow: hidden;
        }
        .logo img {
            width: 100%;
            height: auto;
        }
        .pharmacy-info {
            text-align: right;
            line-height: 1.5;
        }
        .pharmacy-info p {
            margin: 0;
        }
        .pharmacy-info .green {
            color: #009688;
            font-size: 18px;
            font-weight: bold;
        }
        .pharmacy-info .blue {
            color: #1E88E5;
        }
        h1 {
            text-align: center;
            font-size: 24px;
            color: #009688;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            background-color: #f9f9f9;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th {
            background-color: #009688;
            color: white;
            padding: 6px; /* Réduction du padding pour réduire la hauteur */
            text-align: center;
            font-size: 16px;
        }
        td {
            padding: 6px; /* Réduction du padding vertical */
            text-align: center;
            font-size: 14px;
        }
        tbody tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        /* Augmentation des largeurs de colonnes */
        th:nth-child(1), td:nth-child(1) {
            width: 20%; /* Référence */
        }
        th:nth-child(2), td:nth-child(2) {
            width: 30%; /* Produit */
        }
        th:nth-child(3), td:nth-child(3) {
            width: 20%; /* Quantité Approvisionnée */
        }
        th:nth-child(4), td:nth-child(4) {
            width: 15%; /* Quantité Vendue */
        }
        th:nth-child(5), td:nth-child(5) {
            width: 15%; /* Stock Restant */
        }
    </style>
</head>
<body>

    <!-- En-tête avec le logo et les détails de la pharmacie -->
    <div class="header">
        <div class="logo">
            <img src="<?php echo e(asset('croix.png')); ?>" alt="Logo">
        </div>
        <div class="pharmacy-info">
            <p class="green">PHARMACIE CMS DAROUL COURAN</p>
            <p class="blue">CENTRE MEDICO SOCIAL</p>
            <p>Kouloundé, TOGO</p>
            <p>CONTACT : +(228) 93561240</p>
        </div>
    </div>

    <!-- Titre de la page -->
    <h1>Inventaire du <?php echo e($dateDebut); ?> au <?php echo e($dateFin); ?></h1>

    <!-- Tableau d'inventaire -->
    <table>
        <thead>
            <tr>
                <th>Référence</th>
                <th>Produit</th>
                <th>Quantité Approvisionnée</th>
                <th>Quantité Vendue</th>
                <th>Stock Restant</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $references; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reference): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($reference['nom_reference']); ?></td>
                <td><?php echo e($reference['produit']); ?></td>
                <td><?php echo e($reference['quantite_approvisionnee']); ?></td>
                <td><?php echo e($reference['quantite_vendue']); ?></td>
                <td><?php echo e($reference['stock_restant']); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</body>
</html>
<?php /**PATH /home/rachad/CMS/pharmacie/resources/views/latex/stock_inventaire.blade.php ENDPATH**/ ?>