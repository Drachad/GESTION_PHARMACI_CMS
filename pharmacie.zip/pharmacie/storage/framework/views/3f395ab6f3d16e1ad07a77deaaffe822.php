<?php $__env->startSection('title', 'Détails de la vente'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold text-center text-gray-800 mb-6">Détails de la Vente</h1>

    <div class="bg-white shadow-md rounded-lg overflow-hidden">
        <!-- Informations sur la vente -->
        <div class="p-6">
            <p><strong>Nom du Vendeur :</strong> <?php echo e($vente->user->name); ?></p>
            <p><strong>Date de la Vente :</strong> <?php echo e($vente->date); ?></p>
            <p><strong>Nom du Client :</strong> <?php echo e($vente->patient ? $vente->patient->nom : 'Pas spécifié'); ?></p>
        </div>

        <!-- Tableau des produits vendus -->
        <div class="p-6">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-800 text-white">
                    <tr>
                        <th class="px-6 py-3 text-left text-sm font-semibold">Quantité</th>
                        <th class="px-6 py-3 text-left text-sm font-semibold">Produit</th>
                        <th class="px-6 py-3 text-left text-sm font-semibold">Prix Unitaire</th>
                        <th class="px-6 py-3 text-left text-sm font-semibold">Total</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__currentLoopData = $vente->ligneDeVentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ligne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($ligne->quantite); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($ligne->ligneProduit->references->nom_complet); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?php echo e(number_format($ligne->prix, 2)); ?> FCFA</td>
                            <td class="px-6 py-4 whitespace-nowrap"><?php echo e(number_format($ligne->quantite * $ligne->prix, 2)); ?> FCFA</td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot class="bg-gray-50">
                    <tr>
                        <td colspan="3" class="px-6 py-4 text-right font-bold">Total de la Vente</td>
                        <td class="px-6 py-4 font-bold"><?php echo e(number_format($vente->total, 2)); ?> FCFA</td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

    <!-- Bouton pour télécharger la facture en PDF -->
    <div class="mt-8 text-center">
        <a href="<?php echo e(route('generer_facture', $vente)); ?>" class="inline-block bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Télécharger la Facture (PDF)</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rachad/CMS/pharmacie/resources/views/ventes/show.blade.php ENDPATH**/ ?>