<?php echo app('Illuminate\Foundation\Vite')('resources/js/id.js'); ?>
<?php $__env->startSection('title','Création d une référence'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex justify-center items-center min-h-screen bg-gray-100">
    <div class="form-container bg-white rounded-lg shadow-lg p-8 max-w-lg w-full relative">
        <!-- Bouton Retour sous forme de croix -->
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('reference.view')): ?>
        <a href="<?php echo e(route('references.index')); ?>" class="close-button text-red-500 hover:text-red-700 text-2xl absolute top-3 right-3 transition duration-200 ease-in-out" onclick="confirmUpdate(event)">&times;</a>
        <?php endif; ?>
        <h2 class="text-3xl font-bold text-green-600 mb-6 text-center">Créer une Nouvelle Référence</h2>

        <!-- Affichage des erreurs de validation -->
        <?php if($errors->any()): ?>
            <div class="alert alert-danger bg-red-100 border border-red-300 text-red-700 rounded-lg p-4 mb-4">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('reference.create')): ?>
        <form id="referencesstore" action="<?php echo e(route('references.store')); ?>" method="POST" class="space-y-5">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="redirect_to" value="<?php echo e(url()->previous()); ?>">

            <!-- Sélection de la référence -->
            <div class="form-group">
                <label for="nom" class="block text-gray-700 font-semibold mb-1">Sélectionnez une référence :</label>
                <div class="flex space-x-4">
                    <select id="nom" name="nom" class="form-control border-green-300 rounded-lg p-2 w-full">
                        <option value="">Sélectionner une référence</option>
                        <?php $__currentLoopData = $donnees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $nom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($nom); ?>"><?php echo e($nom); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <option value="autre">Autre</option>
                    </select>
                    <input type="text" id="donnees_autre" name="donnees_autre" placeholder="Saisir une nouvelle valeur" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 transition duration-200 ease-in-out text-base shadow-sm">
                </div>
            </div>

            <!-- Sélection du produit -->
            <div class="form-group">
                <label for="produit" class="block text-gray-700 font-semibold mb-1">Produit</label>
                <div class="flex space-x-4">
                    <select id="produit_id" name="produit_id" class="form-control border-green-300 rounded-lg p-2 w-full">
                        <option value="">Sélectionner un produit</option>
                        <?php $__currentLoopData = $produits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($produit->id); ?>" <?php echo e(old('produit_id') == $produit->id ? 'selected' : ''); ?>>
                                <?php echo e($produit->nom); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <!-- Champ Quantité Seuil -->
            <div class="form-group">
                <label for="quantite_seuil" class="block text-gray-700 font-semibold mb-1">Quantité Seuil</label>
                <input type="number" name="quantite_seuil" id="quantite_seuil" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 transition duration-200 ease-in-out text-base shadow-sm" required min="0" placeholder="Saisir la quantité seuil">
            </div>

            <!-- Bouton de soumission -->
            <button type="button" id="submitButton" class="w-full bg-green-500 text-white font-semibold py-3 rounded-lg hover:bg-green-600 transition duration-200 ease-in-out text-base">
                Créer Référence
            </button>
        </form>
        <?php endif; ?>
    </div>
</div>

<!-- Scripts pour la gestion du formulaire -->
<script src="<?php echo e(asset('assets/js/sweetalert2.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
        $('#produit_id').select2({
            placeholder: "Sélectionnez un produit",
            allowClear: true,
            width: '100%',
            language: {
                noResults: function() {
                    return $('<span>').append(
                        $('<a>', {
                            href: '<?php echo e(route('produits.create')); ?>',
                            text: 'produit n\'est pas trouvé créer un nouveau',
                            class: 'text-blue-500 hover:underline',
                            target: '_blank'
                        })
                    );
                }
            }
        });

        $('#nom').select2({
            placeholder: "Sélectionnez une référence",
            allowClear: true,
            width: '100%'
        });
    });

    document.getElementById('submitButton').addEventListener('click', function(event) {
        event.preventDefault();
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Vous allez enregistrer cette référence !",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, enregistrer !',
            cancelButtonText: 'Annuler'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('referencesstore').submit();
            }
        });
    });

    function confirmUpdate(event) {
        event.preventDefault();
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Voulez-vous annuler ?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, annuler !',
            cancelButtonText: 'Non'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = event.target.href;
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rachad/CMS/pharmacie/resources/views/references/create.blade.php ENDPATH**/ ?>