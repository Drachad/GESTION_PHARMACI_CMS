<?php $__env->startSection('title', 'Information d\'un patient'); ?>

<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('patients.view')): ?>
<div class="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
    <div class="max-w-3xl mx-auto">
        <div class="bg-white shadow-md rounded-lg overflow-hidden">
            <div class="p-6 sm:p-8">
                <h2 class="text-3xl font-bold mb-6 text-center text-gray-800">Détails du patient</h2>

                <div class="space-y-4">
                    <div class="bg-gray-50 p-4 rounded-md">
                        <p class="text-gray-700"><span class="font-semibold">Nom :</span> <?php echo e($patient->nom); ?></p>
                    </div>
                    <div class="bg-gray-50 p-4 rounded-md">
                        <p class="text-gray-700"><span class="font-semibold">Prénom :</span> <?php echo e($patient->prenom); ?></p>
                    </div>
                    <div class="bg-gray-50 p-4 rounded-md">
                        <p class="text-gray-700"><span class="font-semibold">Contact :</span> <?php echo e($patient->contact); ?></p>
                    </div>
                </div>

                <div class="mt-8 flex flex-wrap justify-end space-x-2 space-y-2 sm:space-y-0">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('patients.view')): ?>


                    <a href="<?php echo e(route('patients.index')); ?>"
                        class="bg-gray-500 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded transition duration-300 ease-in-out">
                        Retour à la liste
                    </a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('patients.edit')): ?>


                    <a href="<?php echo e(route('patients.edit', $patient)); ?>"
                        class="bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-2 px-4 rounded transition duration-300 ease-in-out">
                        Modifier
                    </a>
                    <?php endif; ?>



                    <button type="button" onclick="confirmeSupprimer()"
                        class="bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-4 rounded transition duration-300 ease-in-out">
                        Supprimer
                    </button>

                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pateints.delete')): ?>
<form id="deleteForm" action="<?php echo e(route('patients.destroy', $patient)); ?>" method="POST" class="hidden">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
</form>
<?php endif; ?>
<script src="<?php echo e(asset('assets/js/sweetalert2.min.js')); ?>"></script>
<script>
    function confirmeSupprimer() {
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Vous ne pourrez pas revenir en arrière !",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, supprimer !',
            cancelButtonText: 'Annuler'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('deleteForm').submit();
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rachad/CMS/pharmacie/resources/views/patients/show.blade.php ENDPATH**/ ?>