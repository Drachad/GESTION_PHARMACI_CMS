<?php

// @formatter:off
// phpcs:ignoreFile
/**
 * A helper file for your Eloquent Models
 * Copy the phpDocs from this file to the correct Model,
 * And remove them from this file, to prevent double declarations.
 *
 * @author Barry vd. Heuvel <barryvdh@gmail.com>
 */


namespace App\Models{
/**
 * 
 *
 * @property int $id
 * @property int $reference_id
 * @property int $quantite
 * @property int $quantite_seuil
 * @property string $notification
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \App\Models\Reference|null $references
 * @method static \Illuminate\Database\Eloquent\Builder|AlerteStock newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|AlerteStock newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|AlerteStock query()
 * @method static \Illuminate\Database\Eloquent\Builder|AlerteStock whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AlerteStock whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AlerteStock whereNotification($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AlerteStock whereQuantite($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AlerteStock whereQuantiteSeuil($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AlerteStock whereReferenceId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AlerteStock whereUpdatedAt($value)
 */
	class AlerteStock extends \Eloquent {}
}

namespace App\Models{
/**
 * 
 *
 * @property int $id
 * @property string $date
 * @property int $fournisseur_id
 * @property int $user_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \App\Models\Fournisseur $fournisseur
 * @property-read \Illuminate\Database\Eloquent\Collection<int, \App\Models\LigneApprovisionnement> $lignes
 * @property-read int|null $lignes_count
 * @property-read \App\Models\Produit|null $produit
 * @property-read \App\Models\User $user
 * @method static \Illuminate\Database\Eloquent\Builder|Approvisionnement newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Approvisionnement newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Approvisionnement query()
 * @method static \Illuminate\Database\Eloquent\Builder|Approvisionnement whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Approvisionnement whereDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Approvisionnement whereFournisseurId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Approvisionnement whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Approvisionnement whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Approvisionnement whereUserId($value)
 */
	class Approvisionnement extends \Eloquent {}
}

namespace App\Models{
/**
 * 
 *
 * @property int $id
 * @property string $nom
 * @property string|null $description
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection<int, \App\Models\Produit> $produits
 * @property-read int|null $produits_count
 * @method static \Illuminate\Database\Eloquent\Builder|Categorie newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Categorie newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Categorie query()
 * @method static \Illuminate\Database\Eloquent\Builder|Categorie whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Categorie whereDescription($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Categorie whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Categorie whereNom($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Categorie whereUpdatedAt($value)
 */
	class Categorie extends \Eloquent {}
}

namespace App\Models{
/**
 * 
 *
 * @property int $id
 * @property string $nom
 * @property string $contact
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection<int, \App\Models\Approvisionnement> $approvisionnements
 * @property-read int|null $approvisionnements_count
 * @method static \Illuminate\Database\Eloquent\Builder|Fournisseur newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Fournisseur newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Fournisseur query()
 * @method static \Illuminate\Database\Eloquent\Builder|Fournisseur whereContact($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Fournisseur whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Fournisseur whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Fournisseur whereNom($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Fournisseur whereUpdatedAt($value)
 */
	class Fournisseur extends \Eloquent {}
}

namespace App\Models{
/**
 * 
 *
 * @property int $id
 * @property int $quantite
 * @property int $ligneProduit_id
 * @property int $approvisionnement_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \App\Models\Approvisionnement $approvisionnement
 * @property-read \App\Models\StockProduit $ligneProduit
 * @property-read \Illuminate\Database\Eloquent\Collection<int, \App\Models\Reference> $references
 * @property-read int|null $references_count
 * @method static \Illuminate\Database\Eloquent\Builder|LigneApprovisionnement newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|LigneApprovisionnement newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|LigneApprovisionnement query()
 * @method static \Illuminate\Database\Eloquent\Builder|LigneApprovisionnement whereApprovisionnementId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|LigneApprovisionnement whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|LigneApprovisionnement whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|LigneApprovisionnement whereLigneProduitId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|LigneApprovisionnement whereQuantite($value)
 * @method static \Illuminate\Database\Eloquent\Builder|LigneApprovisionnement whereUpdatedAt($value)
 */
	class LigneApprovisionnement extends \Eloquent {}
}

namespace App\Models{
/**
 * 
 *
 * @property int $id
 * @property int $quantite
 * @property int $produit_id
 * @property int $vente_id
 * @property string $date_peremption
 * @property string $prix
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \App\Models\StockProduit $ligneProduit
 * @property-read \App\Models\Produit $produit
 * @property-read \App\Models\Vente $vente
 * @method static \Illuminate\Database\Eloquent\Builder|LigneDeVente newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|LigneDeVente newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|LigneDeVente query()
 * @method static \Illuminate\Database\Eloquent\Builder|LigneDeVente whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|LigneDeVente whereDatePeremption($value)
 * @method static \Illuminate\Database\Eloquent\Builder|LigneDeVente whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|LigneDeVente wherePrix($value)
 * @method static \Illuminate\Database\Eloquent\Builder|LigneDeVente whereProduitId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|LigneDeVente whereQuantite($value)
 * @method static \Illuminate\Database\Eloquent\Builder|LigneDeVente whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|LigneDeVente whereVenteId($value)
 */
	class LigneDeVente extends \Eloquent {}
}

namespace App\Models{
/**
 * 
 *
 * @property int $id
 * @property string $nom
 * @property string $prenom
 * @property string $contact
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection<int, \App\Models\Vente> $ventes
 * @property-read int|null $ventes_count
 * @method static \Illuminate\Database\Eloquent\Builder|Patient newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Patient newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Patient query()
 * @method static \Illuminate\Database\Eloquent\Builder|Patient whereContact($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Patient whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Patient whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Patient whereNom($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Patient wherePrenom($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Patient whereUpdatedAt($value)
 */
	class Patient extends \Eloquent {}
}

namespace App\Models{
/**
 * 
 *
 * @property int $id
 * @property string $nom
 * @property int $categorie_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \App\Models\Categorie $categorie
 * @property-read \Illuminate\Database\Eloquent\Collection<int, \App\Models\StockProduit> $ligneProduits
 * @property-read int|null $ligne_produits_count
 * @property-read \Illuminate\Database\Eloquent\Collection<int, \App\Models\Reference> $reference
 * @property-read int|null $reference_count
 * @property-read \Illuminate\Database\Eloquent\Collection<int, \App\Models\Reference> $references
 * @property-read int|null $references_count
 * @method static \Database\Factories\ProduitFactory factory($count = null, $state = [])
 * @method static \Illuminate\Database\Eloquent\Builder|Produit newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Produit newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Produit query()
 * @method static \Illuminate\Database\Eloquent\Builder|Produit whereCategorieId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Produit whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Produit whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Produit whereNom($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Produit whereUpdatedAt($value)
 */
	class Produit extends \Eloquent {}
}

namespace App\Models{
/**
 * 
 *
 * @property int $id
 * @property string $nom
 * @property string|null $nom_complet
 * @property int $produit_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \App\Models\Produit $Produit
 * @property-read \App\Models\AlerteStock|null $alerte
 * @property-read \Illuminate\Database\Eloquent\Collection<int, \App\Models\StockProduit> $ligneProduits
 * @property-read int|null $ligne_produits_count
 * @property-read \Illuminate\Database\Eloquent\Collection<int, \App\Models\StockProduit> $stockProduits
 * @property-read int|null $stock_produits_count
 * @method static \Database\Factories\ReferenceFactory factory($count = null, $state = [])
 * @method static \Illuminate\Database\Eloquent\Builder|Reference newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Reference newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Reference query()
 * @method static \Illuminate\Database\Eloquent\Builder|Reference whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Reference whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Reference whereNom($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Reference whereNomComplet($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Reference whereProduitId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Reference whereUpdatedAt($value)
 */
	class Reference extends \Eloquent {}
}

namespace App\Models{
/**
 * 
 *
 * @property int $id
 * @property int $produit_id
 * @property int $reference_id
 * @property string|null $lot
 * @property int $quantite
 * @property string $date_peremption
 * @property string $prix
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection<int, \App\Models\LigneApprovisionnement> $ligneApprovisionnements
 * @property-read int|null $ligne_approvisionnements_count
 * @property-read \Illuminate\Database\Eloquent\Collection<int, \App\Models\LigneDeVente> $ligneVentes
 * @property-read int|null $ligne_ventes_count
 * @property-read \App\Models\Produit $produit
 * @property-read \App\Models\Reference $references
 * @method static \Illuminate\Database\Eloquent\Builder|StockProduit newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|StockProduit newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|StockProduit query()
 * @method static \Illuminate\Database\Eloquent\Builder|StockProduit whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StockProduit whereDatePeremption($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StockProduit whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StockProduit whereLot($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StockProduit wherePrix($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StockProduit whereProduitId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StockProduit whereQuantite($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StockProduit whereReferenceId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StockProduit whereUpdatedAt($value)
 */
	class StockProduit extends \Eloquent {}
}

namespace App\Models{
/**
 * 
 *
 * @property int $id
 * @property string $name
 * @property string $email
 * @property \Illuminate\Support\Carbon|null $email_verified_at
 * @property string|null $profile_picture
 * @property mixed $password
 * @property string|null $remember_token
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection<int, \App\Models\Approvisionnement> $approvisionnements
 * @property-read int|null $approvisionnements_count
 * @property-read \Illuminate\Notifications\DatabaseNotificationCollection<int, \Illuminate\Notifications\DatabaseNotification> $notifications
 * @property-read int|null $notifications_count
 * @property-read \Illuminate\Database\Eloquent\Collection<int, \Spatie\Permission\Models\Permission> $permissions
 * @property-read int|null $permissions_count
 * @property-read \Spatie\Permission\Models\Role|null $role
 * @property-read \Illuminate\Database\Eloquent\Collection<int, \Spatie\Permission\Models\Role> $roles
 * @property-read int|null $roles_count
 * @property-read \Illuminate\Database\Eloquent\Collection<int, \App\Models\Vente> $ventes
 * @property-read int|null $ventes_count
 * @method static \Database\Factories\UserFactory factory($count = null, $state = [])
 * @method static \Illuminate\Database\Eloquent\Builder|User newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|User newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|User permission($permissions, $without = false)
 * @method static \Illuminate\Database\Eloquent\Builder|User query()
 * @method static \Illuminate\Database\Eloquent\Builder|User role($roles, $guard = null, $without = false)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereEmail($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereEmailVerifiedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User wherePassword($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereProfilePicture($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereRememberToken($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User withoutPermission($permissions)
 * @method static \Illuminate\Database\Eloquent\Builder|User withoutRole($roles, $guard = null)
 */
	class User extends \Eloquent {}
}

namespace App\Models{
/**
 * 
 *
 * @property int $id
 * @property \Illuminate\Support\Carbon $date
 * @property string|null $total
 * @property int|null $patient_id
 * @property int $user_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection<int, \App\Models\LigneDeVente> $ligneDeVentes
 * @property-read int|null $ligne_de_ventes_count
 * @property-read \App\Models\Patient|null $patient
 * @property-read \App\Models\User $user
 * @method static \Illuminate\Database\Eloquent\Builder|Vente newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Vente newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Vente query()
 * @method static \Illuminate\Database\Eloquent\Builder|Vente whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Vente whereDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Vente whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Vente wherePatientId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Vente whereTotal($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Vente whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Vente whereUserId($value)
 */
	class Vente extends \Eloquent {}
}

