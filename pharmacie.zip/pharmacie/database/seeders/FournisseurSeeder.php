<?php

namespace Database\Seeders;
use App\Models\Fournisseur;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class FournisseurSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Fournisseur::insert([
            ['nom' => 'Fournisseur A', 'contact' => '0123456789'],
            ['nom' => 'Fournisseur B', 'contact' => '0987654321'],
            // Add 8 more suppliers
        ]);
    }
}
