<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class RoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // // Créer les permissions de base
        // $basicPermissions = [
        //     'Liste ventes',
        //     'creer vente',
        //     'liste produit',
        //     // Ajoutez les autres permissions spécifiques ici si nécessaire
        // ];

        // foreach ($basicPermissions as $permission) {
        //     if (!empty($permission)) {
        //         Permission::create(['name' => $permission]);
        //     }
        // }

        // Créer toutes les permissions
        $permissions = [
            'alerte.view',
            'users.create',
            'users.edit',
            'users.delete',
            'users.view',
            'roles.view',
            'roles.create',
            'roles.edit',
            'roles.delete',
            'roles.assign',
            'ventes.create',
            'ventes.edit',
            'ventes.delete',
            'ventes.view',
            'produits.create',
            'produits.edit',
            'produits.delete',
            'produits.view',
            'Parametres.edit',
            'Parametres.view',
            'fournisseurs.create',
            'fournisseurs.edit',
            'fournisseurs.delete',
            'fournisseurs.view',
            'approvisionnement.create',
            'approvisionnement.edit',
            'approvisionnement.delete',
            'approvisionnement.view',
            'inventaire.view',
            'patients.create',
            'patients.edit',
            'patients.delete',
            'patients.view',
            'expired-products.view',
            'expired-products.delete',
            'inventaire',
            'profile.view',
             'profile.edit',
             'profile.update',
             'profile.delete',
             'profile.change-password',
             'categories.view',
             'categories.create',
             'categories.edit',
             'categories.delete',
             'reference.view',
            'reference.create',
            'reference.edit',
            'reference.delete',
            'stock.view',
            'stock.create',
            'stock.edit',
            'stock.delete',
        ];

        foreach ($permissions as $permission) {
            Permission::create(['name' => $permission]);
        }

        // Créer les rôles et assigner les permissions
        $admin = Role::create(['name' => 'admin']);
        $admin->givePermissionTo(Permission::all());

        $directive = Role::create(['name' => 'directrice']);
        $directive->givePermissionTo([
            'users.view',
            'users.create',
            'users.edit',
            'users.delete',
            'roles.view',
            'roles.create',
            'roles.edit',
            'roles.delete',
            'roles.assign',
            'ventes.view',
            'produits.create',
            'produits.edit',
            'produits.delete',
            'produits.view',
            'Parametres.edit',
            'Parametres.view',
            'fournisseurs.create',
            'fournisseurs.edit',
            'fournisseurs.delete',
            'fournisseurs.view',
            'approvisionnement.create',
            'approvisionnement.edit',
            'approvisionnement.delete',
            'approvisionnement.view',
            'patients.create',
            'patients.edit',
            'patients.delete',
            'patients.view',
            'expired-products.view',
            'expired-products.delete',
            'inventaire',
            'profile.view',
            'profile.edit',
            'profile.update',
            'profile.delete',
            'profile.change-password',

             'reference.view',
            'reference.create',
            'reference.edit',
            'reference.delete',
            'stock.view',
            'stock.create',
            'stock.edit',
            'stock.delete',
        ]);

        $caissier = Role::create(['name' => 'caissier']);
        $caissier->givePermissionTo([
            'ventes.create',
            'ventes.view',
            'ventes.edit',
            'produits.view',
            'inventaire.view',
            'patients.create',
            'patients.edit',
            'patients.delete',
            'patients.view',
            'inventaire',
            'profile.view',
            'profile.edit',
            'profile.update',
            'profile.delete',
            'profile.change-password',
            'stock.view',


        ]);

        // $user = Role::create(['name' => 'user']);
        // $user->givePermissionTo(['ventes.view', 'produits.view']);

        // Créer le rôle de secrétaire avec les permissions appropriées
        $secretaire = Role::create(['name' => 'secretaire']);
        $secretaire->givePermissionTo([
            'users.view',
            'ventes.view',
            'ventes.create',
            'ventes.edit',
            'produits.create',
            'produits.edit',
            'produits.delete',
            'produits.view',
            'Parametres.edit',
            'Parametres.view',
            'fournisseurs.create',
            'fournisseurs.edit',
            'fournisseurs.delete',
            'fournisseurs.view',
            'approvisionnement.create',
            'approvisionnement.edit',
            'approvisionnement.delete',
            'approvisionnement.view',

            'patients.create',
            'patients.edit',
            'patients.delete',
            'patients.view',
            'expired-products.view',
            'expired-products.delete',
            'inventaire',
            'profile.view',
            'profile.edit',
            'profile.update',
            'profile.delete',
            'profile.change-password',
            'categories.view',
             'categories.create',
             'categories.edit',
             'categories.delete',
             'categories.view',
             'categories.create',
             'categories.edit',
             'categories.delete',
             'reference.view',
            'reference.create',
            'reference.edit',
            'reference.delete',
            'stock.view',
            'stock.create',
            'stock.edit',
            'stock.delete',

        ]);
        $secretaire = Role::create(['name' => 'user']);
        $secretaire->givePermissionTo([
        'profile.view',
        'profile.edit',
        'profile.update',
        'profile.delete',
        'profile.change-password',
        'Parametres.edit',
         'Parametres.view',
        ]);
    }
}
