<?php

namespace Database\Seeders;
use App\Models\Categorie;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CategorieSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Categorie::insert([
            ['nom' => 'Antibiotiques', 'description' => 'Médicaments contre les infections'],
            ['nom' => 'Analgésiques', 'description' => 'Médicaments contre la douleur'],
            ['nom' => 'Vitamines', 'description' => 'Suppléments vitaminiques'],
            ['nom' => 'Antiviraux', 'description' => 'Médicaments contre les virus'],
            ['nom' => 'Vaccins', 'description' => 'Prévention des maladies'],
            // Add 5 more categories
        ]);
    }
}
