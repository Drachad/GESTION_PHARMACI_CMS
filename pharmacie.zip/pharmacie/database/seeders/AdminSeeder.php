<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
       $user= User::create([
            'name' =>'patrik',
            'email' =>'patrik.admin@gmail.com',
            'email_verified_at' => now(),
            'password' =>  Hash::make('patrik_admin2024_cms'),

        ]);
        $user->assignRole('caissier');
        $user= User::create([
            'name' =>'patrik',
            'email' =>'pat.admin@gmail.com',
            'email_verified_at' => now(),
            'password' =>  Hash::make('patrik_admin2024_cms'),

        ]);
        $user->assignRole('directrice');
        $user= User::create([
            'name' =>'patrik',
            'email' =>'patik.admin@gmail.com',
            'email_verified_at' => now(),
            'password' =>  Hash::make('patrik_admin2024_cms'),

        ]);
        $user->assignRole('secretaire');

        $user= User::create([
            'name' =>'rachad',
            'email' =>'rachad.admin@gmail.com',
            'email_verified_at' => now(),
            'password' =>  Hash::make('rachad_admin2024_cms'),

        ]);
        $user->assignRole('admin');
    }
}
