<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        DB::unprepared('
            CREATE TRIGGER calculate_total_after_insert_ligne_de_ventes
            AFTER INSERT ON ligne_de_ventes
            FOR EACH ROW
            BEGIN
                UPDATE ventes
                SET total = (SELECT COALESCE(SUM(quantite * prix), 0) FROM ligne_de_ventes WHERE vente_id = NEW.vente_id)
                WHERE id = NEW.vente_id;
            END;
        ');

        DB::unprepared('
            CREATE TRIGGER calculate_total_after_update_ligne_de_ventes
            AFTER UPDATE ON ligne_de_ventes
            FOR EACH ROW
            BEGIN
                UPDATE ventes
                SET total = (SELECT COALESCE(SUM(quantite * prix), 0) FROM ligne_de_ventes WHERE vente_id = NEW.vente_id)
                WHERE id = NEW.vente_id;
            END;
        ');

        DB::unprepared('
            CREATE TRIGGER calculate_total_after_delete_ligne_de_ventes
            AFTER DELETE ON ligne_de_ventes
            FOR EACH ROW
            BEGIN
                UPDATE ventes
                SET total = (SELECT COALESCE(SUM(quantite * prix), 0) FROM ligne_de_ventes WHERE vente_id = OLD.vente_id)
                WHERE id = OLD.vente_id;
            END;
        ');

        
    }

    /**
     * Reverse the migrations.
     */
    public function down()
    {

        // Suppression du trigger
        DB::statement("DROP TRIGGER IF EXISTS generate_lot");
        DB::unprepared('DROP TRIGGER IF EXISTS calculate_total_after_insert_ligne_de_ventes');
        DB::unprepared('DROP TRIGGER IF EXISTS calculate_total_after_update_ligne_de_ventes');
        DB::unprepared('DROP TRIGGER IF EXISTS calculate_total_after_delete_ligne_de_ventes');
    }
};
