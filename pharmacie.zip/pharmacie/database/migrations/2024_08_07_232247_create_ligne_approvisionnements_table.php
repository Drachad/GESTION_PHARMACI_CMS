<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::create('ligne_approvisionnements', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->bigInteger('quantite');
            $table->unsignedBigInteger('ligneProduit_id');
            $table->unsignedBigInteger('approvisionnement_id');
            $table->foreign('ligneProduit_id')->references('id')->on('stock_produits')->onDelete('cascade');
            $table->foreign('approvisionnement_id')->references('id')->on('approvisionnements')->onDelete('cascade');
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('ligne_approvisionnements');
    }
};
