<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::create('ligne_de_ventes', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->bigInteger('quantite');
            $table->unsignedBigInteger('produit_id');
            $table->unsignedBigInteger('vente_id');
            $table->foreign('produit_id')->references('id')->on('stock_produits')->onDelete('set null');
            $table->foreign('vente_id')->references('id')->on('ventes')->onDelete('cascade');
            $table->decimal('prix',8,2);//nous allons stocker le prix lors de la vente
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('ligne_de_ventes');
    }
};
