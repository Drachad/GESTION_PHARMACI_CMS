<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('stock_produits', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('produit_id');
            $table->unsignedBigInteger('reference_id');
            $table->string('lot')->nullable();
            $table->integer('quantite');
            $table->date('date_peremption');
            $table->decimal('prix',8,2);
            // Relations avec les autres tables
            $table->foreign('produit_id')->references('id')->on('produits')->onDelete('cascade');
            $table->foreign('reference_id')->references('id')->on('references')->onDelete('cascade');

            $table->timestamps();
        });
        DB::statement("
        CREATE TRIGGER generate_lot
        AFTER INSERT ON stock_produits
        FOR EACH ROW
        BEGIN
            UPDATE stock_produits
            SET lot = 'LOT-' || NEW.produit_id || '-' || NEW.reference_id || '-'|| NEW.id
            WHERE id = NEW.id;
        END;
    ");
    DB::statement("
        CREATE TRIGGER adjust_quantity_after_delete
        AFTER DELETE ON ligne_de_ventes
        FOR EACH ROW
        BEGIN
            UPDATE stock_produits
            SET quantite = quantite + OLD.quantite
            WHERE id = OLD.produit_id;
        END;

    ");
    DB::statement("
        CREATE TRIGGER adjust_quantity_after_update
        AFTER UPDATE ON ligne_de_ventes
        FOR EACH ROW
        BEGIN
            -- Réduire la quantité pour l'ancien produit
            UPDATE stock_produits
            SET quantite = quantite + OLD.quantite
            WHERE id = OLD.produit_id;

            -- Réduire la quantité pour le nouveau produit (si modifié)
            UPDATE stock_produits
            SET quantite = quantite - NEW.quantite
            WHERE id = NEW.produit_id;
        END;
");
    DB::statement("
        CREATE TRIGGER delete_stock_after_approvisionnement
        AFTER DELETE ON ligne_approvisionnements
        FOR EACH ROW
        BEGIN
            DELETE  FROM stock_produits WHERE stock_produits.id = OLD.ligneProduit_id;
        END
    ");

    DB::statement("
        CREATE TRIGGER update_prix_stock
        AFTER INSERT ON 'stock_produits'
        FOR EACH ROW
        BEGIN
            UPDATE 'stock_produits'  SET prix = new.prix WHERE stock_produits.id = new.id and
            stock_produits.reference_id = new.reference_id and
            stock_produits.date_peremption = new.date_peremption;
        END
    ");


    DB::statement("

           CREATE TRIGGER adjust_nom_complet
            AFTER INSERT ON 'references'
            FOR EACH ROW
            BEGIN
                UPDATE 'references'
                SET nom_complet = (SELECT nom FROM produits WHERE produits.id = NEW.produit_id) || ' ' || NEW.nom
                WHERE id = NEW.id;
            END;
    ");


    }





    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        DB::statement('DROP TRIGGER IF EXISTS generate_lot');
        DB::statement('DROP TRIGGER IF EXISTS adjust_quantity_after_delete');
        DB::statement('DROP TRIGGER IF EXISTS adjust_quantity_after_update');
        DB::statement('DROP TRIGGER IF EXISTS delete_stock_after_approvisionnement');
        DB::statement('DROP TRIGGER IF EXISTS adjust_nom_complet');
        DB::statement('DROP TRIGGER IF EXISTS update_prix_stock');


        Schema::dropIfExists('stock_produits');
    }
};
