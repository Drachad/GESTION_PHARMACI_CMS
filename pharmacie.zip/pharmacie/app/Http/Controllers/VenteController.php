<?php

namespace App\Http\Controllers;

use App\Events\AlerteStockEvent;
use App\Models\Alarme;
use App\Models\AlerteStock;
use App\Models\LigneDeVente;
use App\Models\LigneProduit;
use App\Models\Patient;
use App\Models\Produit;
use App\Models\StockProduit;
use App\Models\Vente;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Ismaelw\LaraTeX\LaraTeX;
use Illuminate\Routing\Controller ;
class VenteController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function __construct()
    {
        // Appliquer des autorisations sur chaque méthode si nécessaire
        // Exemple d'application des permissions
        $this->middleware('can:ventes.view')->only(['index', 'show']);
        $this->middleware('can:ventes.create')->only(['create', 'store']);
        $this->middleware('can:ventes.edit')->only(['edit', 'update']);
        $this->middleware('can:ventes.delete')->only(['destroy']);
    }
     public function index()
     {
         // Pagination avec 10 éléments par page
         $ventes = Vente::with('ligneDeVentes.ligneProduit', 'patient', 'user','ligneDeVentes.produit.references')
                        ->paginate(10);

         return view('ventes.index', compact('ventes'));
     }


    /**
     * Show the form for creating a new resource.
     */
    public function create()
{


// Récupération des produits avec leurs informations nécessaires
$produitsSeuil = StockProduit::select('stock_produits.*', 'alerte_stocks.quantite_seuil')
->join('alerte_stocks', 'stock_produits.reference_id', '=', 'alerte_stocks.reference_id')
->where('stock_produits.quantite', '<=', DB::raw('alerte_stocks.quantite_seuil'))
->where('stock_produits.date_peremption', '>', now())->get();



// Traitement des alertes
foreach ($produitsSeuil as $produit) {
    $quantiteRestante = $produit->quantite;
    $referenceId = $produit->reference_id;

    // Récupération de la quantite_seuil depuis la table alerte_stocks
    $alerteExistante = AlerteStock::where('reference_id', $referenceId)->first();

    if ($alerteExistante) {
        $quantiteSeuil = $alerteExistante->quantite_seuil;

        // Déterminer le message d'alerte basé sur la quantité seuil
        if ($quantiteRestante <= $quantiteSeuil * 0.2) {
            $message = 'Alerte critique : la quantité  est très basse (' . $quantiteRestante . ' restant). Seuil : ' . $quantiteSeuil;
        } elseif ($quantiteRestante <= $quantiteSeuil * 0.5) {
            $message = 'Alerte élevée : la quantité  est basse (' . $quantiteRestante . ' restant). Seuil : ' . $quantiteSeuil;
        } elseif ($quantiteRestante <= $quantiteSeuil * 0.8) {
            $message = 'Alerte moyenne : la quantité  est moyenne (' . $quantiteRestante . ' restant). Seuil : ' . $quantiteSeuil;
        } else {
            continue; // Si la quantité est au-dessus du seuil, aucun message n'est généré
        }

        // Mise à jour de l'alerte existante avec le nouveau message
        $alerteExistante->update([
            'quantite' => $quantiteRestante,
            'notification' => $message,
        ]);
    } else {
        // Création d'une nouvelle alerte si elle n'existe pas encore
        $quantiteSeuil = 0; // Définir une valeur par défaut ou gérer autrement si nécessaire
        $message = 'Alerte : la quantité est à surveiller (' . $quantiteRestante . ' restant). Seuil : ' . $quantiteSeuil;

        AlerteStock::create([
            'reference_id' => $referenceId,
            'quantite' => $quantiteRestante,
            'quantite_seuil' => $quantiteSeuil, // Valeur par défaut ou à définir selon votre logique
            'notification' => $message,
        ]);
    }
}


    $produits = StockProduit::select('stock_produits.*')
    ->join(DB::raw('(SELECT reference_id, MIN(date_peremption) as min_date FROM stock_produits WHERE quantite > 0 AND date_peremption > datetime("now") GROUP BY reference_id) as subquery'), function($join) {
        $join->on('stock_produits.reference_id', '=', 'subquery.reference_id')
             ->on('stock_produits.date_peremption', '=', 'subquery.min_date');
    })
    ->with('references')
    ->where('quantite', '>', 0)
    ->where('date_peremption', '>', DB::raw('datetime("now")'))
    ->orderBy('stock_produits.reference_id')  // Ajout de l'ordre ici
    ->get();


// Retourner ou afficher les résultats


        $patients = Patient::all();

        return view('ventes.create', compact('produits', 'patients'));
    }








    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'patient_id' => 'nullable|exists:patients,id',
            'new_patient_nom' => 'nullable|string|max:255|required_with:new_patient_prenom,new_patient_contact',
            'new_patient_prenom' => 'nullable|string|max:255|required_with:new_patient_nom,new_patient_contact',
            'new_patient_contact' => 'nullable|string|max:255|required_with:new_patient_nom,new_patient_prenom',
            'lignes' => 'required|array',
        ]);

        $userId = Auth::user()->id;
        $patientId = $validatedData['patient_id'];

        // Création d'un nouveau patient si nécessaire
        if (!$patientId && !empty($validatedData['new_patient_nom']) && !empty($validatedData['new_patient_prenom'])) {
            $patient = Patient::create([
                'nom' => $validatedData['new_patient_nom'],
                'prenom' => $validatedData['new_patient_prenom'],
                'contact' => $validatedData['new_patient_contact'],
            ]);
            $patientId = $patient->id;
        } else {
            $patientId = $patientId ?: null;
        }

        try {
            // Début de la transaction
            DB::beginTransaction();

            // Création de la vente
            $vente = Vente::create([
                'patient_id' => $patientId,
                'user_id' => $userId,
                'date' => now(),
            ]);

            // Gestion des lignes de vente
            foreach ($validatedData['lignes'] as $ligne) {
                $produit =  StockProduit::where('lot', $ligne['lot'])->first();
                //dd($produit);
                if (!$produit) {
                    DB::rollback();
                    return redirect()->back()->withErrors(['error' => 'Le produit avec l\'ID ' . $ligne['lot'] . ' n\'existe pas.']);
                }

                // Vérification des quantités en stock
                if ($produit->quantite < $ligne['quantite']) {
                    DB::rollback();
                    return redirect()->back()->withErrors(['error' => 'La quantité demandée pour ' . $produit->produit->nom . ' dépasse la quantité en stock.']);
                }

                // Création de la ligne de vente
                LigneDeVente::create([
                    'vente_id' => $vente->id,
                    'produit_id' => $produit->produit_id,
                    'quantite' => $ligne['quantite'],
                    'prix' => $produit->prix,
                ]);

                // Mise à jour du stock
                $produit->decrement('quantite', $ligne['quantite']);


            }

            // Validation de la transaction
            DB::commit();

            return redirect()->route('ventes.index')->with('success', 'Vente enregistrée avec succès.');
        } catch (\Exception $e) {
            // Annulation en cas d'erreur
            DB::rollback();
            return redirect()->back()->withErrors(['error' => 'Erreur lors de l\'enregistrement de la vente.']);
        }
         // Gestion des alertes
         $referenceId = $produit->reference_id;
         $quantiteRestante = $produit->quantite;

         //Exemple de logique d'alerte
         $alerteExistante = AlerteStock::where('reference_id', $referenceId)->first();
         if ($alerteExistante) {
             $quantiteSeuil = $alerteExistante->quantite_seuil;
             $message = null;
             if ($quantiteRestante <= $quantiteSeuil * 0.2) {
                 $message = 'Alerte critique pour ' . $produit->produit->nom . ' : quantité très basse.';
             }
             $alerteExistante->update(['quantite' => $quantiteRestante, 'notification' => $message]);
         }
    }

      // Affiche les détails d'une vente
      public function show(Vente $vente)
      {
          return view('ventes.show', compact('vente'));
      }


    /**
     * Show the form for editing the specified resource.
     */

//      public function edit(Vente $vente)
// {
//     // Eager load 'stockProduit' with 'reference' to get the complete product details
//     $lignes = $vente->ligneDeVentes()->with('ligneProduit.references')->get();

//     // Load all patients and available products with valid stock and expiration dates
//     $patients = Patient::all();
//     $produits = StockProduit::with('references') // Correct relation name is 'reference', singular
//         ->where('quantite', '>', 0)
//         ->where('date_peremption', '>', now())
//         ->get();

//     return view('ventes.edit', compact('vente', 'lignes', 'patients', 'produits'));
// }





    /**
     * Update the specified resource in storage.
     */




    /**
     * Remove the specified resource from storage.
     */

    public function destroy(Vente $vente)
{
    // Supprimer les lignes de vente associées via la relation
    $vente->ligneDeVentes()->delete();

    // Supprimer la vente
    $vente->delete();

    return redirect()->route('ventes.index');
}
public function generer_facture(Vente $vente)
{

        // Générer et télécharger le PDF avec LaraTeX
        return (new LaraTeX('latex.template_facture'))->with([
            'vente' => $vente,


            'total' => $vente->total,
        ])->download('facture.pdf');

}
}
