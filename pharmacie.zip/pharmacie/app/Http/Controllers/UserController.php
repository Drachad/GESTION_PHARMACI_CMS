<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Spatie\Permission\Models\Role;
use Illuminate\Routing\Controller ;
class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function __construct()
    {
        // Appliquer des autorisations sur chaque méthode
        $this->middleware('can:users.view')->only(['index', 'show']);
        $this->middleware('can:users.create')->only(['create', 'store']);
        $this->middleware('can:users.edit')->only(['edit', 'update']);
        $this->middleware('can:users.delete')->only(['destroy']);
    }

    public function index(Request $request)
{
    $paginate_number = 5;
    $search = $request->input('search');

    $query = User::query();

    if ($search) {
        $query->where('name', 'like', '%' . $search . '%')
              ->orWhere('email', 'like', '%' . $search . '%')
              ->orWhere('id', 'like', '%' . $search . '%');
    }

    $user = $query->paginate($paginate_number);

    return view('user.index', compact('user', 'search'));
}


    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {

        $roles = Role::whereNotIn('name', ['admin', 'user'])->get();

        return view('user.create',compact('roles'));
    }

    /**
     * Store a newly created resource in storage.
     */



public function store(Request $request)
{
    $validatedData = $request->validate([
        'name' => 'required|string|max:255',
        'email' => 'required|string|email|max:255|unique:users',
        'password' => 'required|string|min:8|confirmed',
        'role' => 'required|string|exists:roles,name',
        'profile_picture' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
    ], [
        'required' => 'Le champ :attribute est obligatoire.',
        'string' => 'Le champ :attribute doit être une chaîne de caractères.',
        'email' => 'L\'adresse e-mail doit être au format correct.',
        'min' => 'Le champ :attribute doit contenir au moins :min caractères.',
        'max' => 'Le champ :attribute ne peut pas dépasser :max caractères.',
        'unique' => 'Le champ :attribute est déjà utilisé.',
        'exists' => 'Le champ :attribute n\'existe pas.',
        'image' => 'Le fichier doit être une image.',
        'mimes' => 'Le fichier doit être au format :mimes.',
    ]);


   if($request['profile_picture']==null){

        $validatedData['profile_picture']='./user.png';

   }else{

        $id_user=User::max('id')+1;
        $fileName=$request->file('profile_picture');
        $extension=$fileName->getClientOriginalExtension();
        $path=$request->file('profile_picture')->storeAs('profile_picture',strtolower("$$request->name"."_"."$id_user"."$extension"),'public');
        $validatedData['profile_picture']='./storage/'.$path;
   }


    $user = User::create($validatedData);

    $user->assignRole($validatedData['role']);

    return redirect()->route('user.index')->with('success', 'Utilisateur créé et rôle assigné avec succès.');
}

    /**
     * Display the specified resource.
     */
    public function show(User $user)
    {
        return view('user.show',compact('user'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(User $user)
    {

        $roles = Role::whereNotIn('name', ['admin', 'user'])->get();



        return view('user.edit', compact('user', 'roles'));
    }


    /**
     * Update the specified resource in storage.
     */

     public function update(Request $request, User $user)
     {
         $validateData = $request->validate([
             'name' => 'required|string|max:255',
             'email' => 'required|string|email|max:255|unique:users,email,' . $user->id,
            'password' => 'nullable|string|min:8|confirmed',
            'role_id' => 'required|exists:roles,id',
            'profile_picture' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
         ], [
             'required' => 'Le champ :attribute est obligatoire.',
             'string' => 'Le champ :attribute doit être une chaîne de caractères.',
             'email' => 'L\'adresse e-mail doit être au format correct.',
             'min' => 'Le champ :attribute doit contenir au moins :min caractères.',
             'max' => 'Le champ :attribute ne peut pas dépasser :max caractères.',
             'unique' => 'Le champ :attribute est déjà utilisé.',
             'exists' => 'Le champ :attribute n\'existe pas.',
             'image' => 'Le fichier doit être une image.',
             'mimes' => 'Le fichier doit être au format :mimes.',
         ]);

         // Vérifier le résultat après validation


         $user->name = $validateData['name'];
         $user->email = $validateData['email'];

         if ($request->filled('password')) {
             $user->password = Hash::make($validateData['password']);
         }

         if ($request->hasFile('profile_picture')) {
             // Supprimer l'image précédente si elle existe
             if ($user->profile_picture) {
                 Storage::delete('public/images/' . basename($user->profile_picture));
             }

             // Sauvegarder la nouvelle image
             $image = $request->file('profile_picture');
             $id_user = $user->id;
             $extension = $image->getClientOriginalExtension();
             $imageName = strtolower($user->name . "_" . $id_user . "." . $extension);
             $image->storeAs('public/images', $imageName);

             $user->profile_picture = 'storage/images/' . $imageName;
         }

         // Sauvegarder l'utilisateur
         $user->save();

         // Synchroniser le rôle
         $user->roles()->sync([$request->role_id]);
       
         return redirect()->route('user.index')->with('success', 'Utilisateur mis à jour avec succès.');
     }


    /**
     * Remove the specified resource from storage.
     */
    public function destroy(User $user)
    {
        $user->delete();

        return redirect()->route('user.index')->with('success', 'User deleted successfully.');
    }
}
