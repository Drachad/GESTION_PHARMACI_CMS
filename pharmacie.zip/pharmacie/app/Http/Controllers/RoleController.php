<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Illuminate\Validation\Rule;
use Illuminate\Routing\Controller;

class RoleController extends Controller
{
    public function __construct()
    {
        // Appliquer des autorisations sur chaque méthode si nécessaire
        $this->middleware('can:roles.view')->only(['index', 'show']);
        $this->middleware('can:roles.create')->only(['create', 'store']);
        $this->middleware('can:roles.edit')->only(['edit', 'update']);
        $this->middleware('can:roles.delete')->only(['destroy']);
    }

    public function index()
    {
        $paginate_number = 5;

        $roles_query = Role::whereNotIn('name', ['admin', 'user'])->with('permissions');
        $roles = $roles_query->has('permissions', '>=', 3)->paginate($paginate_number);

        $permissions_query = Permission::query();
        $permissions = $permissions_query->paginate($paginate_number);

        return view('roles.index', compact('roles', 'permissions'));


    }

    public function create()
    {
        $permissions = Permission::all();
        return view('roles.create', compact('permissions'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100|unique:roles,name',
            'permissions' => 'required|array',
            'permissions.*' => 'exists:permissions,id',
        ]);

        // Créer le rôle
        $role = Role::create(['name' => $request->name]);

        // Synchroniser les permissions
        if ($request->has('permissions')) {
            $permissions = Permission::whereIn('id', $request->permissions)->get();
            $role->syncPermissions($permissions);
        }

        $notifications = [
            'message' => "Rôle créé avec succès !!",
            'alert-type' => "success",
        ];

        return redirect()->route('roles.index')->with($notifications);
    }

    public function update(Request $request, Role $role)
    {
        $request->validate([
            'name' => [
                'required',
                'string',
                'max:255',
                Rule::unique('roles', 'name')->ignore($role->id),
            ],
            'permissions' => 'array',
            'permissions.*' => 'exists:permissions,id',
        ]);

        // Mettre à jour le rôle
        $role->update(['name' => $request->name]);

        // Synchroniser les permissions
        if ($request->has('permissions')) {
            $permissions = Permission::whereIn('id', $request->permissions)->get();
            $role->syncPermissions($permissions);
        } else {
            $role->permissions()->detach();
        }

        $notifications = [
            'message' => "Rôle mis à jour avec succès !!",
            'alert-type' => "success",
        ];

        return redirect()->route('roles.index')->with($notifications);
    }

    public function edit(Role $role)
    {
        $permissions = Permission::all();
        $rolePermissions = $role->permissions->pluck('id')->toArray();
        return view('roles.edit', compact('role', 'permissions', 'rolePermissions'));
    }


    public function show(Role $role)
    {
        return view('roles.show', compact('role'));
    }

    public function destroy(Role $role)
    {
        $role->delete();
        $notification = [
            'message' => "Rôle supprimé avec succès !!",
            'alert-type' => 'success',
        ];
        return redirect()->route('roles.index')->with($notification);
    }
}
