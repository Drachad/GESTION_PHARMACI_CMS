<?php

namespace App\Http\Controllers;

use App\Http\Requests\ProfileUpdateRequest;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\View\View;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Routing\Controller;

class ProfileController extends Controller
{

    /**
     * Display the user's profile form.
     */
    public function showActions(){
        return view("profile.actions");
    }
    public function edit(Request $request): View
    {
        return view('profile.edit', [
            'user' => $request->user(),
        ]);
    }

    public function show()
    {
        $user = Auth::user(); // Récupère l'utilisateur connecté
        return view('profile.partials.show', compact('user'));
    }

    /**
     * Update the user's profile information.
     */
    public function update(ProfileUpdateRequest $request): RedirectResponse
{
    $user = $request->user(); // Obtenir l'instance de l'utilisateur

    $validatedData = $request->validated();

    // Mettre à jour les informations de l'utilisateur, sauf l'image de profil
    $user->fill($validatedData);

    // Validation spécifique pour l'image de profil
    $request->validate([
        'profile_picture' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
    ]);

    // Vérifier si l'email a été modifié
    if ($user->isDirty('email')) {
        $user->email_verified_at = null; // Réinitialiser la vérification de l'email
    }

    // Traitement de l'image de profil
    if ($request->hasFile('profile_picture')) {
        // Supprimer l'ancienne image si elle existe
        if ($user->profile_picture) {
            Storage::delete($user->profile_picture);
        }

        // Stocker la nouvelle image
        $path = $request->file('profile_picture')->store('profile_pictures');

        // Mettre à jour le modèle utilisateur avec le chemin de l'image
        $user->profile_picture = $path;
    }

    // Sauvegarder les modifications de l'utilisateur
    $user->save();

    // Redirection avec message de succès
    return Redirect::route('profile.show')->with('status', 'profile-updated');
}


    /**
     * Delete the user's account.
     */
    public function destroy(Request $request): RedirectResponse
    {
        $request->validateWithBag('userDeletion', [
            'password' => ['required', 'current_password'],
        ]);

        $user = $request->user();

        Auth::logout();

        $user->delete();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return Redirect::to('/');
    }

      // Méthode pour traiter l'action du formulaire
      public function showChangePasswordForm(): View
      {
          return view('profile.partials.update-password-form');
      }

      /**
       * Display the account deletion confirmation form.
       */
      public function showDeleteAccountForm(): View
      {
          return view('profile.partials.delete-user-form');
      }

}
