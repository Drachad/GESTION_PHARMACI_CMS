<?php

namespace App\Http\Controllers;

use App\Models\AlerteStock;
use Illuminate\Http\Request;
use App\Models\Produit;
use App\Models\Categorie;

class ProduitController extends Controller
{
    public function index()
    {
        $produits = Produit::paginate(5);

        return view('produits.index', compact('produits'));
    }

    public function create()
    {

        $categories=Categorie::all();
        return view('produits.create',compact('categories'));
    }

    public function store(Request $request)
{

    // dd($request->input('hidden_id'));
    $data=$request->validate([
        'nom' => 'required|string|max:255',
        'categorie_id' => 'required|exists:categories,id',

    ],[
        'nom.required'=>'saisire le nom de la reference',
        'categorie_id.required'=>'choisire une categories'
    ]);

    Produit::create([
        'nom'=>$data['nom'],
        'categorie_id'=>$data['categorie_id']
    ]);

    // if ($request->filled('redirect_to')) {  // Utilisation de filled() pour vérifier si le champ est bien présent et non vide.
    //     // $uri=$request('redirect_to');
    //     // dd($request);

    //     return redirect($request->input('redirect_to'))
    //            ->with('success', 'Catégorie créée avec succès.');
    // }

    return redirect()->route('produits.index')->with('success', 'Produit créé avec succès.');
}


    public function show(Produit $produit)
    {
        return view('produits.show', compact('produit'));
    }

    public function edit(Produit $produit)
    {


        $categories=Categorie::all();
        return view('produits.edit', compact('produit','categories'));

    }


    public function update(Request $request, Produit $produit)
    {
        $data=$request->validate([
            'nom' => 'required|string|max:255',
            'categorie_id' => 'required|exists:categories,id',
        ],[
            'nom.required'=>'saisire le nom de la reference',
            'categorie_id.required'=>'choisire une categories'
        ]);
        $produit->update([
            'nom'=>$data['nom'],
            'categorie_id'=>$data['categorie_id']


        ]);

        return redirect()->route('produits.index')->with('success', 'Produit mis à jour avec succès.');
    }

    public function destroy(Produit $produit)
    {
        $produit->delete();
        return redirect()->route('produits.index')->with('success', 'Produit supprimé avec succès.');
    }
}
