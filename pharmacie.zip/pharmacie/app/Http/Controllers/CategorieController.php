<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Categorie;
use Illuminate\Routing\Controller ;

class CategorieController extends Controller
{
    public function __construct()
    {
        // Appliquer des autorisations sur chaque méthode
        $this->middleware('can:categories.view')->only(['index', 'show']);
        $this->middleware('can:categories.create')->only(['create', 'store']);
        $this->middleware('can:categories.edit')->only(['edit', 'update']);
        $this->middleware('can:categories.delete')->only(['destroy']);
    }
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $categories=Categorie::paginate(5);
        // dd($categories); 
        return view('categories.index',compact('categories',));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('categories.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            "nom" => "required",
           "description" => "required",]);
        Categorie::create($validatedData);

        // if ($request->filled('redirect_to')) {  // Utilisation de filled() pour vérifier si le champ est bien présent et non vide.
        //     return redirect($request->input('redirect_to'))
        //            ->with('success', 'Catégorie créée avec succès.');
        // }

        return redirect()->route('categories.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Categorie $category)
{
    // dd($category);
    return view('categories.edit', compact('category'));
}

public function update(Request $request, Categorie $category)
{
    $validatedData = $request->validate([
        "nom" => "required",
        "description" => "required",
    ]);

    $category->update($validatedData);

    return redirect()->route('categories.index')->with('success', 'Catégorie mise à jour avec succès!');
}

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Categorie $category)
    {
        // dd($category);
        $category->delete();
        return redirect()->route("categories.index");
    }
}
