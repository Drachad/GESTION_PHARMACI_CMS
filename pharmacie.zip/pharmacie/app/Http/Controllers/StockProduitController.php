<?php

namespace App\Http\Controllers;

use App\Models\Alarme;
use App\Models\AlerteStock;
use App\Models\LigneProduit;
use App\Models\Produit;
use App\Models\Reference;
use App\Models\StockProduit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Routing\Controller ;

class StockProduitController extends Controller
{
    public function __construct()
    {
        // Appliquer le middleware can pour restreindre l'accès en fonction des permissions
        $this->middleware('can:stock.view')->only('index', 'show');
        $this->middleware('can:stock.create')->only('create', 'store');
        $this->middleware('can:stock.edit')->only('edit', 'update');
        $this->middleware('can:stock.delete')->only('destroy');
    }

    public function index()
    {
        $search = request()->input('search');
        $minQuantite = request()->input('min_quantite'); // Quantité minimale à filtrer
        $maxQuantite = request()->input('max_quantite'); // Quantité maximale à filtrer

        // Étape 1: Récupération des produits avec leurs seuils et informations nécessaires
        $produitsSeuil = StockProduit::select('stock_produits.*', 'alerte_stocks.quantite_seuil')
            ->join('alerte_stocks', 'stock_produits.reference_id', '=', 'alerte_stocks.reference_id')
            ->where('stock_produits.quantite', '>', 0) // Ne pas inclure les produits dont la quantité est zéro
            ->where('stock_produits.date_peremption', '>', now())
            ->get();

        // Traitement des alertes
        foreach ($produitsSeuil as $produit) {
            $quantiteRestante = $produit->quantite;
            $referenceId = $produit->reference_id;

            // Récupération de la quantite_seuil depuis la table alerte_stocks
            $alerteExistante = AlerteStock::where('reference_id', $referenceId)->first();

            if ($alerteExistante) {
                $quantiteSeuil = $alerteExistante->quantite_seuil;

                // Déterminer le message d'alerte basé sur la quantité seuil
                if ($quantiteRestante <= $quantiteSeuil * 0.2) {
                    $message = 'Alerte critique : la quantité  est très basse (' . $quantiteRestante . ' restant). Seuil : ' . $quantiteSeuil;
                } elseif ($quantiteRestante <= $quantiteSeuil * 0.5) {
                    $message = 'Alerte élevée : la quantité  est basse (' . $quantiteRestante . ' restant). Seuil : ' . $quantiteSeuil;
                } elseif ($quantiteRestante <= $quantiteSeuil * 0.8) {
                    $message = 'Alerte moyenne : la quantité est moyenne (' . $quantiteRestante . ' restant). Seuil : ' . $quantiteSeuil;
                } else {
                    continue; // Si la quantité est au-dessus du seuil, aucun message n'est généré
                }

                // Mise à jour de l'alerte existante avec le nouveau message
                $alerteExistante->update([
                    'quantite' => $quantiteRestante,
                    'notification' => $message,
                ]);
            } else {
                // Création d'une nouvelle alerte si elle n'existe pas encore
                $quantiteSeuil = 0; // Définir une valeur par défaut ou gérer autrement si nécessaire
                $message = 'Alerte : la quantité  est à surveiller (' . $quantiteRestante . ' restant). Seuil : ' . $quantiteSeuil;

                AlerteStock::create([
                    'reference_id' => $referenceId,
                    'quantite' => $quantiteRestante,
                    'quantite_seuil' => $quantiteSeuil, // Valeur par défaut ou à définir selon votre logique
                    'notification' => $message,
                ]);
            }
        }

        $query = DB::table('stock_produits')
            ->select('reference_id', 'produit_id', DB::raw('SUM(quantite) as quantite_total'), 'date_peremption', DB::raw('(
                SELECT sp2.prix
                FROM stock_produits sp2
                WHERE sp2.reference_id = stock_produits.reference_id
                AND sp2.produit_id = stock_produits.produit_id AND sp2.quantite > 0
                ORDER BY sp2.created_at DESC
                LIMIT 1
            ) as prix'))
            ->groupBy('reference_id', 'produit_id', 'date_peremption')
            ->having('quantite_total', '>', 0); // Déplacer la condition sur quantite_total ici

        // Ajouter des conditions de recherche si des critères sont fournis
        if ($search) {
            $query->where(function($q) use ($search) {
                $q->whereIn('reference_id', function($subQuery) use ($search) {
                    $subQuery->select('id')
                        ->from('references')
                        ->where('nom', 'LIKE', "%{$search}%")
                        ->orWhere('nom_complet', 'LIKE', "%{$search}%");
                })
                ->orWhereIn('produit_id', function($subQuery) use ($search) {
                    $subQuery->select('id')
                        ->from('produits')
                        ->where('nom', 'LIKE', "%{$search}%");
                });
            });
        }

        // Ajouter des conditions sur la quantité totale
        if ($minQuantite) {
            $query->having('quantite_total', '>=', $minQuantite);
        }
        if ($maxQuantite) {
            $query->having('quantite_total', '<=', $maxQuantite);
        }

        // Exécuter la requête
        $results = $query->get();

        // Paginer les résultats
        $stockProduits = $query->paginate(6);

        // Récupérer les références pour les afficher
        $references = Reference::whereIn('id', $stockProduits->pluck('reference_id'))->get()->keyBy('id');

        return view('stock_produit.index', compact('stockProduits', 'references'));
    }



    public function update(Request $request, StockProduit $ligneProduit)
    {
        $request->validate([
            'produit_id' => 'required|exists:produits,id',
            'reference_id' => 'required|exists:references,id',
            'quantite' => 'required|integer',
        ]);

        $ligneProduit->update($request->all());
        return redirect()->route('ligneProduits.index')->with('success', 'Ligne de produit mise à jour avec succès.');
    }

    public function destroy(StockProduit $ligneProduit)
    {
        $ligneProduit->delete();
        return redirect()->route('ligneProduits.index')->with('success', 'Ligne de produit supprimée avec succès.');
    }


    public function getSeuil($id)
    {
        $alerteStock = AlerteStock::where('reference_id', $id)->first();

        if ($alerteStock) {
            return response()->json(['seuil' => $alerteStock->quantite_seuil]);
        }

        return response()->json(['seuil' => null], 404); // Si le seuil n'existe pas
    }

}