<?php

namespace App\Http\Controllers;

use App\Models\AlerteStock;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
class AlerteStockController extends Controller
{

    public function __construct()
    {
        // Appliquer le middleware can pour restreindre l'accès en fonction des permissions
        $this->middleware('can:alerte.view')->only('index');
        $this->middleware('can:approvisionnement.create')->only('index');


    }
   
    public function index()
{
    // Récupérer toutes les alertes de stock avec les références associées
    $alertes = AlerteStock::with('references')->get();

    // Compter le nombre d'alertes
    $nombreAlertes = AlerteStock::count();

    // Retourner la vue avec les données des alertes et le nombre d'alertes
    return view('alertes.index', ['alertes' => $alertes, 'nombreAlertes' => $nombreAlertes]);
}

}
