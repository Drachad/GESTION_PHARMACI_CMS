<?php

namespace App\Http\Controllers;

use App\Models\AlerteStock;
use App\Models\Reference;
use App\Models\Produit;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller ;
class ReferenceController extends Controller
{
    public function __construct()
    {
        // Appliquer le middleware can pour restreindre l'accès en fonction des permissions
        $this->middleware('can:reference.view')->only('index', 'show');
        $this->middleware('can:reference.create')->only('create', 'store');
        $this->middleware('can:reference.edit')->only('edit', 'update');
        $this->middleware('can:reference.delete')->only('destroy');
    }

    // Commande: php artisan make:controller ReferenceController

    public function index()
    {
        $references = Reference::paginate(5);
        return view('references.index', compact('references'));
    }

    public function create()
    {
        $produits=Produit::all();
        $donnees = Reference::pluck('nom', 'id'); // Récupère les données de la base de données
        return view('references.create',compact('produits','donnees'));
    }

    public function store(Request $request)
    {
        // dd($request->input('hidden_id'));
        $validatedData = $request->validate([

            'nom' => 'required', // Validation pour des noms multiples (s'ils existent)
            'produit_id' => 'required|integer|exists:produits,id', // Validation pour l'ID du produit
            'quantite_seuil' => 'required|integer|min:0', // Le seuil doit être fourni
        ], [
            'produit_nom.required' => 'choisir une reference.',

            'produit_id.required' => 'Veuillez sélectionner un produit.',
            'quantite_seuil.required'=>'Veuillez Fournir une quantité seuil partant de 0 en allant',

        ]);
        $nom = $request->input('nom');
        if ($nom == 'autre') {
            $request->validate(['donnees_autre' => 'required',]);
        $nom = $request->input('donnees_autre');
    }

    $reference=Reference::create([

            'nom'=>$nom,

            'produit_id'=>$validatedData['produit_id']
        ]);

        AlerteStock::create([
            'reference_id' => $reference->id,
            'quantite' => 0, // Quantité initiale
            'quantite_seuil' => $validatedData['quantite_seuil'], // Quantité seuil définie
            'notification' => '', // Notification vide par défaut
        ]);

        // if ($request->filled('redirect_to')) {  // Utilisation de filled() pour vérifier si le champ est bien présent et non vide.
        //     return redirect($request->input('redirect_to'))
        //            ->with('success', 'references créée avec succès.');
        // }
        return redirect()->route('references.index')->with('success', 'Référence créée avec succès.');
    }

    public function show(Reference $reference)
    {
        $produits=Produit::all();
        return view('references.show', compact('reference','produits'));
    }

    public function edit(Reference $reference)
    {
        $produits=Produit::all();
        return view('references.edit', compact('reference','produits'));
    }

    public function update(Request $request, Reference $reference)
    {
        $validatedData = $request->validate([
            'nom' => 'required|string|max:255', // Validation pour des noms multiples (s'ils existent)
            'produit_id' => 'required|string', // Validation pour le champ de nom du produit
            'quantite_seuil' => 'nullable|integer|min:0', // La quantité seuil est optionnelle lors de la modification
        ], [
            'nom.required' => 'Veuillez entrer le nom du produit.',
            'produit_id.required' => 'Veuillez sélectionner un produit.',
            'quantite_seuil.required'=>'Veuillez Fournir une quantité seuil partant de 0 en allant',

        ]);

        $reference->update([
            'nom'=>$validatedData['nom'],
            'produit_id'=>$validatedData['produit_id']
        ]);
        if ($request->filled('quantite_seuil')) {
            $reference->alerte->update([
                'quantite_seuil' => $validatedData['quantite_seuil'],
            ]);
        }
        
        return redirect()->route('references.index')->with('success', 'Référence mise à jour avec succès.');
    }

    public function destroy(Reference $reference)
    {
        $reference->delete();
        return redirect()->route('references.index')->with('success', 'Référence supprimée avec succès.');
    }


}
