<?php

namespace App\Http\Controllers;

use App\Models\Patient;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller ;
use Illuminate\Support\Facades\Auth;

class PatientController extends Controller
{
    /**
     * Display a listing of the resource.
     */

     public function __construct(){
        $this->middleware('auth');
        // dd(Auth::user());
          // Appliquer des autorisations sur chaque méthode
        $this->middleware('can:patients.view')->only(['index', 'show']);
        $this->middleware('can:patients.create')->only(['create', 'store']);
        $this->middleware('can:patients.edit')->only(['edit', 'update']);
        $this->middleware('can:patients.delete')->only(['destroy']);
     }
    public function index()
{
    $user = Auth::user();
    $paginate_number = 5;
    $query = Patient::query();
    // dd($user);
    $patients =  $query->paginate($paginate_number);
    // 10 patients par page
    return view('patients.index', compact('patients'));
}


    /**
     * Show the form for creating a new resource.
     */
    public function create()
{
    return view('patients.create');
}

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'nom' => 'required|string|max:255|regex:/^[a-zA-Z][a-zA-Z\s-]*$/',
            'prenom' => 'required|string|max:255|regex:/^[a-zA-Z][a-zA-Z\s-]*$/',
           'contact' => 'required|string|max:255|regex:/^\+?228\d{2}[-\s]?\d{2}[-\s]?\d{2}[-\s]?\d{2}$/',
        ],[
            'nom.required' => 'Le nom est obligatoire.',
            'nom.regex' => 'Le nom doit commencer par une lettre.',
            'prenom.required' => 'Le prénom est obligatoire.',
            'contact.required' => 'Le contact est obligatoire.',
            'contact.regex' => 'Le contact doit être un numéro de téléphone togolais valide.',
        ]);


        Patient::create($validatedData);

        return redirect()->route('patients.index')->with('success', 'Patient créé avec succès.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Patient $patient)
    {
        return view('patients.show', compact('patient'));
    }
    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Patient $patient)
    {
        return view('patients.edit', compact('patient'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Patient $patient)
    {
        $validatedData = $request->validate([
            'nom' => 'required|string|max:255|regex:/^[a-zA-Z][a-zA-Z\s-]*$/',
            'prenom' => 'required|string|max:255|regex:/^[a-zA-Z][a-zA-Z\s-]*$/',
            'contact' => 'required|string|max:255|regex:/^\+?228\d{2}[-\s]?\d{2}[-\s]?\d{2}[-\s]?\d{2}$/',
        ],[
            'nom.required' => 'Le nom est obligatoire.',
            'nom.regex' => 'Le nom doit commencer par une lettre.',
            'prenom.required' => 'Le prénom est obligatoire.',
            'contact.required' => 'Le contact est obligatoire.',
            'contact.regex' => 'Le contact doit être un numéro de téléphone togolais valide.',
        ]);


        $patient->update($validatedData);

        return redirect()->route('patients.index')->with('success', 'Patient mis à jour avec succès.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Patient $patient)
    {
        $patient->delete();

        return redirect()->route('patients.index')->with('success', 'Patient supprimé avec succès.');
    }
}












