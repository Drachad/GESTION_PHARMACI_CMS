<?php

namespace App\Http\Controllers;

use App\Models\Produit;
use App\Models\StockProduit;
use Illuminate\Http\Request;

class ExpiredProductController extends Controller
{
    public function index()
    {
        // Récupère les produits expirés
        $expiredProducts = StockProduit::where('date_peremption', '<', now())->get();

        return view('produits.expired', compact('expiredProducts'));
    }

    public function destroy($id)
    {
        $product = StockProduit::find($id);

        if ($product) {
            dd($product->delete());
            return redirect()->route('expired.products.index')->with('success', 'Produit supprimé avec succès.');
        }

        return redirect()->route('expired.products.index')->with('error', 'Produit non trouvé.');
    }
}
