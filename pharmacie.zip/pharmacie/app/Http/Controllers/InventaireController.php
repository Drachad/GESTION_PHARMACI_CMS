<?php

namespace App\Http\Controllers;

use App\Models\Approvisionnement;
use App\Models\LigneApprovisionnement;
use App\Models\StockProduit;
use App\Models\Reference;
use App\Models\Vente;
use App\Models\LigneDeVente;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

use Barryvdh\DomPDF\Facade\Pdf;

use Carbon\Carbon;

class InventaireController extends Controller
{


    public function __construct()
    {
        // Appliquer des autorisations sur chaque méthode
        $this->middleware('can:expired-products.view')->only('index');
        $this->middleware('can:expired-products.delete')->only('destroy');
        $this->middleware('can:inventaire')->only('inventaire');
    }
    public function index()
    {

        return view("inventaire.index");
    }

    public function inventaire(Request $request)
    {
        // Validation des données d'entrée
        $request->validate([
            'type_inventaire' => 'required|string',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after:start_date',
        ], [
            'type_inventaire.required' => 'Le type d\'inventaire est obligatoire.',
            'type_inventaire.string' => 'Le type d\'inventaire doit être une chaîne de caractères valide.',
            'start_date.required' => 'La date de début est obligatoire.',
            'start_date.date' => 'La date de début doit être une date valide.',
            'end_date.required' => 'La date de fin est obligatoire.',
            'end_date.date' => 'La date de fin doit être une date valide.',
            'end_date.after' => 'La date de fin doit être strictement supérieure à la date de début.',
        ]);

        // Récupérer les dates et le type d'inventaire
        $typeInventaire = $request->input('type_inventaire');
        $startDate = $request->input('start_date');
        $endDate = $request->input('end_date');

        // Initialiser les variables pour le graphique
        $labels = [];
        $data = [];
        $resultats = collect();

        // Récupérer les données en fonction du type d'inventaire avec pagination
        switch ($typeInventaire) {
            case 'approvisionnement':
                $resultats = Approvisionnement::whereBetween('date', [$startDate, $endDate])
                                              ->with('lignes.ligneProduit')
                                              ->paginate(10); // Paginer les résultats
                $resultatsCollection = $resultats->getCollection(); // Convertir en collection
                $labels = $resultatsCollection->pluck('lignes.ligneProduit.references.nom_complet')->unique()->values()->toArray(); // Noms des produits
                $data = $resultatsCollection->groupBy('ligneproduit_id')->map->sum('quantite')->values()->toArray();
                break;

            case 'vente':
                $resultats = Vente::whereBetween('date', [$startDate, $endDate])
                                  ->with('ligneDeVentes.ligneProduit')
                                  ->paginate(10); // Paginer les résultats
                $resultatsCollection = $resultats->getCollection(); // Convertir en collection
                $labels = $resultatsCollection->flatMap->ligneDeVentes->pluck('ligneProduit.references.nom_complet')->unique()->values()->toArray(); // Noms des produits
                $data = $resultatsCollection->flatMap->ligneDeVentes->groupBy('produit_id')->map->sum('quantite')->values()->toArray();
                break;

            case 'stock':
                $resultats = StockProduit::paginate(10); // Paginer les résultats
                $resultatsCollection = $resultats->getCollection(); // Convertir en collection
                $labels = $resultatsCollection->pluck('references.nom_complet')->unique()->values()->toArray(); // Noms des produits
                $data = $resultatsCollection->pluck('quantite')->values()->toArray();
                break;

            case 'perime':
                $resultats = StockProduit::where('date_peremption', '<=', $endDate)
                                         ->where('quantite', '>', 0)
                                         ->paginate(10); // Paginer les résultats
                $resultatsCollection = $resultats->getCollection(); // Convertir en collection
                $labels = $resultatsCollection->pluck('references.nom_complet')->unique()->values()->toArray(); // Noms des produits
                $data = $resultatsCollection->pluck('quantite')->values()->toArray();
                break;

            default:
                return back()->withErrors(['type_inventaire' => 'Type d\'inventaire non valide.']);
        }

        // Structurer les données pour Chart.js
        $chartData = [
            'labels' => $labels,
            'datasets' => [
                [
                    'label' => ucfirst($typeInventaire), // Utiliser le type d'inventaire comme étiquette
                    'data' => $data,
                    'backgroundColor' => 'rgba(54, 162, 235, 0.5)',
                    'borderColor' => 'rgba(54, 162, 235, 1)',
                    'borderWidth' => 1
                ]
            ]
        ];

        return view('layouts.components.contenu', [
            'typeInventaire' => $typeInventaire,
            'startDate' => $startDate,
            'endDate' => $endDate,
            'chartData' => $chartData,
            'resultats' => $resultats,
        ]);
    }


    

public function genererInventairePDF(Request $request)
{
    $request->validate([
        'date_debut' => 'required|date',
        'date_fin' => 'required|date|after_or_equal:date_debut',
    ]);

    $dateDebut = $request->input('date_debut');
    $dateFin = $request->input('date_fin');

    $references = Reference::with('produit', 'stockProduits')
        ->get()
        ->map(function ($reference) use ($dateDebut, $dateFin) {
            if (!$reference || !$reference->stockProduits || !$reference->produit) {
                return null;
            }

            $quantiteApprovisionnee = LigneApprovisionnement::whereHas('ligneProduit', function($query) use ($reference) {
                $query->where('reference_id', $reference->id);
            })
            ->whereBetween('created_at', [$dateDebut, $dateFin])
            ->sum('quantite');

            $quantiteVendue = LigneDeVente::whereHas('ligneProduit', function($query) use ($reference) {
                $query->where('reference_id', $reference->id);
            })
            ->whereBetween('created_at', [$dateDebut, $dateFin])
            ->sum('quantite');

            $stockRestant = $reference->stockProduits->sum('quantite');

            return [
                'nom_reference' => $reference->nom_complet ?? $reference->nom,
                'produit' => $reference->produit->nom ?? 'Inconnu',
                'quantite_approvisionnee' => $quantiteApprovisionnee,
                'quantite_vendue' => $quantiteVendue,
                'stock_restant' => $stockRestant,
            ];
        })
        ->filter();

    // Générer le PDF à partir de la vue
    $pdf = Pdf::loadView('latex.stock_inventaire', compact('references', 'dateDebut', 'dateFin'));

    // Télécharger le fichier PDF
    return $pdf->download('inventaire_' . $dateDebut . '_au_' . $dateFin . '.pdf');
}


}

