<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Fournisseur;
use Illuminate\Routing\Controller ;
class FournisseurController extends Controller
{
    public function __construct()
    {
        // Appliquer des autorisations sur chaque méthode
        $this->middleware('can:fournisseurs.view')->only(['index', 'show']);
        $this->middleware('can:fournisseurs.create')->only(['create', 'store']);
        $this->middleware('can:fournisseurs.edit')->only(['edit', 'update']);
        $this->middleware('can:fournisseurs.delete')->only(['destroy']);
    }
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $fournisseurs=Fournisseur::paginate(6);
        // dd($produits); 
        return view('fournisseurs.index',compact('fournisseurs',));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('fournisseurs.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validateData=$request->validate([
            'nom' => 'required|string',
            'contact' => 'required',
        ]);
        Fournisseur::create($validateData);
        // if ($request->filled('redirect_to')) {  // Utilisation de filled() pour vérifier si le champ est bien présent et non vide.
        //     return redirect($request->input('redirect_to'))
        //            ->with('success', 'Catégorie créée avec succès.');
        // }

        return redirect()->route('fournisseurs.index');

    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Fournisseur $fournisseur)
    {
       return view('fournisseurs.edite',compact('fournisseur'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request,Fournisseur $fournisseur)
    {
        $validateData=$request->validate([
            'nom' => 'required|string',
            'contact' => 'required',
        ]);

        $fournisseur->update($validateData);
        return redirect()->route('fournisseurs.index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Fournisseur $fournisseur)
    {
        $fournisseur->delete();
        return redirect()->route('fournisseurs.index');
    }
}
