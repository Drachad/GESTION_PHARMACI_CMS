<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Approvisionnement;
use App\Models\LigneApprovisionnement;
use App\Models\Fournisseur;
use App\Models\Produit;
use App\Models\StockProduit;
use Illuminate\Routing\Controller ;
use App\Models\Reference;
use Illuminate\Support\Facades\Auth;


class ApprovisionnementController extends Controller
{
    public function __construct()
    {
        // Appliquer le middleware can pour restreindre l'accès en fonction des permissions
        $this->middleware('can:approvisionnement.view')->only('index', 'show');
        $this->middleware('can:approvisionnement.create')->only('create', 'store');
        $this->middleware('can:approvisionnement.edit')->only('edit', 'update');
        $this->middleware('can:approvisionnement.delete')->only('destroy');
    }
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $approvs=Approvisionnement::paginate(6);
        //  dd($approvs); 
        return view('approvisionnements.index',compact('approvs',));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $fournisseurs=Fournisseur::all();
        $produits=Produit::all();
        $references=Reference::all();
        return view('approvisionnements.create',compact('fournisseurs','produits','references'));
    }

    /**
     * Store a newly created resource in storage.
     */
    
    public function store(Request $request)
{
    // Validation des données d'entrée
     $validatedData = $request->validate([
        'fournisseur_id' => 'required|exists:fournisseurs,id',
        'refs_id.*' => 'required|exists:references,id',
        'prixs.*' => 'required|numeric|min:0',
        'quantite.*' => 'required|integer|min:1',
        'date_peremption.*' => 'required|date|after:today',

    ], [
        'fournisseur_id.required' => 'Veuillez sélectionner un fournisseur.',
        'fournisseur_id.exists' => 'Le fournisseur sélectionné n\'est pas valide.',
        'prixs.*.required' => 'prix doit etre minimun 0.',
        'refs_id.*.required' => 'Veuillez sélectionner une référence de produit.',
        'refs_id.*.exists' => 'La référence de produit sélectionnée n\'est pas valide.',
        'quantite.*.required' => 'Veuillez entrer la quantité.',
        'quantite.*.integer' => 'La quantité doit être un nombre entier.',
        'quantite.*.min' => 'La quantité doit être au moins de 1.',
        'date_peremption.*.required' => 'Veuillez entrer une date de péremption.',
        'date_peremption.*.date' => 'La date de péremption doit être une date valide.',
        'date_peremption.*.after' => 'La date de péremption doit être postérieure à aujourd\'hui.',
    ]);


    // Récupération de l'utilisateur connecté
    $utilisateur = Auth::user();

    // Création de l'approvisionnement
    $appro = Approvisionnement::create([
        'date' => now(),
        'fournisseur_id' => $validatedData['fournisseur_id'],
        'user_id' => $utilisateur->id,
    ]);

    // Parcours des lignes d'approvisionnement pour créer les entrées associées
    foreach ($validatedData['refs_id'] as $index => $ref_id) {
        // Récupération de la référence
        $reference = Reference::findOrFail($ref_id);
        $produit_id = $reference->produit->id;
        
        // Création du stock produit
        $stock = StockProduit::create([
            'produit_id' => $produit_id,
            'reference_id' => $reference->id,
            'prix'=>$validatedData['prixs'][$index],
            'quantite' => $validatedData['quantite'][$index],
            'date_peremption' => $validatedData['date_peremption'][$index],
        ]);

        // Création de la ligne d'approvisionnement
        LigneApprovisionnement::create([
            'quantite' => $validatedData['quantite'][$index],
            'ligneProduit_id' => $stock->id,
            'approvisionnement_id' => $appro->id,
        ]);
    }

    
    // Redirection vers la liste des approvisionnements avec un message de succès
    return redirect()->route('approvisionnements.index')
                     ->with('success', 'Approvisionnement créé avec succès.');
}


    /**
     * Display the specified resource.
     */
    public function show(Approvisionnement $approvisionnement)
    {


        $lignes=$approvisionnement->lignes()->paginate(5);
        return view('approvisionnements.show',compact('lignes'));



    }
    

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Approvisionnement $approvisionnement)
    {
        $fournisseurs=Fournisseur::all();
        $stock=StockProduit::all();
        $references=Reference::all();
        return view('approvisionnements.edit',compact('approvisionnement','fournisseurs','references','stock'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
{
          
    // Validation des données d'entrée
    $validatedData = $request->validate([
        'hidden_id' => 'required|exists:fournisseurs,id',
        'refs_id.*' => 'required|exists:references,id',
        'prixs.*' => 'required|numeric|min:0',
        'quantite.*' => 'required|integer|min:1',
        'date_peremption.*' => 'required|date|after:today',
    ], [
        'hidden_id.required' => 'Veuillez sélectionner un fournisseur.',
        'fournisseur_id.exists' => 'Le fournisseur sélectionné n\'est pas valide.',
        'prixs.*.required' => 'Le prix doit être au moins 0.',
        'refs_id.*.required' => 'Veuillez sélectionner une référence de produit.',
        'refs_id.*.exists' => 'La référence de produit sélectionnée n\'est pas valide.',
        'quantite.*.required' => 'Veuillez entrer la quantité.',
        'quantite.*.integer' => 'La quantité doit être un nombre entier.',
        'quantite.*.min' => 'La quantité doit être au moins de 1.',
        'date_peremption.*.required' => 'Veuillez entrer une date de péremption.',
        'date_peremption.*.date' => 'La date de péremption doit être une date valide.',
        'date_peremption.*.after' => 'La date de péremption doit être postérieure à aujourd\'hui.',
    ]);
        
    // Trouver l'approvisionnement existant
    $appro = Approvisionnement::findOrFail($id);

    // Mise à jour de l'approvisionnement
    $appro->update([
        'fournisseur_id' => $validatedData['hidden_id'],
        'date' => now(), // Vous pouvez utiliser une date différente si nécessaire
    ]);

    // Supprimer les lignes d'approvisionnement existantes
    $appro->lignes()->delete();

    // Parcours des lignes d'approvisionnement pour mettre à jour les entrées associées
    foreach ($validatedData['refs_id'] as $index => $ref_id) {
        // Récupération de la référence
        $reference = Reference::findOrFail($ref_id);
        $produit_id = $reference->produit->id;

        // Création ou mise à jour du stock produit
        $stock = StockProduit::updateOrCreate(
            ['produit_id' => $produit_id, 'reference_id' => $reference->id],
            [
                'prix' => $validatedData['prixs'][$index],
                'quantite' => $validatedData['quantite'][$index],
                'date_peremption' => $validatedData['date_peremption'][$index],
            ]
        );

        // Création de la ligne d'approvisionnement
        LigneApprovisionnement::create([
            'quantite' => $validatedData['quantite'][$index],
            'ligneProduit_id' => $stock->id,
            'approvisionnement_id' => $appro->id,
        ]);
    }

    // Redirection vers la liste des approvisionnements avec un message de succès
    return redirect()->route('approvisionnements.index')
                     ->with('success', 'Approvisionnement mis à jour avec succès.');
}


    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Approvisionnement $Approvisionnement)
    {
        $Approvisionnement->delete();
        return redirect()->route("approvisionnements.index");
    }
}