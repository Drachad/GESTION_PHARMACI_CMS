<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Fournisseur extends Model
{
    use HasFactory;

    protected $fillable = ['nom', 'contact'];

    protected $primarykey=['id'];

    // Relation avec Approvisionnement
    public function approvisionnements()
    {
        return $this->hasMany(Approvisionnement::class);
    }
}
