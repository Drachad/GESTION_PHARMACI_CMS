<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Reference extends Model
{
    use HasFactory;

    protected $fillable = ['nom','produit_id','nom_complet'];

    protected $primarykey='id';


    protected static function boot()
{
    parent::boot();


    // Lors de la mise à jour d'une référence existante
    static::updating(function ($reference) {
        $produit = $reference->Produit; // Charge le modèle Produit associé
        if ($produit) {
            $reference->nom_complet = $produit->nom . ' ' . $reference->nom;
        }
    });
}

    public function Produit()
    {
        return $this->belongsTo(Produit::class);
    }
    public function alerte()
    {
        return $this->hasOne(AlerteStock::class, 'reference_id'); // Une référence a une seule alarme
    }
    public function ligneProduits()
    {
        return $this->hasMany(StockProduit::class,'produit_id');
    }
    public function stockProduits()
{
    return $this->hasMany(StockProduit::class, 'reference_id');
}


}
