<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Produit extends Model
{
    use HasFactory;




    protected $fillable = ['nom', 'categorie_id'];


    protected $primarykey='id';




    public function categorie()
    {
        return $this->belongsTo(Categorie::class);
    }

    public function references()
{
    return $this->hasMany(Reference::class);
}

public function reference()
{
    return $this->hasMany(Reference::class, 'produit_id', 'id');
}

    public function ligneProduits()
    {
        return $this->hasMany(StockProduit::class);
    }


}
