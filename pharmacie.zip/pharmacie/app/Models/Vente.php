<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Vente extends Model
{
    use HasFactory;

    protected $fillable = ['date', 'totale', 'patient_id', 'user_id'];

    protected $primarykey=['id'];

    // Relation avec User
    public function user()
    {
        return $this->belongsTo(User::class,"user_id");
    }

    // Relation avec Patient
    public function patient()
    {
        return $this->belongsTo(Patient::class,"patient_id");
    }

    // Relation avec LigneDeVente
    public function ligneDeVentes()
    {
        return $this->hasMany(LigneDeVente::class);
}
    protected function casts(): array
    {
        return [
            'date' => 'datetime',
        ];
    }


}
