<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LigneDeVente extends Model
{
    use HasFactory;



    protected $primarykey=['id'];

    protected $fillable = ['quantite', 'prix', 'produit_id', 'vente_id'];

    public function ligneProduit()
    {
        return $this->belongsTo(StockProduit::class,'produit_id');
    }
    // public function produit()
    // {
    //     return $this->belongsTo(Produit::class, 'produit_id');
    // }

    public function produit()
    {
        return $this->belongsTo(Produit::class, 'produit_id');
    }
    public function vente()
    {
        return $this->belongsTo(Vente::class);
    }

}
