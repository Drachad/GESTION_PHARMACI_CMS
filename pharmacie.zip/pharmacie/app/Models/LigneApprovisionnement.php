<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LigneApprovisionnement extends Model
{
    use HasFactory;



    protected $primaryKey='id';

    protected $fillable = ['quantite', 'ligneProduit_id', 'approvisionnement_id'];

    public function ligneProduit()
{
    return $this->belongsTo(StockProduit::class, 'ligneProduit_id');
}
public function references()
{
    return $this->hasMany(Reference::class, 'produit_id', 'id');
}

    public function approvisionnement()
    {
        return $this->belongsTo(Approvisionnement::class);
    }
}
