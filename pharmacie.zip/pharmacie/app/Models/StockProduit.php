<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StockProduit extends Model
{
    use HasFactory;


    protected $fillable = ['produit_id', 'lot', 'quantite', 'date_peremption','reference_id','prix'];

    protected $primarykey='id';

    public function produit()
    {
        return $this->belongsTo(Produit::class);
    }
    
    public function references()
    {
        return $this->belongsTo(Reference::class, 'reference_id');
    }

    public function ligneApprovisionnements()
    {
        return $this->hasMany(LigneApprovisionnement::class);
    }

    public function ligneVentes()
    {
        return $this->hasMany(LigneDeVente::class);
    }



    public function isExpired()
    {
        return $this->date_peremption < now();
    }


}
