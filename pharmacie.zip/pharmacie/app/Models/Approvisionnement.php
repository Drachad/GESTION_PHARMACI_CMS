<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Approvisionnement extends Model
{
    use HasFactory;

    protected $fillable = ['date', 'fournisseur_id', 'user_id'];
    protected $primaryKey="id";
    // Relation avec User
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    // Relation avec Fournisseur
    public function fournisseur()
    {
        return $this->belongsTo(Fournisseur::class);
    }
    public function produit()
    {
        return $this->belongsTo(Produit::class);
    }
    // Relation avec LigneApprovisionnement
    public function lignes()
{
    return $this->hasMany(LigneApprovisionnement::class);
}

}
