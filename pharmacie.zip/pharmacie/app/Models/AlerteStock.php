<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AlerteStock extends Model
{
    use HasFactory;


    protected $fillable = [
        'reference_id',
        'quantite',
        'notification',
        'quantite_seuil',
    ];

    public function references()
    {
        return $this->belongsTo(Reference::class,'reference_id');
    }
}
