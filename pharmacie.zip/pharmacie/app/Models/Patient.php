<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Patient extends Model
{
    use HasFactory;

    protected $fillable = ['nom', 'prenom', 'contact'];

    protected $primarykey=['id'];

    // Relation avec Vente
    public function ventes()
    {
        return $this->hasMany(Vente::class);
    }
}
