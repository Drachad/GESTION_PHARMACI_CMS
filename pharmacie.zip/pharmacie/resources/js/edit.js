document.addEventListener('DOMContentLoaded', function () {
    // Charger les lignes de vente depuis le stockage local au démarrage de la page.
    loadLignesVente();

    const productOptions = JSON.parse(document.getElementById('productOptions').value);
    const ligneVenteBody = document.getElementById('ligneVenteBody');
    const ajouterLigneBtn = document.getElementById('ajouterLigne');
    const soumettreVenteBtn = document.getElementById('soumettreVente');
    const patientIdInput = document.getElementById('patient_id');
    const produitSelect = document.getElementById('produit');
    const quantiteInput = document.getElementById('quantite');
    const prixStockDiv = document.getElementById('prix-stock');

    // Ajout d'une nouvelle ligne lors du clic sur le bouton 'Ajouter'.
    ajouterLigneBtn.addEventListener('click', function (e) {
        e.preventDefault();
        addLigneVente();
    });

    // Soumission de la vente lors du clic sur le bouton 'Soumettre'.
    soumettreVenteBtn.addEventListener('click', function (e) {
        e.preventDefault();

        const lignesVente = JSON.parse(localStorage.getItem('lignesVente')) || [];
        if (lignesVente.length === 0) {
            Swal.fire({
                title: "Erreur",
                text: "Vous devez ajouter au moins un produit à la vente.",
                icon: "error"
            });
            return;
        } else {
            Swal.fire({
                title: "Vous allez enregistrer cette vente !?",
                showDenyButton: true,
                showCancelButton: true,
                confirmButtonText: "Enregistrer",
                denyButtonText: `Ne pas Enregistrer`
            }).then((result) => {
                if (result.isConfirmed) {
                    const invalidLignes = lignesVente.some(ligne => {
                        const produit = productOptions.find(p => p.id == ligne.produitId);
                        return produit && ligne.quantite > produit.quantite;
                    });
                    if (invalidLignes) {
                        Swal.fire({
                            title: "Erreur",
                            text: "Certaines quantités dépassent le stock disponible",
                            icon: "error"
                        });
                        return;
                    }

                    const form = document.querySelector('form');
                    lignesVente.forEach((ligne, index) => {
                        const produitInput = document.createElement('input');
                        produitInput.type = 'hidden';
                        produitInput.name = `lignes[${index}][id]`;
                        produitInput.value = ligne.produitId;
                        form.appendChild(produitInput);

                        const quantiteInput = document.createElement('input');
                        quantiteInput.type = 'hidden';
                        quantiteInput.name = `lignes[${index}][quantite]`;
                        quantiteInput.value = ligne.quantite;
                        form.appendChild(quantiteInput);
                    });

                    const patientInput = document.createElement('input');
                    patientInput.type = 'hidden';
                    patientInput.name = 'patient_id';
                    patientInput.value = patientIdInput.value;
                    form.appendChild(patientInput);

                    localStorage.removeItem('lignesVente');
                    form.submit();

                    Swal.fire("Sauvegarder!", "", "success");
                } else if (result.isDenied) {
                    Swal.fire("Les modifications ne sont pas enregistrées", "", "info");
                }
            });
        }
    });

    // Fonction pour charger les lignes de vente depuis le stockage local.
    function loadLignesVente() {
        const lignesVente = JSON.parse(localStorage.getItem('lignesVente')) || [];
        lignesVente.forEach(ligne => {
            addLigneVente(ligne);
        });
    }

    // Ajout ou modification de lignes de vente.
    function addLigneVente(ligne = null) {
        const produitId = ligne ? ligne.produitId : produitSelect.value;
        if (!produitId) {
            console.error('L\'ID du produit est undefined ou non défini.');
            return;
        }

        const produit = productOptions.find(p => p.id == produitId);
        if (!produit) {
            console.error(`Produit avec l'ID ${produitId} introuvable.`);
            return;
        }

        const quantite = ligne ? ligne.quantite : parseInt(quantiteInput.value);
        // if (!quantite || isNaN(quantite) || quantite <= 0) {
        //     Swal.fire({
        //         title: "Erreur",
        //         text: "Veuillez fournir une quantité valide.",
        //         icon: "error"
        //     });
        //     return;
        // }

        if (quantite > produit.quantite) {
            Swal.fire({
                title: "Erreur",
                text: `La quantité saisie (${quantite}) dépasse le stock disponible (${produit.quantite}).`,
                icon: "error"
            });
            return;
        }

        // Vérification si la ligne de produit existe déjà pour la mise à jour.
        const existingRow = Array.from(ligneVenteBody.children).find(row => row.dataset.produitId == produitId);
        if (existingRow) {
            const existingQuantiteCell = existingRow.querySelector('td:nth-child(3)');
            existingQuantiteCell.textContent = quantite;

            const totalCell = existingRow.querySelector('td:nth-child(4)');
            totalCell.textContent = (produit.prix * quantite).toFixed(2) + ' FCFA';

            updateLigneVente(produitId, quantite);
        } else {
            const row = createLigneVenteRow(produit, quantite);
            row.dataset.produitId = produitId;
            ligneVenteBody.appendChild(row);

            storeLigneVente({ produitId, quantite });
        }

        // Réinitialiser les champs après ajout/modification.
        produitSelect.value = '';
        quantiteInput.value = '';
        prixStockDiv.innerHTML = '';
    }

    // Création d'une nouvelle ligne de produit dans le tableau.
    function createLigneVenteRow(produit, quantite) {
        if (!produit) {
            console.error('Produit est undefined dans createLigneVenteRow');
            return;
        }

        const row = document.createElement('tr');
        row.innerHTML = `
            <td class="w-1/3 text-left py-3 px-4 sm:w-auto">${produit.produit.nom}</td>
            <td class="w-1/6 text-left py-3 px-4 sm:w-auto">${produit.prix.toFixed(2)} FCFA</td>
            <td class="w-1/6 text-left py-3 px-4 sm:w-auto">${quantite}</td>
            <td class="w-1/6 text-left py-3 px-4 sm:w-auto">${(produit.prix * quantite).toFixed(2)} FCFA</td>
            <td class="w-1/6 text-left py-3 px-4 sm:w-auto">
                <div class="flex items-center justify-end space-x-2">
                    <button class="bg-blue-500 text-white px-2 py-1 rounded-md modifier-ligne">Modifier</button>
                    <button class="bg-red-500 text-white px-2 py-1 rounded-md supprimer-ligne">Supprimer</button>
                </div>
            </td>
        `;
        return row;
    }

    // Stocker les lignes de vente dans le stockage local.
    function storeLigneVente(ligne) {
        const lignesVente = JSON.parse(localStorage.getItem('lignesVente')) || [];
        // Remplace la ligne existante par la nouvelle ou ajoute si elle n'existe pas.
        const existingIndex = lignesVente.findIndex(l => l.produitId == ligne.produitId);
        if (existingIndex !== -1) {
            lignesVente[existingIndex] = ligne;
        } else {
            lignesVente.push(ligne);
        }
        localStorage.setItem('lignesVente', JSON.stringify(lignesVente));
    }

    // Mettre à jour la ligne de vente existante.
    function updateLigneVente(produitId, quantite) {
        const lignesVente = JSON.parse(localStorage.getItem('lignesVente')) || [];
        const ligne = lignesVente.find(l => l.produitId == produitId);
        if (ligne) {
            ligne.quantite = quantite;
            localStorage.setItem('lignesVente', JSON.stringify(lignesVente));
        }
    }

    // Supprimer une ligne de vente.
    function removeLigneVente(produitId) {
        const lignesVente = JSON.parse(localStorage.getItem('lignesVente')) || [];
        const updatedLignesVente = lignesVente.filter(l => l.produitId != produitId);
        localStorage.setItem('lignesVente', JSON.stringify(updatedLignesVente));
    }

    // Modification et suppression des lignes à partir des boutons dans le tableau.
    ligneVenteBody.addEventListener('click', function (e) {
        if (e.target.classList.contains('supprimer-ligne')) {
            e.preventDefault();
            const row = e.target.closest('tr');
            const produitId = row.dataset.produitId;

            row.remove();
            removeLigneVente(produitId);
        } else if (e.target.classList.contains('modifier-ligne')) {
            e.preventDefault();
            const row = e.target.closest('tr');
            const produitId = row.dataset.produitId;
            const quantite = parseInt(row.children[2].textContent);

            // Chargement des valeurs pour modification.
            produitSelect.value = produitId;
            quantiteInput.value = quantite;

            prixStockDiv.innerHTML = `Prix: ${produit.prix.toFixed(2)} FCFA, Stock: ${produit.quantite}`;
        }
    });
});
