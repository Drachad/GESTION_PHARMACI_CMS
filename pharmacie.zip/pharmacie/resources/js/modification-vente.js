
document.addEventListener('DOMContentLoaded', function() {
    // localStorage.removeItem('lignesVente');

    const productOptions = JSON.parse(document.getElementById('productOptions').value);
    const ligneVenteBody = document.getElementById('ligneVenteBody');
    const ajouterLigneBtn = document.getElementById('ajouterLigne');
    const soumettreVenteBtn = document.getElementById('soumettreVente');
    const patientIdInput = document.getElementById('patient_id');
    const produitSelect = document.getElementById('produit');
    const quantiteInput = document.getElementById('quantite');
    const prixStockDiv = document.getElementById('prix-stock');

    loadLignesVente();

    ajouterLigneBtn.addEventListener('click', function(e) {
        e.preventDefault();
        addLigneVente();
    });

    soumettreVenteBtn.addEventListener('click', function(e) {
        e.preventDefault();
    console.log("Soumission de la vente");

    const lignesVente = JSON.parse(localStorage.getItem('lignesVente')) || [];
    console.log("lignesVente:", lignesVente);

    const lignesExistantes = Array.from(ligneVenteBody.children).map(row => ({
        produitId: row.dataset.produitId,
        quantite: parseInt(row.querySelector('td:nth-child(3)').textContent)
    }));
    console.log("lignesExistantes:", lignesExistantes);

    const allLignes = [...lignesVente, ...lignesExistantes];
    console.log("allLignes:", allLignes);

    if (allLignes.length === 0) {
        Swal.fire({
            title: "Erreur",
            text: "Vous devez avoir au moins un produit dans la vente.",
            icon: "error"
        });
        return;
    }

        Swal.fire({
            title: "Vous allez enregistrer cette vente !?",
            showDenyButton: true,
            showCancelButton: true,
            confirmButtonText: "Enregistrer",
            denyButtonText: `Ne pas Enregistrer`
        }).then((result) => {
            if (result.isConfirmed) {
                // Vérification des quantités pour toutes les lignes
                const allLignes = [...lignesVente, ...lignesExistantes];
                const invalidLignes = allLignes.some(ligne => {
                    const produit = productOptions.find(p => p.id == ligne.produitId);
                    return produit && ligne.quantite > produit.quantite;
                });

                if (invalidLignes) {
                    Swal.fire({
                        title: "Erreur",
                        text: "Certaines quantités dépassent le stock disponible",
                        icon: "error"
                    });
                    return;
                }

                // Ajout des lignes au formulaire
                const form = document.querySelector('form');
                allLignes.forEach((ligne, index) => {
                    const produitInput = document.createElement('input');
                    produitInput.type = 'hidden';
                    produitInput.name = `lignes[${index}][id]`;
                    produitInput.value = ligne.produitId;
                    form.appendChild(produitInput);

                    const quantiteInput = document.createElement('input');
                    quantiteInput.type = 'hidden';
                    quantiteInput.name = `lignes[${index}][quantite]`;
                    quantiteInput.value = ligne.quantite;
                    form.appendChild(quantiteInput);
                });

                const patientInput = document.createElement('input');
                patientInput.type = 'hidden';
                patientInput.name = 'patient_id';
                patientInput.value = patientIdInput.value;
                form.appendChild(patientInput);

                localStorage.removeItem('lignesVente');
                form.submit();

                Swal.fire("Sauvegardé!", "", "success");
            } else if (result.isDenied) {
                Swal.fire("Les modifications ne sont pas enregistrées", "", "info");
            }
        });
    });

    function loadLignesVente() {
        const lignesVente = JSON.parse(localStorage.getItem('lignesVente')) || [];
        lignesVente.forEach(ligne => {
            addLigneVente(ligne);
        });
    }

    function addLigneVente(ligne = null) {
        console.log("Début de addLigneVente", ligne);

        let produitId;
        if (ligne) {
            produitId = ligne.produitId;
        } else {
            produitId = produitSelect.value;
        }
        console.log("produitId:", produitId);

        const produit = productOptions.find(p => p.id == produitId);
        if (!produit) {
            console.error(`Produit avec l'ID ${produitId} introuvable.`);
            return;
        }

        const quantite = ligne ? ligne.quantite : parseInt(quantiteInput.value);
        if (!quantite || isNaN(quantite) || quantite <= 0) {
            Swal.fire({
                title: "Erreur",
                text: "Veuillez fournir une quantité valide.",
                icon: "error"
            });
            return;
        }

        if (quantite > produit.quantite) {
            Swal.fire({
                title: "Erreur",
                text: `La quantité saisie (${quantite}) dépasse le stock disponible (${produit.quantite}).`,
                icon: "error"
            });
            return;
        }

        const existingRow = Array.from(ligneVenteBody.children).find(row => row.dataset.produitId == produitId);
        if (existingRow) {
            updateExistingLigneVente(produitId, quantite);
        } else {
            const row = createLigneVenteRow(produit, quantite);
            row.dataset.produitId = produitId;
            ligneVenteBody.appendChild(row);
            storeLigneVente({ produitId, quantite });
        }

        produitSelect.value = '';
        quantiteInput.value = '';
        prixStockDiv.innerHTML = '';
    }
        // return produit.produit.references.map(ref => ref.nom_complet).join('');


        function createLigneVenteRow(produit, quantite) {
            if (!produit) {
                console.error('Produit est undefined dans createLigneVenteRow');
                return;
            }
            console.log('Quantité:', quantite);

            // Fonction pour obtenir le nom complet de la référence en utilisant reference_id du produit
            function getNomCompletReference(produit) {

                return produit.references ? produit.references.nom_complet : 'Unknown';
            }
            // Appeler la fonction pour obtenir le nom complet
            let nomComplet = getNomCompletReference(produit);

            // Vérification des valeurs pour débogage
            console.log('Produit:', produit);
            console.log('Produit reference_id:', produit.reference_id);
            console.log('Nom complet de la référence:', nomComplet);

            // Créer la ligne du tableau
            const row = document.createElement('tr');
            row.innerHTML = `
                <td class="w-1/3 text-left py-3 px-4 sm:w-auto">${nomComplet}</td>
                <td class="w-1/6 text-left py-3 px-4 sm:w-auto">${produit.prix.toFixed(2)} FCFA</td>
                <td class="w-1/6 text-left py-3 px-4 sm:w-auto">${quantite}</td>
                <td class="w-1/6 text-left py-3 px-4 sm:w-auto">${(produit.prix * quantite).toFixed(2)} FCFA</td>
                <td class="w-1/6 text-left py-3 px-4 sm:w-auto">
                    <div class="flex items-center justify-end space-x-2">
                        <button class="bg-blue-500 text-white px-2 py-1 rounded-md modifier-ligne">Modifier</button>
                        <button class="bg-red-500 text-white px-2 py-1 rounded-md supprimer-ligne">Supprimer</button>
                    </div>
                </td>
            `;

            return row;
        }
    function storeLigneVente(ligne) {
        const lignesVente = JSON.parse(localStorage.getItem('lignesVente')) || [];
        lignesVente.push(ligne);
        localStorage.setItem('lignesVente', JSON.stringify(lignesVente));
    }
    function updateExistingLigneVente(produitId, quantite) {
        const row = Array.from(ligneVenteBody.children).find(row => row.dataset.produitId == produitId);
        if (row) {
            const quantiteCell = row.querySelector('td:nth-child(3)');
            const totalCell = row.querySelector('td:nth-child(4)');
            const produit = productOptions.find(p => p.id == produitId);

            quantiteCell.textContent = quantite;
            totalCell.textContent = (produit.prix * quantite).toFixed(2) + ' FCFA';
        }
    }
    function updateLigneVente(produitId, quantite) {
        const lignesVente = JSON.parse(localStorage.getItem('lignesVente')) || [];
        const ligne = lignesVente.find(l => l.produitId == produitId);
        if (ligne) {
            ligne.quantite = quantite;
            localStorage.setItem('lignesVente', JSON.stringify(lignesVente));
        }
    }

    function removeLigneVente(produitId) {
        const lignesVente = JSON.parse(localStorage.getItem('lignesVente')) || [];
        const updatedLignesVente = lignesVente.filter(ligne => ligne.produitId != produitId);
        localStorage.setItem('lignesVente', JSON.stringify(updatedLignesVente));
    }

    function editLigneVente(produitId, quantite) {
        const produit = productOptions.find(p => p.id == produitId);
        if (produit) {
            produitSelect.value = produitId;
            quantiteInput.value = quantite;
            prixStockDiv.innerHTML = `
                <div class="mt-2">
                    <span>Prix: ${produit.prix.toFixed(2)} FCFA</span><br>
                    <span>Stock: ${produit.quantite}</span>
                </div>
            `;
            updateExistingLigneVente(produitId, quantite);
        }
    }
    document.getElementById('ligneVenteBody').addEventListener('click', function(e) {
        if (e.target.classList.contains('supprimer-ligne')) {
            e.preventDefault();
            const row = e.target.closest('tr');
            const produitId = row.dataset.produitId;

            // Confirmation avant suppression
            Swal.fire({
                title: 'Êtes-vous sûr ?',
                text: "Vous allez supprimer cette ligne !",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Oui, supprimer !',
                cancelButtonText: 'Annuler'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Suppression de la ligne
                    ligneVenteBody.removeChild(row);
                    removeLigneVente(produitId);

                    Swal.fire({
                        title: 'Supprimé !',
                        text: 'La ligne a été supprimée.',
                        icon: 'success'
                    });
                }
            });
        } else if (e.target.classList.contains('modifier-ligne')) {
            e.preventDefault();
            const row = e.target.closest('tr');
            const produitId = row.dataset.produitId;
            const quantite = parseInt(row.querySelector('td:nth-child(3)').textContent);
            editLigneVente(produitId, quantite);
            ligneVenteBody.removeChild(row);
            removeLigneVente(produitId);
        }
    });



});
