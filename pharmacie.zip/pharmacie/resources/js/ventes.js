// document.addEventListener('DOMContentLoaded', function() {
//     localStorage.removeItem('lignesVente');

//     const productOptions = JSON.parse(document.getElementById('productOptions').value);
//     const ligneVenteBody = document.getElementById('ligneVenteBody');
//     const ajouterLigneBtn = document.getElementById('ajouterLigne');
//     const soumettreVenteBtn = document.getElementById('soumettreVente');
//     const patientIdInput = document.getElementById('patient_id');
//     const produitSelect = document.getElementById('produit');
//     const quantiteInput = document.getElementById('quantite');
//     const prixStockDiv = document.getElementById('prix-stock');


//     loadLignesVente();

//     ajouterLigneBtn.addEventListener('click', function(e) {
//         e.preventDefault();
//         addLigneVente();
//     });

//     soumettreVenteBtn.addEventListener('click', function(e) {
//         e.preventDefault();

//         const lignesVente = JSON.parse(localStorage.getItem('lignesVente')) || [];
//         console.log(lignesVente);
//         if (lignesVente.length === 0 ) {
//             console.log('Lignes de vente:', lignesVente);
// console.log('Patient ID:', patientIdInput.value);

//             Swal.fire({
//                 title: "Erreur",
//                 text: "Vous devez ajouter au moins un produit à la vente.",
//                 icon: "error"
//               });
//             return;
//         }
//         else{

//               Swal.fire({
//                 title: "Vous allez enregistrer cette vente !?",
//                 showDenyButton: true,
//                 showCancelButton: true,
//                 confirmButtonText: "Enregistrer",
//                 denyButtonText: `Ne pas Enregistrer`
//               }).then((result) => {
//                  if (result.isConfirmed) {





//                     const invalidLignes = lignesVente.some(ligne => {
//                     const produit = productOptions.find(p => p.id == ligne.produitId);
//                     return produit && ligne.quantite > produit.quantite;
//                 });
//                 if (invalidLignes) {

//                     Swal.fire({
//                         title: "Erreur",
//                         text: "Certaines quantités dépassent le stock disponible",
//                         icon: "error"
//                       });
//                     return;
//                 }

//                 const form = document.querySelector('form');
//                 lignesVente.forEach((ligne, index) => {
//                     const produitInput = document.createElement('input');
//                     produitInput.type = 'hidden';
//                     produitInput.name = `lignes[${index}][id]`;
//                     produitInput.value = ligne.produitId;
//                     form.appendChild(produitInput);

//                     const quantiteInput = document.createElement('input');
//                     quantiteInput.type = 'hidden';
//                     quantiteInput.name = `lignes[${index}][quantite]`;
//                     quantiteInput.value = ligne.quantite;
//                     form.appendChild(quantiteInput);

//                      // Ajouter un champ caché pour le lot
//                     const lotInput = document.createElement('input');
//                     lotInput.type = 'hidden';
//                     lotInput.name = `lignes[${index}][lot]`;
//                     lotInput.value = ligne.lot;  // Assurez-vous que le lot est bien stocké dans `lignesVente`
//                     form.appendChild(lotInput);
//                 });

//                 const patientInput = document.createElement('input');
//                 patientInput.type = 'hidden';
//                 patientInput.name = 'patient_id';
//                 patientInput.value = patientIdInput.value;
//                 form.appendChild(patientInput);
//                 localStorage.removeItem('lignesVente');
//                 form.submit();

//                 Swal.fire("Sauvegarder!", "", "success")


//                ;

//             }else if (result.isDenied) {
//                 Swal.fire("Les modifications ne sont pas enregistrées", "", "info");
//               }
//             });
//         }

//     });



//     function loadLignesVente() {
//         const lignesVente = JSON.parse(localStorage.getItem('lignesVente')) || [];
//         console.log(lignesVente);
//         lignesVente.forEach(ligne => {
//             addLigneVente(ligne);
//         });
//     }



//     function addLigneVente(ligne = null) {
//         // const selectedOption = produitSelect.options[produitSelect.selectedIndex];
//         // console.log("Produit ID:", selectedOption.value);
//         // console.log("Prix:", selectedOption.getAttribute('data-prix'));
//         // console.log("Quantité en stock:", selectedOption.getAttribute('data-quantite'));
//         const produitId = ligne ? ligne.produitId : produitSelect.value;
//         if (!produitId) {
//             console.error('L\'ID du produit est undefined ou non défini.');
//             return;
//         }

//         // const produit = productOptions.find(p => p.id == produitId);
//         // if (!produit) {
//         //     console.error(`Produit avec l'ID ${produitId} introuvable.`);
//         //     return;
//         // }
//             // Utilisez l'option sélectionnée pour obtenir les informations du produit
//     const selectedOption = produitSelect.options[produitSelect.selectedIndex];
//     const produit = {
//         id: produitId,
//         prix: parseFloat(selectedOption.getAttribute('data-prix')),
//         quantite: parseInt(selectedOption.getAttribute('data-quantite')),
//         lot: selectedOption.getAttribute('data-lot'),
//         references: {
//             nom_complet: selectedOption.textContent.trim()
//         }
//     };
//         console.log(selectedOption.getAttribute('data-lot'));
//         const quantite = ligne ? ligne.quantite : parseInt(quantiteInput.value);
//         if (!quantite || isNaN(quantite) || quantite <= 0) {
//             Swal.fire({
//                 title: "Erreur",
//                 text: "Veuillez fournir une quantité valide.",
//                 icon: "error"
//             });
//             return;
//         }

//         if (quantite > produit.quantite) {
//             Swal.fire({
//                 title: "Erreur",
//                 text: `La quantité saisie (${quantite}) dépasse le stock disponible (${produit.quantite}).`,
//                 icon: "error"
//             });
//             return;
//         }

//         // Appel AJAX pour récupérer le seuil du produit depuis la table alerte_stocks
//         $.ajax({
//             url: `/produits/${produitId}/seuil`,
//             method: 'GET',
//             success: function(response) {
//                 const seuil = response.seuil || 10; // Si pas de seuil, utiliser 10 par défaut
//                 const quantiteRestante = produit.quantite - quantite;

//                 // Vérification du seuil et affichage d'une alerte si nécessaire
//                 if (quantiteRestante <= seuil) {
//                     let message = `Attention : la quantité restante du produit ${produit.nom} est faible (${quantiteRestante} restant). Seuil minimum : ${seuil}.`;

//                     if (quantiteRestante <= seuil * 0.2) {
//                         message = `Alerte critique : la quantité restante du produit ${produit.nom} est très basse (${quantiteRestante} restant).`;
//                     }

//                     Swal.fire({
//                         title: "Alerte Stock",
//                         text: message,
//                         icon: "warning"
//                     });
//                 }

//                 // Continuer l'ajout de la ligne après la vérification du seuil

//             const existingRow = Array.from(ligneVenteBody.children).find(row => row.dataset.produitId == produitId);
//             if (existingRow) {
//                 const existingQuantiteCell = existingRow.querySelector('td:nth-child(3)');
//                 existingQuantiteCell.textContent = quantite;

//                 const totalCell = existingRow.querySelector('td:nth-child(4)');
//                 totalCell.textContent = (produit.prix * quantite).toFixed(2) + ' FCFA';

//                 updateLigneVente(produitId, quantite,produit.lot);
//             } else {
//                 const row = createLigneVenteRow(produit, quantite);
//                 row.dataset.produitId = produitId;
//                 ligneVenteBody.appendChild(row);

//                 storeLigneVente({ produitId, quantite , lot:produit.lot});
//             }

//             produitSelect.value = '';
//             quantiteInput.value = '';
//         },
//             error: function() {
//                 Swal.fire({
//                     title: "Erreur",
//                     text: "Impossible de récupérer le seuil pour ce produit.",
//                     icon: "error"
//                 });
//             }
//         });
//     }






//     function updateLigneVente(produitId, quantite) {
//         const lignesVente = JSON.parse(localStorage.getItem('lignesVente')) || [];
//         const ligne = lignesVente.find(l => l.produitId == produitId);
//         if (ligne) {
//             ligne.quantite = quantite;
//         }else {
//             lignesVente.push({ produitId, quantite, lot });
//         }
//         localStorage.setItem('lignesVente', JSON.stringify(lignesVente));
//     }

//     function storeLigneVente(ligne) {
//         const lignesVente = JSON.parse(localStorage.getItem('lignesVente')) || [];
//         const existingIndex = lignesVente.findIndex(l => l.produitId == ligne.produitId);
//         if (existingIndex !== -1) {
//             lignesVente[existingIndex] = ligne;
//         } else {
//             lignesVente.push(ligne);
//         }
//         localStorage.setItem('lignesVente', JSON.stringify(lignesVente));
//     }

//         // return produit.produit.references.map(ref => ref.nom_complet).join('');




//         function createLigneVenteRow(produit, quantite) {
//             if (!produit) {
//                 console.error('Produit est undefined dans createLigneVenteRow');
//                 return;
//             }
//             console.log('Quantité:', quantite);

//             // Fonction pour obtenir le nom complet de la référence en utilisant reference_id du produit
//             function getNomCompletReference(produit) {
//                 // Assuming produit.references is a direct object with the 'nom_complet' property
//                 return produit.references ? produit.references.nom_complet : 'Unknown';
//             }
//             // Appeler la fonction pour obtenir le nom complet
//             let nomComplet = getNomCompletReference(produit);

//             // Vérification des valeurs pour débogage
//             console.log('Produit:', produit);
//             console.log('Produit reference_id:', produit.lot);
//             console.log('Nom complet de la référence:', nomComplet);


//             // Créer la ligne du tableau
//             const row = document.createElement('tr');
//             row.innerHTML = `
//                 <td class="w-1/3 text-left py-3 px-4 sm:w-auto">${nomComplet}</td>
//                 <td class="w-1/6 text-left py-3 px-4 sm:w-auto">${produit.prix.toFixed(2)} FCFA</td>
//                 <td class="w-1/6 text-left py-3 px-4 sm:w-auto">${quantite}</td>
//                 <td class="w-1/6 text-left py-3 px-4 sm:w-auto">${(produit.prix * quantite).toFixed(2)} FCFA</td>
//                 <td class="w-1/6 text-left py-3 px-4 sm:w-auto">
//                     <div class="flex items-center justify-end space-x-2">
//                         <button class="bg-blue-500 text-white px-2 py-1 rounded-md modifier-ligne">Modifier</button>
//                         <button class="bg-red-500 text-white px-2 py-1 rounded-md supprimer-ligne">Supprimer</button>
//                     </div>
//                 </td>
//             `;

//             return row;
//         }


//         // console.log(ligne , "ma ligne ");
//     function storeLigneVente(ligne) {
//         const lignesVente = JSON.parse(localStorage.getItem('lignesVente')) || [];
//         lignesVente.push(ligne);
//         localStorage.setItem('lignesVente', JSON.stringify(lignesVente));
//     }

//     function updateLigneVente(produitId, quantite) {
//         const lignesVente = JSON.parse(localStorage.getItem('lignesVente')) || [];
//         console.log('Lignes de vente:', JSON.parse(localStorage.getItem('lignesVente')));
//         const ligne = lignesVente.find(l => l.produitId == produitId);
//         if (ligne) {
//             ligne.quantite = quantite;
//             localStorage.setItem('lignesVente', JSON.stringify(lignesVente));
//         }
//     }

//     function removeLigneVente(produitId) {
//         const lignesVente = JSON.parse(localStorage.getItem('lignesVente')) || [];
//         const updatedLignesVente = lignesVente.filter(ligne => ligne.produitId != produitId);
//         localStorage.setItem('lignesVente', JSON.stringify(updatedLignesVente));
//     }

//     function editLigneVente(produitId, quantite) {
//         const produit = productOptions.find(p => p.id == produitId);
//         if (produit) {
//             produitSelect.value = produitId;
//             quantiteInput.value = quantite;
//             prixStockDiv.innerHTML = `
//                 <div class="mt-2">
//                     <span>Prix: ${produit.prix.toFixed(2)} FCFA</span><br>
//                     <span>Stock: ${produit.quantite}</span>
//                 </div>
//             `;
//         }
//     }

//     document.getElementById('ligneVenteBody').addEventListener('click', function(e) {
//         if (e.target.classList.contains('supprimer-ligne')) {
//             e.preventDefault();
//             const row = e.target.closest('tr');
//             const produitId = row.dataset.produitId;

//             // Confirmation avant suppression
//             Swal.fire({
//                 title: 'Êtes-vous sûr ?',
//                 text: "Vous allez supprimer cette ligne !",
//                 icon: 'warning',
//                 showCancelButton: true,
//                 confirmButtonColor: '#3085d6',
//                 cancelButtonColor: '#d33',
//                 confirmButtonText: 'Oui, supprimer !',
//                 cancelButtonText: 'Annuler'
//             }).then((result) => {
//                 if (result.isConfirmed) {
//                     // Suppression de la ligne
//                     ligneVenteBody.removeChild(row);
//                     removeLigneVente(produitId);

//                     Swal.fire({
//                         title: 'Supprimé !',
//                         text: 'La ligne a été supprimée.',
//                         icon: 'success'
//                     });
//                 }
//             });
//         } else if (e.target.classList.contains('modifier-ligne')) {
//             e.preventDefault();
//             const row = e.target.closest('tr');
//             const produitId = row.dataset.produitId;
//             const quantite = parseInt(row.querySelector('td:nth-child(3)').textContent);
//             console.log(produitId,quantite);
//             editLigneVente(produitId, quantite);
//             ligneVenteBody.removeChild(row);
//             removeLigneVente(produitId);
//         }
//     });



// });



document.addEventListener('DOMContentLoaded', function () {
    localStorage.removeItem('lignesVente');

    const productOptions = JSON.parse(document.getElementById('productOptions').value);
    const ligneVenteBody = document.getElementById('ligneVenteBody');
    const ajouterLigneBtn = document.getElementById('ajouterLigne');
    const soumettreVenteBtn = document.getElementById('soumettreVente');
    const patientIdInput = document.getElementById('patient_id');
    const produitSelect = document.getElementById('produit');
    const quantiteInput = document.getElementById('quantite');
    const prixStockDiv = document.getElementById('prix-stock');

    loadLignesVente();

    ajouterLigneBtn.addEventListener('click', function (e) {
        e.preventDefault();
        addLigneVente();
    });

    soumettreVenteBtn.addEventListener('click', function (e) {
        e.preventDefault();
        const lignesVente = JSON.parse(localStorage.getItem('lignesVente')) || [];
        if (lignesVente.length === 0) {
            Swal.fire({
                title: "Erreur",
                text: "Vous devez ajouter au moins un produit à la vente.",
                icon: "error"
            });
            return;
        } else {
            Swal.fire({
                title: "Vous allez enregistrer cette vente !?",
                showDenyButton: true,
                showCancelButton: true,
                confirmButtonText: "Enregistrer",
                denyButtonText: `Ne pas Enregistrer`
            }).then((result) => {
                if (result.isConfirmed) {
                    const invalidLignes = lignesVente.some(ligne => {
                        const produit = productOptions.find(p => p.id == ligne.produitId);
                        return produit && ligne.quantite > produit.quantite;
                    });

                    if (invalidLignes) {
                        Swal.fire({
                            title: "Erreur",
                            text: "Certaines quantités dépassent le stock disponible",
                            icon: "error"
                        });
                        return;
                    }

                    const form = document.querySelector('form');
                    lignesVente.forEach((ligne, index) => {
                        const produitInput = document.createElement('input');
                        produitInput.type = 'hidden';
                        produitInput.name = `lignes[${index}][id]`;
                        produitInput.value = ligne.produitId;
                        form.appendChild(produitInput);

                        const quantiteInput = document.createElement('input');
                        quantiteInput.type = 'hidden';
                        quantiteInput.name = `lignes[${index}][quantite]`;
                        quantiteInput.value = ligne.quantite;
                        form.appendChild(quantiteInput);

                        const lotInput = document.createElement('input');
                        lotInput.type = 'hidden';
                        lotInput.name = `lignes[${index}][lot]`;
                        lotInput.value = ligne.lot; // Assurez-vous que le lot est bien stocké dans `lignesVente`
                        form.appendChild(lotInput);
                    });

                    const patientInput = document.createElement('input');
                    patientInput.type = 'hidden';
                    patientInput.name = 'patient_id';
                    patientInput.value = patientIdInput.value;
                    form.appendChild(patientInput);
                    localStorage.removeItem('lignesVente');
                    form.submit();
                    Swal.fire("Sauvegardé!", "", "success");
                } else if (result.isDenied) {
                    Swal.fire("Les modifications ne sont pas enregistrées", "", "info");
                }
            });
        }
    });

    function loadLignesVente() {
        const lignesVente = JSON.parse(localStorage.getItem('lignesVente')) || [];
        lignesVente.forEach(ligne => {
            addLigneVente(ligne);
        });
    }

    function addLigneVente(ligne = null) {
        const produitId = ligne ? ligne.produitId : produitSelect.value;
        if (!produitId) {
            console.error('L\'ID du produit est undefined ou non défini.');
            return;
        }

        const selectedOption = produitSelect.options[produitSelect.selectedIndex];
        const produit = {
            id: produitId,
            prix: parseFloat(selectedOption.getAttribute('data-prix')),
            quantite: parseInt(selectedOption.getAttribute('data-quantite')),
            lot: selectedOption.getAttribute('data-lot'),
            references: {
                nom_complet: selectedOption.textContent.trim()
            }
        };

        const quantite = ligne ? ligne.quantite : parseInt(quantiteInput.value);
        if (!quantite || isNaN(quantite) || quantite <= 0) {
            Swal.fire({
                title: "Erreur",
                text: "Veuillez fournir une quantité valide.",
                icon: "error"
            });
            return;
        }

        if (quantite > produit.quantite) {
            Swal.fire({
                title: "Erreur",
                text: `La quantité saisie (${quantite}) dépasse le stock disponible (${produit.quantite}).`,
                icon: "error"
            });
            return;
        }

        // Appel AJAX pour récupérer le seuil du produit depuis la table alerte_stocks
        $.ajax({
            url: `/produits/${produitId}/seuil`,
            method: 'GET',
            success: function (response) {
                const seuil = response.seuil || 10; // Si pas de seuil, utiliser 10 par défaut
                const quantiteRestante = produit.quantite - quantite;

                // Vérification du seuil et affichage d'une alerte si nécessaire
                if (quantiteRestante <= seuil) {
                    let message = `Attention : la quantité restante du produit ${produit.nom} est faible (${quantiteRestante} restant). Seuil minimum : ${seuil}.`;
                    if (quantiteRestante <= seuil * 0.2) {
                        message = `Alerte critique : la quantité restante du produit ${produit.nom} est très basse (${quantiteRestante} restant).`;
                    }

                    Swal.fire({
                        title: "Alerte Stock",
                        text: message,
                        icon: "warning"
                    });
                }

                const existingRow = Array.from(ligneVenteBody.children).find(row => row.dataset.produitId == produitId);
                if (existingRow) {
                    const existingQuantiteCell = existingRow.querySelector('td:nth-child(3)');
                    existingQuantiteCell.textContent = quantite;

                    const totalCell = existingRow.querySelector('td:nth-child(4)');
                    totalCell.textContent = (produit.prix * quantite).toFixed(2) + ' FCFA';

                    updateLigneVente(produitId, quantite);
                } else {
                    const row = createLigneVenteRow(produit, quantite);
                    row.dataset.produitId = produitId;
                    ligneVenteBody.appendChild(row);

                    storeLigneVente({ produitId, quantite, lot: produit.lot });
                }

                produitSelect.value = '';
                quantiteInput.value = '';
            },
            error: function () {
                Swal.fire({
                    title: "Erreur",
                    text: "Impossible de récupérer le seuil pour ce produit.",
                    icon: "error"
                });
            }
        });
    }

    function updateLigneVente(produitId, quantite) {
        const lignesVente = JSON.parse(localStorage.getItem('lignesVente')) || [];
        const ligne = lignesVente.find(l => l.produitId == produitId);
        if (ligne) {
            ligne.quantite = quantite;
            localStorage.setItem('lignesVente', JSON.stringify(lignesVente));
        }
    }

    function storeLigneVente(ligne) {
        const lignesVente = JSON.parse(localStorage.getItem('lignesVente')) || [];
        const existingIndex = lignesVente.findIndex(l => l.produitId == ligne.produitId);
        if (existingIndex !== -1) {
            lignesVente[existingIndex] = ligne;
        } else {
            lignesVente.push(ligne);
        }
        localStorage.setItem('lignesVente', JSON.stringify(lignesVente));
    }

    function createLigneVenteRow(produit, quantite) {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td class="w-1/3 text-left py-3 px-4 sm:w-auto">${produit.references.nom_complet}</td>
            <td class="w-1/6 text-left py-3 px-4 sm:w-auto">${produit.prix.toFixed(2)} FCFA</td>
            <td class="w-1/6 text-left py-3 px-4 sm:w-auto">${quantite}</td>
            <td class="w-1/6 text-left py-3 px-4 sm:w-auto">${(produit.prix * quantite).toFixed(2)} FCFA</td>
            <td class="w-1/6 text-left py-3 px-4 sm:w-auto">
                <div class="flex items-center justify-end space-x-2">
                    <button class="bg-blue-500 text-white px-2 py-1 rounded-md modifier-ligne">Modifier</button>
                    <button class="bg-red-500 text-white px-2 py-1 rounded-md supprimer-ligne">Supprimer</button>
                </div>
            </td>
        `;
        row.querySelector('.supprimer-ligne').addEventListener('click', function () {
            deleteLigneVente(row, produit.id);
        });
        row.querySelector('.modifier-ligne').addEventListener('click', function () {
            modifierLigneVente(row, produit);
        });
        return row;
    }

    function deleteLigneVente(row, produitId) {
        Swal.fire({
            title: "Êtes-vous sûr ?",
            text: "Vous ne pourrez pas revenir en arrière!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Oui, supprimer !",
            cancelButtonText: "Annuler"
        }).then((result) => {
            if (result.isConfirmed) {
                const lignesVente = JSON.parse(localStorage.getItem('lignesVente')) || [];
                const index = lignesVente.findIndex(ligne => ligne.produitId == produitId);
                if (index !== -1) {
                    lignesVente.splice(index, 1);
                    localStorage.setItem('lignesVente', JSON.stringify(lignesVente));
                }
                row.remove();
                Swal.fire("Supprimé!", "La ligne a été supprimée.", "success");
            }
        });
    }

    function modifierLigneVente(row, produit) {
        const quantiteCell = row.querySelector('td:nth-child(3)');
        const quantiteActuelle = parseInt(quantiteCell.textContent);
        quantiteInput.value = quantiteActuelle;
        produitSelect.value = produit.id;

        row.remove();
        const lignesVente = JSON.parse(localStorage.getItem('lignesVente')) || [];
        const index = lignesVente.findIndex(ligne => ligne.produitId == produit.id);
        if (index !== -1) {
            lignesVente.splice(index, 1);
            localStorage.setItem('lignesVente', JSON.stringify(lignesVente));
        }
    }
});
