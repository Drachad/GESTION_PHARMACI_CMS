// // import Echo from 'laravel-echo';

// // import Pusher from 'pusher-js';
// // window.Pusher = Pusher;

// // window.Echo = new Echo({
// //     broadcaster: 'reverb',
// //     key: import.meta.env.VITE_REVERB_APP_KEY,
// //     wsHost: import.meta.env.VITE_REVERB_HOST,
// //     wsPort: import.meta.env.VITE_REVERB_PORT ?? 80,
// //     wssPort: import.meta.env.VITE_REVERB_PORT ?? 443,
// //     forceTLS: (import.meta.env.VITE_REVERB_SCHEME ?? 'https') === 'https',
// //     enabledTransports: ['ws', 'wss'],
// // });
// import Echo from 'laravel-echo';
// //import Redis from 'ioredis';

//  const echo = new Echo({
//     broadcaster: 'redis',
//     key: 'phpredis',
//     host: '127.0.0.1',
//     port: 6379,
//     auth: {
//         headers: {
//         Authorization: 'Bearer ' + token
//         }
//     },
//     namespace: 'App.Events',
//  });

// alert('bonjour');
//  echo.channel('channel-alerte-stock')
//  .listen('AlerteStockEvent', (e) => {
//     alert(e.messagealerte);
//     });
