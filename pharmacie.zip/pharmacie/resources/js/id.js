document.getElementById('produit-input').addEventListener('input', function() {
    let input = this;
    let list = document.getElementById('produits');
    let hiddenInput = document.getElementById('produit-id');
    let options = list.getElementsByTagName('option');
    hiddenInput.value = ""; // Réinitialiser l'ID du produit

    for (let i = 0; i < options.length; i++) {
        if (options[i].value === input.value) {
            hiddenInput.value = options[i].getAttribute('data-id');
            break;
        }
    }
});


document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('reference-input').addEventListener('input', function() {
        let input = this;
        let list = document.getElementById('references-datalist');
        let hiddenInput = document.getElementById('reference-id');
        let options = list.getElementsByTagName('option');
        hiddenInput.value = ""; // Réinitialiser l'ID du produit

        for (let i = 0; i < options.length; i++) {
            if (options[i].value === input.value) {
                hiddenInput.value = options[i].getAttribute('data-id');
                break;
            }
        }
    });
});