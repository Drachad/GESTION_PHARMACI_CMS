@extends('layouts.base')
@section('content')
    <div class="container mx-auto px-6 py-4 bg-white rounded-lg shadow-md">
        <!-- Bouton Retour sous forme de croix -->
        @canany('approvisionnement.view',)


        <a href="{{ route('approvisionnements.index') }}" class="text-red-600 text-3xl font-bold cursor-pointer">&times;</a>
        @endcanany
        <h2 class="text-3xl font-semibold text-green-800 border-b-4 border-green-700 pb-3 mb-6">
            Créer un nouvel approvisionnement
        </h2>

        @if ($errors->any())
            <div class="alert alert-danger bg-red-100 border border-red-300 text-red-700 rounded-lg p-4 mb-4">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        @canany( 'approvisionnement.create',)


        <form id="approform" action="{{ route('approvisionnements.store') }}" method="POST">
            @csrf
            <input type="hidden" name="redirect_to" value="{{ url()->previous() }}">

            <!-- Champs principaux -->
            <div class="form-group mb-6">
                <label for="fournisseur_id" class="font-bold text-green-800 text-lg">Fournisseur</label>
                <div class="flex space-x-4">
                <select id="fournisseur_id" name="fournisseur_id" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 transition duration-200 ease-in-out text-base shadow-sm">
                    <option value="">Sélectionner un fournisseur</option>
                    @foreach($fournisseurs as $fournisseur)
                        <option value="{{ $fournisseur->id }}" {{ (old('fournisseur_id') ) == $fournisseur->id ? 'selected' : '' }}>
                            {{ $fournisseur->nom }}
                        </option>
                    @endforeach
                </select>
                </div>

                
            </div>

            <hr class="border-gray-300 mb-6">

            <!-- Tableau des lignes d'approvisionnement -->
            <h4 class="text-xl font-semibold mb-4 text-green-700">Lignes d'approvisionnement</h4>

            <table class="w-full border-collapse bg-gray-100 rounded-lg overflow-hidden">
                <thead>
                    <tr class="bg-green-600 text-white text-sm uppercase">
                        <th class="px-4 py-3">Produit</th>
                        <th class="px-4 py-3">Prix</th>
                        <th class="px-4 py-3">Quantité</th>
                        <th class="px-4 py-3">Date de péremption</th>
                        <th class="px-4 py-3">Actions</th>
                    </tr>
                </thead>
                <tbody id="ligne-approvisionnement-table">
                    @if(old('refs_id'))

    @foreach(old('refs_id') as $index => $ref_id)
        <tr class="ligne-approvisionnement" data-index="{{ $index }}">
            <td class="px-4 py-2">
                <div class="flex space-x-1">
                    <select name="refs_id[]" id="ref-{{ $index }}" class="form-control select2 border-green-300 rounded-lg p-2 w-full">
                        <option value="">Sélectionner un produit</option>
                        @foreach($references as $reference)
                            <option value="{{ $reference->id }}" {{ $ref_id == $reference->id ? 'selected' : '' }}>
                                {{ $reference->nom_complet }}
                              </option>

                        @endforeach
                    </select>
                    
                </div>
            </td>
            <td class="px-4 py-2">
                <input type="number" name="prixs[]" class="form-control border-green-300 rounded-lg p-2 w-full" value="{{ old('prixs.'.$index) }}">
            </td>
            <td class="px-4 py-2">
                <input type="number" name="quantite[]" class="form-control border-green-300 rounded-lg p-2 w-full" value="{{ old('quantite.'.$index) }}">
            </td>
            <td class="px-4 py-2">
                <input type="date" name="date_peremption[]" class="form-control border-green-300 rounded-lg p-2 w-full" value="{{ old('date_peremption.'.$index) }}">
            </td>
            <td class="px-4 py-2">
                <button type="button" class="btn btn-danger bg-red-600 text-white rounded-lg px-4 py-2 hover:bg-red-700 remove-ligne">Supprimer</button>
            </td>
        </tr>
    @endforeach


                    @else
                        <tr class="ligne-approvisionnement" data-index="0">
                            <td class="px-4 py-2">
                            <div class="flex space-x-1">
                                <select name="refs_id[]" id='ref' class="form-control border-green-300 rounded-lg p-2 px-7 w-full">
                                    <option value="">Sélectionner un produit</option>
                                    @foreach($references as $reference)
                                        <option value="{{ $reference->id }}">{{ $reference->nom_complet }}</option>
                                    @endforeach

                                </select>

                                

                            </div>
                            </td>
                            <td class="px-4 py-2">
                                <input type="number" name="prixs[]" class="form-control border-green-300 rounded-lg p-2 w-full">
                            </td>
                            <td class="px-4 py-2">
                                <input type="number" name="quantite[]" class="form-control border-green-300 rounded-lg p-2 w-full">
                            </td>
                            <td class="px-4 py-2">
                                <input type="date" name="date_peremption[]" class="form-control border-green-300 rounded-lg p-2 w-full">
                            </td>
                            <td class="px-4 py-2">
                                <button type="button" class="btn btn-danger bg-red-600 text-white rounded-lg px-4 py-2 hover:bg-red-700 remove-ligne">Supprimer</button>
                            </td>
                        </tr>
                    @endif
                </tbody>
            </table>

            <button type="button" id="add-ligne" class="btn btn-secondary bg-gray-600 text-white rounded-lg px-4 py-2 mt-4 hover:bg-gray-700">Ajouter une ligne</button>

            <button id="soumettreVente" type="button" class="btn bg-green-600 text-white rounded-lg px-4 py-2 mt-4 hover:bg-green-700">Créer</button>
        </form>
        @endcanany
    </div>
    <script src="{{ asset('assets/js/sweetalert2.min.js') }}"></script>

    <script>
        
        
        $(document).ready(function() {
    // Initialisation du Select2 avec gestion de "no result"
    $('select.select2').select2({
        placeholder: "Sélectionnez une référence",
        allowClear: true,
        width: '100%',
        minimumResultsForSearch: 0,
        language: {
            noResults: function() {
                // Retourner un lien pour la création d'une nouvelle référence
                return $('<span>').append(
                    $('<a>', {
                        href: '{{ route('references.create') }}',
                        text: 'Référence non trouvée, créer une nouvelle',
                        class: 'text-blue-500 hover:underline',
                        target: '_blank'
                    })
                );
            }
        }
    });



    // Gestion dynamique de l'ajout de nouvelles lignes
    let ligneIndex = {{ old('refs_id') ? count(old('refs_id')) : 1 }};



    $('#add-ligne').click(function() {
        let table = $('#ligne-approvisionnement-table');
        let newRow = `
            <tr class="ligne-approvisionnement" data-index="${ligneIndex}">
                <td class="px-4 py-2">
                    <div class="flex space-x-1">
                        <select name="refs_id[]" id="ref-${ligneIndex}" class="form-control select2 border-green-300 rounded-lg p-2 w-full">
                            <option value="">Sélectionner un produit</option>
                            @foreach($references as $reference)
                                <option value="{{ $reference->id }}">{{ $reference->nom_complet }}</option>
                            @endforeach
                        </select>
                        
                    </div>


                </td>
                <td class="px-4 py-2">
                    <input type="number" name="prixs[]" class="form-control border-green-300 rounded-lg p-2 w-full">
                </td>
                <td class="px-4 py-2">
                    <input type="number" name="quantite[]" class="form-control border-green-300 rounded-lg p-2 w-full">
                </td>
                <td class="px-4 py-2">
                    <input type="date" name="date_peremption[]" class="form-control border-green-300 rounded-lg p-2 w-full">
                </td>
                <td class="px-4 py-2">
                    <button type="button" class="btn btn-danger bg-red-600 text-white rounded-lg px-4 py-2 hover:bg-red-700 remove-ligne">Supprimer</button>
                </td>


            </tr>`;

        table.append(newRow);

        // Appliquer Select2 à la nouvelle ligne
        $(`#ref-${ligneIndex}`).select2({
            placeholder: "Sélectionnez une référence",
            allowClear: true,
            width: '100%',
            minimumResultsForSearch: 0,
            language: {
                noResults: function() {
                    // Retourner un lien pour la création d'une nouvelle référence
                    return $('<span>').append(
                        $('<a>', {
                            href: '{{ route('references.create') }}',
                            text: 'Référence non trouvée, créer une nouvelle',
                            class: 'text-blue-500 hover:underline',
                            target: '_blank'
                        })
                    );
                }
            }
        });

        ligneIndex++;
    });

    // Supprimer une ligne
    $(document).on('click', '.remove-ligne', function() {
    Swal.fire({
        title: 'Êtes-vous sûr ?',
        text: "Vous allez supprimer cette ligne !",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Oui, supprimer !',
        cancelButtonText: 'Annuler'
    }).then((result) => {
        if (result.isConfirmed) {
            // Suppression de la ligne
            $(this).closest('tr').remove();
        }
    });
});

});

document.getElementById('soumettreVente').addEventListener('click', function(event) {
        event.preventDefault();
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Voulez-vous  enregistrer cet Approvisionnement !",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, valider !',
            cancelButtonText: 'Annuler'
        }).then((result) => {
            if (result.isConfirmed) {
                Swal.fire({
                    title: 'Approvisionnement enregistré',
                    icon: 'success'
                }).then(() => {
                    document.getElementById('approform').submit();
                });
            }
        });
    });

    </script>
    <script>
    $(document).ready(function() {
    $('#ref').select2({
        placeholder: "Sélectionnez une référence",
        allowClear: true,
        width: '100%',
        minimumResultsForSearch: 0,
        language: {
            noResults: function() {
                // Retourner un lien pour la création d'une nouvelle référence
                return $('<span>').append(
                    $('<a>', {
                        href: '{{ route('references.create') }}',
                        text: 'Référence non trouvée, créer une nouvelle',
                        class: 'text-blue-500 hover:underline',
                        target: '_blank'
                    })
                );
            }
        }
    });
});


$(document).ready(function() {
        $('#fournisseur_id').select2({
            placeholder: "Sélectionnez un fournisseur",
            allowClear: true,
            width: '100%',
            minimumResultsForSearch: 0,
            language: {
                    noResults: function() {
                        // Retourner le lien HTML pour la création d'un nouvel article
                        return $('<span>').append(
                            $('<a>', {
                                href: '{{ route('fournisseurs.create') }}',
                                text: 'fournisseur n\'a  pas ete trouvé créer un nouveau',
                                class: 'text-blue-500 hover:underline',
                                target: '_blank'
                            })
                        );
                }    }
        });
    });



    

    
    
</script>

@endsection
