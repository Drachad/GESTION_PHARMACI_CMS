@extends('layouts.base')


 

@section('title','Modification d un produit ')



@section('content')
<div class="flex justify-center items-center min-h-screen bg-gray-100">
    <div class="form-container bg-white rounded-lg shadow-lg p-12 max-w-xl w-full relative">
        <!-- Bouton Retour sous forme de croix -->
        @canany('produits.view')
        <a href="{{ route('produits.index') }}" class="close-button text-red-500 hover:text-red-700 text-3xl absolute top-4 right-4 transition duration-200 ease-in-out" onclick="confirmUpdate(event) ">&times;</a>
        @endcanany


        <h2 class="text-4xl font-extrabold text-green-600 mb-10 text-center tracking-wide">Modifier le Produit</h2>
        @canany('produits.edit')


        <form id="produitsupdate" action="{{ route('produits.update', $produit) }}" method="POST" class="space-y-6">

            @csrf
            @method('PUT')
            <input type="hidden" name="redirect_to" value="{{ url()->previous() }}">
            
            @if ($errors->any())
            <div class="alert alert-danger bg-red-100 border border-red-300 text-red-700 rounded-lg p-4 mb-4">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

            <!-- Champ Nom du Produit -->
            <div class="form-group">
                <label for="nom" class="block text-gray-700 font-semibold mb-2 text-lg">Nom du Produit</label>

                <input type="text" id="nom" name="nom" value="{{ old('nom', $produit->nom) }}" placeholder="Nom du produit" required 

                       class="w-full p-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 transition duration-300 ease-in-out text-lg shadow-sm">
                @error('nom')
                    <div class="text-red-600 mt-2 text-base font-medium">{{ $message }}</div>
                @enderror
            </div>

            <!-- Champ Catégorie -->
                    
                <div class="form-group">
                <label for="categorie_id" class="block text-gray-700 font-semibold mb-2 text-lg">Catégorie</label>
                <div class="flex space-x-4">
                    <select name="categorie_id" id="categorie_id" class="form-control border-green-300 rounded-lg p-2 w-full">
                        <option value="">Sélectionner une catégorie</option>

                       @foreach($categories as $categorie)

                            <option value="{{ $categorie->id }}" 
                                {{ (old('categorie_id') ?? $produit->categorie_id) == $categorie->id ? 'selected' : '' }}>
                                {{ $categorie->nom }}
                            </option>
                         @endforeach
                    </select>

                    @canany('categories.create')

                    <!-- Bouton pour ajouter une nouvelle catégorie -->
                    <a href="{{ route('categories.create') }}" class="text-white bg-blue-500 hover:bg-blue-600 font-bold py-0.8 px-3 rounded-lg transition duration-300 ease-in-out text-center shadow-sm" onclick="confirmcreate(event)">
                        +
                    </a>
                    @endcanany
                </div>
                @error('categorie_id')
                    <div class="text-red-600 mt-2 text-base font-medium">{{ $message }}</div>
                @enderror
                <!-- Lien pour créer une nouvelle catégorie -->
                @canany('categories.create')


                <p class="text-sm text-gray-500 mt-2">
                    Pas de catégorie correspondante ? <a href="{{ route('categories.create') }}" class="text-green-500 hover:text-green-700 font-medium transition duration-300 ease-in-out" onclick="confirmcreate(event)">Créer une nouvelle catégorie</a>.
                </p>
                @endcanany
            </div>

            <!-- Bouton Enregistrer -->
            <div class="form-group">
                <button type="button" id="update"


                        class="w-full bg-green-500 text-white font-bold py-4 rounded-lg hover:bg-green-600 hover:shadow-lg transition duration-300 ease-in-out text-lg">
                    Enregistrer les Modifications
                </button>
            </div>
        </form>
        @endcanany
    </div>
</div>
<script src="{{ asset('assets/js/sweetalert2.min.js') }}"></script>

<script>
    document.getElementById('update').addEventListener('click', function(event) {
        event.preventDefault();
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Vous allez enregistrer ce patient !",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, enregistrer !',
            cancelButtonText: 'Annuler'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('produitsupdate').submit();
            }
        });
    });

    function confirmUpdate(event) {
        event.preventDefault();
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Voulez vous Annuler !",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, Annuler !',
            cancelButtonText: 'Non '
        }).then((result) => {
            if (result.isConfirmed) {

                window.location.href = event.target.href;
            }
        });
    }
    function confirmcreate(event) {
        event.preventDefault();
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Voulez vous Créer !",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, créer !',
            cancelButtonText: 'Non '
        }).then((result) => {
            if (result.isConfirmed) {

                window.location.href = event.target.href;
            }
        });
    }
</script>

<script>
    $(document).ready(function() {
        $('#categorie_id').select2({
            placeholder: "Sélectionnez une categorie",
            allowClear: true,
            width: '100%',
            minimumResultsForSearch: 0,
            language: {
                    noResults: function() {
                        // Retourner le lien HTML pour la création d'un nouvel article
                        return $('<span>').append(
                            $('<a>', {
                                href: '{{ route('categories.create') }}',
                                text: 'categorie n\'est pas trouvé créer un nouveau',
                                class: 'text-blue-500 hover:underline',
                                target: '_blank'
                            })
                        );
                }    }
        });
    });
</script>

@endsection
