@extends('layouts.base')
@section('title','Création d\'un produit')

@section('content')
<div class="flex justify-center items-center min-h-screen bg-gray-100">
    <div class="form-container bg-white rounded-lg shadow-lg p-12 max-w-xl w-full relative">

        @canany('produits.view')
            <a href="{{ route('produits.index') }}" class="close-button text-red-500 hover:text-red-700 text-3xl absolute top-4 right-4 transition duration-200 ease-in-out" onclick="confirmUpdate(event)">&times;</a>
        @endcanany

        <h2 class="text-4xl font-extrabold text-green-600 mb-10 text-center tracking-wide">Ajouter un Produit</h2>

        @canany('produits.create')
            <form id="produitcreate" action="{{ route('produits.store') }}" method="POST" class="space-y-6">
                @csrf
                <input type="hidden" name="redirect_to" value="{{ url()->previous() }}">

                @if ($errors->any())
                    <div class="alert alert-danger bg-red-100 border border-red-300 text-red-700 rounded-lg p-4 mb-4">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <div class="form-group">
                    <label for="nom" class="block text-gray-700 font-semibold mb-2 text-lg">Nom du Produit</label>
                    <input type="text" id="nom" name="nom" value="{{ old('nom') }}" placeholder="Nom du produit" required 
                           class="w-full p-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 transition duration-300 ease-in-out text-lg shadow-sm">
                </div>

                <div class="form-group">
                    <label for="categorie_id" class="block text-gray-700 font-semibold mb-2 text-lg">Catégorie</label>
                    <div class="flex space-x-1">
                        <select name="categorie_id" id="categorie" class="form-control border-green-300 rounded-lg p-2 w-full">
                            <option value="">Sélectionner une catégorie</option>
                            @foreach($categories as $categorie)
                                <option value="{{ $categorie->id }}" {{ old('categorie_id') == $categorie->id ? 'selected' : '' }}>
                                    {{ $categorie->nom }}
                                </option>
                            @endforeach
                        </select>

                    </div>
                    
                </div>

                <div class="form-group">
                    <button type="submit" id="submitButton" class="w-full bg-green-500 text-white font-bold py-4 rounded-lg hover:bg-green-600 hover:shadow-lg transition duration-300 ease-in-out text-lg">
                        Ajouter Produit
                    </button>
                </div>
            </form>
        @endcanany
    </div>
</div>

<script src="{{ asset('assets/js/sweetalert2.min.js') }}"></script>
<script>
    document.getElementById('submitButton').addEventListener('click', function(event) {
        event.preventDefault();
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Voulez-vous enregistrer ?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, enregistrer !',
            cancelButtonText: 'Annuler'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('produitcreate').submit();
            }
        });
    });

    function confirmUpdate(event) {
        event.preventDefault();
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Voulez-vous annuler ?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, annuler !',
            cancelButtonText: 'Non'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = event.target.href;
            }
        });
    }

    function confirmcreate(event) {
        event.preventDefault();
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Voulez-vous créer ?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, créer !',
            cancelButtonText: 'Non'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = event.target.href;
            }
        });
    }
</script>
<script>
    $(document).ready(function() {
        $('#categorie').select2({
            placeholder: "Sélectionnez une categorie",
            allowClear: true,
            width: '100%',
            minimumResultsForSearch: 0,
            language: {
                    noResults: function() {
                        // Retourner le lien HTML pour la création d'un nouvel article
                        return $('<span>').append(
                            $('<a>', {
                                href: '{{ route('categories.create') }}',
                                text: 'categorie n\'est pas trouvé créer un nouveau',
                                class: 'text-blue-500 hover:underline',
                                target: '_blank'
                            })
                        );
                }    }
        });
    });
</script>
@endsection
