@extends('layouts.base')

@section('title','Modifiaction Fournisseur')



@section('content')
<div class="flex justify-center items-center min-h-screen bg-gray-100">
    <div class="form-container bg-white rounded-lg shadow-lg p-8 max-w-lg w-full relative">
        <!-- Bouton Retour sous forme de croix -->


        @canany('fournisseurs.view')




        <a href="{{ route('fournisseurs.index') }}" class="close-button text-red-500 hover:text-red-700 text-2xl absolute top-3 right-3 transition duration-200 ease-in-out" onclick="confirmUpdate(event)">&times;</a>
        @endcanany
        <h2 class="text-3xl font-bold text-green-600 mb-6 text-center">Modifier un Fournisseur</h2>
        @canany('fournisseurs.edit')


        <form id="foursseurupdate" action="{{ route('fournisseurs.update', $fournisseur->id) }}" method="POST" class="space-y-5">

            @csrf
            @method('PUT')

            <div class="form-group">
                @if ($errors->has('nom'))
                    <p class="error-message">{{ $errors->first('nom') }}</p>
                @endif
                <label for="nom" class="block text-gray-700 font-semibold mb-1">Nom</label>

                <input type="text" id="nom" name="nom" value="{{ old('nom', $fournisseur->nom) }}" placeholder="Nom du fournisseur" required 

                       class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 transition duration-200 ease-in-out text-base shadow-sm">
            </div>

            <div class="form-group">
                @if ($errors->has('contact'))
                    <p class="error-message">{{ $errors->first('contact') }}</p>
                @endif
                <label for="contact" class="block text-gray-700 font-semibold mb-1">Contact</label>

                <input type="text" id="contact" name="contact" value="{{ old('contact', $fournisseur->contact) }}" placeholder="Contact du fournisseur" required

                       class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 transition duration-200 ease-in-out text-base shadow-sm">
            </div>

            <div class="form-group">

                <button type="button" id="submitButton"

                        class="w-full bg-green-500 text-white font-semibold py-3 rounded-lg hover:bg-green-600 transition duration-200 ease-in-out text-base">
                    Modifier Fournisseur
                </button>
            </div>
        </form>
        @endcanany
    </div>
</div>

<script src="{{ asset('assets/js/sweetalert2.min.js') }}"></script>
<script>
    document.getElementById('submitButton').addEventListener('click', function(event) {
        event.preventDefault();
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Vous allez enregistrer ce patient !",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, enregistrer !',
            cancelButtonText: 'Annuler'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('foursseurupdate').submit();
            }
        });
    });

    function confirmUpdate(event) {
        event.preventDefault();
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Voulez vous Annuler !",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, Annuler !',
            cancelButtonText: 'Non '
        }).then((result) => {
            if (result.isConfirmed) {

                window.location.href = event.target.href;
            }
        });
    }

</script>

@endsection
