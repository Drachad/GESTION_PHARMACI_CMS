{{-- <x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __('Actions de Profil') }}
        </h2>
    </x-slot>

    <div class="py-12 bg-gray-100 dark:bg-gray-900">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
            <!-- Mettre à jour les Informations du Profil -->
            <div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                <div class="max-w-xl">
                    <a href="{{ route('profile.edit') }}" class="w-full inline-block text-center bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                        {{ __('Mettre à Jour les Informations du Profil') }}
                    </a>
                </div>
            </div>

            <!-- Mettre à jour le Mot de Passe -->
            <div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                <div class="max-w-xl">
                    <a href="{{ route('profile.change-password') }}" class="w-full inline-block text-center bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                        {{ __('Mettre à Jour le Mot de Passe') }}
                    </a>
                </div>
            </div>

            <!-- Supprimer le Compte -->
            <div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                <div class="max-w-xl">
                    <a href="{{ route('profile.delete-account') }}" class="w-full inline-block text-center bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
                        {{ __('Supprimer le Compte') }}
                    </a>
                </div>
            </div>
        </div>

        <!-- Bouton Retour à l'Accueil -->
        <div class="flex justify-center mt-8">
            <a href="{{ route('welcome') }}" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition duration-200">
                {{ __('Retour à l\'Accueil') }}
            </a>
        </div>
    </div>

    <!-- Confirmation JavaScript -->
</x-app-layout> --}}
@extends('layouts.base')
@section('title', 'Actions de Profil')
@section('content')

    <!-- Header -->
    <header class="bg-white dark:bg-gray-100 shadow sm:rounded-lg">
        <div class="max-w-8xl mx-auto py-3 px-2 sm:px-3 lg:px-5">
            <h2 class="font-semibold text-gray-800 dark:text-gray-100 leading-tight">
                {{ __('Actions de Profil') }}
            </h2>
        </div>
    </header>

    <!-- Main Content -->
    <div class="py-6 bg-gray-100 dark:bg-gray-100">
        <div class="max-w-7xl mx-auto px-2 sm:px-6 lg:px-8 space-y-6">
            <!-- Mettre à jour les Informations du Profil -->
            <div class="p-4 sm:p-6 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                <div class="max-w-md mx-auto">
                    <a href="{{ route('profile.edit') }}" class="w-full inline-block text-center bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded transition duration-200">
                        {{ __('Mettre à Jour les Informations du Profil') }}
                    </a>
                </div>
            </div>

            <!-- Mettre à jour le Mot de Passe -->
            <div class="p-4 sm:p-6 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                <div class="max-w-md mx-auto">
                    <a href="{{ route('profile.change-password') }}" class="w-full inline-block text-center bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded transition duration-200">
                        {{ __('Mettre à Jour le Mot de Passe') }}
                    </a>
                </div>
            </div>

            <!-- Supprimer le Compte -->
            <div class="p-4 sm:p-6 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                <div class="max-w-md mx-auto">
                    <a href="{{ route('profile.delete-account') }}" class="w-full inline-block text-center bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded transition duration-200">
                        {{ __('Supprimer le Compte') }}
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bouton Retour à l'Accueil -->
    <div class="flex justify-center mt-8">
        <a href="{{ route('welcome') }}" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition duration-200">
            {{ __('Retour à l\'Accueil') }}
        </a>
    </div>

@endsection

