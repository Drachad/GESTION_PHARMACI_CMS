{{-- <x-app-layout>
    <x-slot name="header">
        <div class="flex items-center justify-between">
            <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
                {{ __('Profil') }}
            </h2>
            <!-- Bouton Retour à l'Accueil -->
            <a href="{{ route('welcome') }}"
               class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition duration-200">
                {{ __('Retour à l\'Accueil') }}
            </a>
        </div>
    </x-slot>

    <div class="py-12 bg-gray-100 dark:bg-gray-900 min-h-screen">
        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
            <!-- Formulaire de mise à jour des informations de profil -->
            <div class="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6">
                <div class="flex items-center justify-between">
                    <h3 class="text-lg font-medium text-gray-900 dark:text-white">
                        {{ __('Mettre à jour les informations du profil') }}
                    </h3>
                </div>
                <div class="mt-4">
                    @include('profile.partials.update-profile-information-form')
                </div>
            </div>

            <!-- Formulaire de mise à jour du mot de passe -->
            <div class="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6">
                <div class="flex items-center justify-between">
                    <h3 class="text-lg font-medium text-gray-900 dark:text-white">
                        {{ __('Mettre à jour le mot de passe') }}
                    </h3>
                </div>
                <div class="mt-4">
                    @include('profile.partials.update-password-form')
                </div>
            </div>

            <!-- Formulaire de suppression de l'utilisateur -->
            <div class="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6">
                <div class="flex items-center justify-between">
                    <h3 class="text-lg font-medium text-gray-900 dark:text-white">
                        {{ __('Supprimer le compte') }}
                    </h3>
                </div>
                <div class="mt-4">
                    @include('profile.partials.delete-user-form')
                </div>
            </div>
        </div>
    </div>
</x-app-layout> --}}
{{-- @extends('layouts.base')

@section('title', 'Editer Profil')

@section('content')

<!-- Header -->


<!-- Main Content -->
<main class="py-12 bg-gray-100 dark:bg-gray-900 ">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <!-- Formulaire de mise à jour des informations de profil -->
        <div class="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6">
            <h3 class="text-lg font-medium text-gray-900 dark:text-white">
                {{ __('Mettre à jour les informations du profil') }}
            </h3>
            <div class="mt-4">
                @includeIf('profile.partials.update-profile-information-form')
            </div>
        </div>

        <!-- Formulaire de mise à jour du mot de passe -->
        <div class="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6">
            <h3 class="text-lg font-medium text-gray-900 dark:text-white">
                {{ __('Mettre à jour le mot de passe') }}
            </h3>
            <div class="mt-4">
                @includeIf('profile.partials.update-password-form')
            </div>
        </div>

        <!-- Formulaire de suppression de l'utilisateur -->
        <div class="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6">
            <h3 class="text-lg font-medium text-gray-900 dark:text-white">
                {{ __('Supprimer le compte') }}
            </h3>
            <div class="mt-4">
                @includeIf('profile.partials.delete-user-form')
            </div>
        </div>
    </div>
</main>

<!-- Scripts -->


@endsection --}}

@extends('layouts.base')

@section('content')
    <div class="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <!-- Header -->
        <div class="flex items-center justify-between mb-6">
            <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
                {{ __('Éditer le Profil') }}
            </h2>
            <!-- Bouton Retour à l'Accueil -->
            <a href="{{ route('welcome') }}"
               class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition duration-200">
                {{ __('Retour à l\'Accueil') }}
            </a>
        </div>

        <!-- Main Content -->
        <div class="bg-gray-100 dark:bg-gray-900 p-6 rounded-lg">

            <div class="max-w-4xl mx-auto space-y-6">
                <!-- Formulaire de mise à jour des informations de profil -->
                <div class="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6">
                    <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">
                        {{ __('Mettre à jour les informations du profil') }}
                    </h3>
                    @include('profile.partials.update-profile-information-form')
                </div>

                <!-- Formulaire de mise à jour du mot de passe -->
                <div class="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6">
                    <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">
                        {{ __('Mettre à jour le mot de passe') }}
                    </h3>
                    @include('profile.partials.update-password-form')
                </div>

                <!-- Formulaire de suppression de l'utilisateur -->
                <div class="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6">
                    <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">
                        {{ __('Supprimer le compte') }}
                    </h3>
                    @include('profile.partials.delete-user-form')
                </div>
            </div>
        </div>
    </div>
    @vite(['resources/css/app.css'])
@endsection
