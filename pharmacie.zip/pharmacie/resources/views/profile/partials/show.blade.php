@extends('layouts.base')

@section('title', 'Profil Utilisateur')

@section('content')
    <div class="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <!-- En-tête -->
        <header class="bg-white dark:bg-gray-800 shadow sm:rounded-lg p-6 mb-6">
            <div class="flex items-center justify-center flex-col space-y-4 sm:flex-row sm:space-y-0 sm:space-x-6">
                <div class="flex -space-x-2 overflow-hidden">
                    <img class="inline-block h-16 w-16 rounded-full ring-2 ring-white sm:h-24 sm:w-24" src="{{ asset('user.png') }}" alt="{{ $user->name }}">
                </div>
                <div class="text-center sm:text-left">
                    <h2 class="text-2xl font-semibold text-gray-800 dark:text-gray-200 mb-2">
                        {{ $user->name }}
                    </h2>
                    <p class="text-gray-600 dark:text-gray-400">{{ $user->email }}</p>
                </div>
            </div>
        </header>

        <div class="bg-white dark:bg-gray-800 shadow sm:rounded-lg p-6 space-y-4 sm:flex sm:space-y-0 sm:space-x-4">
            <a href="{{ route('profile.edit') }}" class="w-full sm:w-1/3 inline-block text-center bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                {{ __('Modifier le Profil') }}
            </a>
            <a href="{{ route('profile.change-password') }}" class="w-full sm:w-1/3 inline-block text-center bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                {{ __('Modifier le Mot de Passe') }}
            </a>
            <a href="{{ route('profile.delete-account') }}" class="w-full sm:w-1/3 inline-block text-center bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
                {{ __('Supprimer le Compte') }}
            </a>
        </div>
    </div>
@endsection
