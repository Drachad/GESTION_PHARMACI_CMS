@extends("layouts.base")
@section('title','Bienvenue')
@section('content')
<h2>

</h2>
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
    @canany('produits.view',)
    <!-- Card Produit -->
    <div class="bg-white p-6 rounded-lg shadow hover:shadow-lg transition-shadow duration-300">
        <div class="flex items-center">
            <div class="bg-green-100 p-2 rounded-full">
                <svg class="w-8 h-8 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 12H4"></path> <!-- Icône produit -->
                </svg>
            </div>
            <h2 class="ml-4 text-xl font-semibold text-green-600">Produits</h2>
        </div>
        <p class="mt-4 text-gray-600">Gérer les produits disponibles.</p>
        <a href="{{ route('produits.index') }}" class="mt-4 inline-block bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition-colors duration-300">
            Voir les produits
        </a>
    </div>
    @endcanany
    @canany('ventes.view',)
    <!-- Card Vente -->
    <div class="bg-white p-6 rounded-lg shadow hover:shadow-lg transition-shadow duration-300">
        <div class="flex items-center">
            <div class="bg-blue-100 p-2 rounded-full">
                <svg class="w-8 h-8 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h18v18H3z"></path> <!-- Icône vente -->
                </svg>
            </div>
            <h2 class="ml-4 text-xl font-semibold text-blue-600">Ventes</h2>
        </div>
        <p class="mt-4 text-gray-600">Gérer les ventes effectuées.</p>
        <a href="{{ route('ventes.index') }}" class="mt-4 inline-block bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition-colors duration-300">
            Voir les ventes
        </a>
    </div>
    @endcanany
    <!-- Card Stock -->
    @canany('stock.view',)
    <div class="bg-white p-6 rounded-lg shadow hover:shadow-lg transition-shadow duration-300">
        <div class="flex items-center">
            <div class="bg-yellow-100 p-2 rounded-full">
                <svg class="w-8 h-8 text-yellow-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2 4 4 8-8 4 4"></path> <!-- Icône stock -->
                </svg>
            </div>
            <h2 class="ml-4 text-xl font-semibold text-yellow-600">Stock</h2>
        </div>
        <p class="mt-4 text-gray-600">Gérer le stock des produits.</p>
        <a href="{{ route('stockProduits.index') }}" class="mt-4 inline-block bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600 transition-colors duration-300">
            Voir le stock
        </a>
    </div>
    @endcanany
    <!-- Card Références -->
    @canany('references.view',)
    <div class="bg-white p-6 rounded-lg shadow hover:shadow-lg transition-shadow duration-300">
        <div class="flex items-center">
            <div class="bg-red-100 p-2 rounded-full">
                <svg class="w-8 h-8 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1v-2h2v6z"></path> <!-- Icône références -->
                </svg>
            </div>
            <h2 class="ml-4 text-xl font-semibold text-red-600">Références</h2>
        </div>
        <p class="mt-4 text-gray-600">Gérer les références des produits.</p>
        <a href="{{ route('references.index') }}" class="mt-4 inline-block bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition-colors duration-300">
            Voir les références
        </a>
    </div>
    @endcanany
    <!-- Card Fournisseurs -->
    @canany('fournisseurs.view',)
    <div class="bg-white p-6 rounded-lg shadow hover:shadow-lg transition-shadow duration-300">
        <div class="flex items-center">
            <div class="bg-purple-100 p-2 rounded-full">
                <svg class="w-8 h-8 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v1m0 6v7m0 3h6v-3h-6zm0-10a2 2 0 100 4"></path> <!-- Icône fournisseur -->
                </svg>
            </div>
            <h2 class="ml-4 text-xl font-semibold text-purple-600">Fournisseurs</h2>
        </div>
        <p class="mt-4 text-gray-600">Gérer les fournisseurs des produits.</p>
        <a href="{{ route('fournisseurs.index') }}" class="mt-4 inline-block bg-purple-500 text-white px-4 py-2 rounded hover:bg-purple-600 transition-colors duration-300">
            Voir les fournisseurs
        </a>
    </div>
    @endcanany
    <!-- Card Catégories -->
    @canany('categories.view',)
    <div class="bg-white p-6 rounded-lg shadow hover:shadow-lg transition-shadow duration-300">
        <div class="flex items-center">
            <div class="bg-teal-100 p-2 rounded-full">
                <svg class="w-8 h-8 text-teal-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path> <!-- Icône catégories -->
                </svg>
            </div>
            <h2 class="ml-4 text-xl font-semibold text-teal-600">Catégories</h2>
        </div>
        <p class="mt-4 text-gray-600">Gérer les catégories de produits.</p>
        <a href="{{ route('categories.index') }}" class="mt-4 inline-block bg-teal-500 text-white px-4 py-2 rounded hover:bg-teal-600 transition-colors duration-300">
            Voir les catégories
        </a>
    </div>
    @endcanany
    @canany('approvisionnement.view',)
    <!-- Card Approvisionnement -->
    <div class="bg-white p-6 rounded-lg shadow hover:shadow-lg transition-shadow duration-300">
        <div class="flex items-center">
            <div class="bg-indigo-100 p-2 rounded-full">
                <svg class="w-8 h-8 text-indigo-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path> <!-- Icône approvisionnement -->
                </svg>
            </div>
            <h2 class="ml-4 text-xl font-semibold text-indigo-600">Approvisionnement</h2>
        </div>
        <p class="mt-4 text-gray-600">Gérer les approvisionnements de produits.</p>
        <a href="{{ route('approvisionnements.index') }}" class="mt-4 inline-block bg-indigo-500 text-white px-4 py-2 rounded hover:bg-indigo-600 transition-colors duration-300">
            Voir l'approvisionnement
        </a>
    </div>
    @endcanany
    @canany('inventaire.view',)
    <!-- Card Inventaire -->
    <div class="bg-white p-6 rounded-lg shadow hover:shadow-lg transition-shadow duration-300">
        <div class="flex items-center">
            <div class="bg-orange-100 p-2 rounded-full">
                <svg class="w-8 h-8 text-orange-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 3h6v3h2v5h-3"></path> <!-- Icône inventaire -->
                </svg>
            </div>
            <h2 class="ml-4 text-xl font-semibold text-orange-600">Inventaire</h2>
        </div>
        <p class="mt-4 text-gray-600">Gérer l'inventaire des produits.</p>
        <a href="{{ route('inventaire.index') }}" class="mt-4 inline-block bg-orange-500 text-white px-4 py-2 rounded hover:bg-orange-600 transition-colors duration-300">
            Voir l'inventaire
        </a>
    </div>
    @endcanany
</div>

@endsection
