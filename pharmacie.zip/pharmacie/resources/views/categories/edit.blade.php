@extends('layouts.base')

@section('title','Modification d une categorie')
@section('content')
<div class="flex justify-center items-center min-h-screen bg-gray-100">
    <div class="form-container bg-white rounded-lg shadow-lg p-8 max-w-md w-full relative">
        @canany('categories.view')


        <!-- Bouton Retour sous forme de croix -->
        <a href="{{ route('categories.index') }}" class="close-button text-red-500 hover:text-red-700 text-2xl absolute top-3 right-3 transition duration-200 ease-in-out" onclick="confirmUpdate(event)">&times;</a>
        @endcanany
        <h2 class="text-3xl font-bold text-green-600 mb-6 text-center">Modifier une catégorie</h2>
        @canany('categories.edit')


        <form  id="categorieedit" action="{{ route('categories.update', $category) }}" method="POST" class="space-y-5">

            @csrf
            @method('PUT')
            <input type="hidden" name="redirect_to" value="{{ url()->previous() }}">

            <div class="form-group">
                <label for="nom" class="block text-gray-700 font-semibold mb-1">Nom</label>

                <input type="text" id="nom" name="nom" value="{{ old('nom', $category->nom) }}" placeholder="Nom de la catégorie" required

                       class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 transition duration-200 ease-in-out text-base shadow-sm">
            </div>

            <div class="form-group">
                <label for="description" class="block text-gray-700 font-semibold mb-1">Description</label>

                <textarea id="description" name="description" rows="3" placeholder="Description de la catégorie" 

                          class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 transition duration-200 ease-in-out text-base shadow-sm">{{ old('description', $category->description) }}</textarea>
            </div>

            <div class="form-group">

                <button type="button"  id="submitButton"

                        class="w-full bg-green-500 text-white font-semibold py-3 rounded-lg hover:bg-green-600 transition duration-200 ease-in-out text-base">
                    Modifier Catégorie
                </button>
            </div>
        </form>
        @endcanany
    </div>
</div>

<script src="{{ asset('assets/js/sweetalert2.min.js') }}"></script>
<script>
    document.getElementById('submitButton').addEventListener('click', function(event) {
        event.preventDefault();
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Voulez vous mettre à jour  cette catégorie !",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, valider !',
            cancelButtonText: 'Annuler'
        }).then((result) => {
            if (result.isConfirmed) {
                Swal.fire({
                    title: 'catégorie Modifier',
                    icon: 'success'
                }).then(() => {
                    document.getElementById('categorieedit').submit();
                });
            }
        });
    })

    function confirmUpdate(event) {
        event.preventDefault();
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Voulez vous Annuler !",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, Annuler!',
            cancelButtonText: 'Ne pas Annuler'
        }).then((result) => {
            if (result.isConfirmed) {

                window.location.href = event.target.href;
            }
        });
    }
</script>

@endsection
