@extends('layouts.base')
@section('title','Inventaire')
@section('content')
<div class="container">
    <h1>Générer l'Inventaire</h1>

    <form action="{{ route('inventaire.index') }}" method="GET">
        <div class="form-group">
            <label for="start_date">Date de début:</label>
            <input type="date" id="start_date" name="start_date" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="end_date">Date de fin:</label>
            <input type="date" id="end_date" name="end_date" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-primary">Voir l'inventaire</button>
    </form>
</div>
@endsection
