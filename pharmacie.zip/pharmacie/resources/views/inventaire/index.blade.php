@extends('layouts.base')

@section('title', 'Inventaire')

@section('content')



<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold text-gray-800 mb-8">Générer l'Inventaire</h1>
    @canany('inventaire')

    @if ($errors->any())
    <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">
        <ul class="list-disc pl-5">
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
    <form  id="inventaireform" action="{{ route('genererInventairePDF') }}" method="post" class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
        @csrf

        {{-- <div class="flex flex-col md:flex-row md:space-x-4 mb-6">
            <div class="flex-1 mb-4 md:mb-0">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="type_inventaire">
                    Type D'inventaire
                </label>
                <select name="type_inventaire" id="type_inventaire" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                    <option value="perime">perime</option>
                    <option value="approvisionnement">Approvisionnement</option>
                    <option value="vente">Vente</option>
                    <option value="stock">Stock</option>
                </select>
            </div> --}}

            <div class="flex-1 mb-4 md:mb-0">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="start_date">
                    Date de début:
                </label>
                <input type="date" id="start_date" name="date_debut" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
            </div>

            <div class="flex-1">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="end_date">
                    Date de fin:
                </label>
                <input type="date" id="date_fin" name="date_fin" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
            </div>
        </div>

        <div class="flex items-center justify-center">
            <button type="button" id="submitButton" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline w-full md:w-auto" >
                Voir l'inventaire
            </button>
        </div>
    </form>
    @else
    <div class="alert alert-danger">
        Vous n'avez pas la permission d'accéder à cette section.
    </div>
    @endcanany
</div>
<script src="{{ asset("assets/js/sweetalert2.min.js") }}"></script>
<script>
      document.getElementById('submitButton').addEventListener('click', function(event) {
        event.preventDefault();
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Vous allez enregistrer ce patient !",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, enregistrer !',
            cancelButtonText: 'Annuler'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('inventaireform').submit();
            }
        });
    });

</script>

@endsection