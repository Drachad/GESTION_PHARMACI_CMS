<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Account</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css">
    <style>
        .hidden {
            display: none;
        }
    </style>
</head>
<body class="bg-gray-100 dark:bg-gray-900">
    <div class="container mx-auto py-8">
        <header>
            <h2 class="text-lg font-medium text-gray-900 dark:text-gray-100">
                Delete Account
            </h2>
            <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
                Once your account is deleted, all of its resources and data will be permanently deleted. Before deleting your account, please download any data or information that you wish to retain.
            </p>
        </header>

        <button
            id="delete-account-button"
            class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded mt-6"
        >
            Delete Account
        </button>

        <!-- Modal -->
        <div
            id="confirm-deletion-modal"
            class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full hidden"
        >
            <div class="relative top-1/4 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white dark:bg-gray-800">
                <form id="delete-account-form" method="post" action="/profile/destroy">
                    <!-- Add CSRF Token and Method -->
                    <input type="hidden" name="_token" value="YOUR_CSRF_TOKEN">
                    <input type="hidden" name="_method" value="delete">

                    <h2 class="text-lg font-medium text-gray-900 dark:text-gray-100">
                        Are you sure you want to delete your account?
                    </h2>

                    <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
                        Once your account is deleted, all of its resources and data will be permanently deleted. Please enter your password to confirm you would like to permanently delete your account.
                    </p>

                    <div class="mt-6">
                        <label for="password" class="sr-only">Password</label>
                        <input
                            id="password"
                            name="password"
                            type="password"
                            class="mt-1 block w-3/4 border border-gray-300 rounded-md shadow-sm dark:text-gray-800"
                            placeholder="Password"
                            required
                        />
                        <span id="password-error" class="text-red-500 text-sm mt-2 hidden"></span>
                    </div>

                    <div class="mt-6 flex justify-end">
                        <button
                            type="button"
                            id="cancel-button"
                            class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded"
                        >
                            Cancel
                        </button>

                        <button
                            type="submit"
                            class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded ms-3"
                        >
                            Delete Account
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        // JavaScript to handle modal open and close
        document.addEventListener('DOMContentLoaded', function() {
            const deleteAccountButton = document.getElementById('delete-account-button');
            const confirmDeletionModal = document.getElementById('confirm-deletion-modal');
            const cancelButton = document.getElementById('cancel-button');
            const passwordInput = document.getElementById('password');
            const passwordError = document.getElementById('password-error');

            deleteAccountButton.addEventListener('click', function() {
                confirmDeletionModal.classList.remove('hidden');
            });

            cancelButton.addEventListener('click', function() {
                confirmDeletionModal.classList.add('hidden');
            });

            // Form submission event listener
            const deleteAccountForm = document.getElementById('delete-account-form');
            deleteAccountForm.addEventListener('submit', function(event) {
                event.preventDefault(); // Prevent the form from submitting the traditional way

                // Simple password validation
                if (passwordInput.value === '') {
                    passwordError.textContent = 'Password is required.';
                    passwordError.classList.remove('hidden');
                    return;
                } else {
                    passwordError.classList.add('hidden');
                }

                // Proceed with form submission
                // Here you might want to perform an AJAX request instead of submitting traditionally
                deleteAccountForm.submit();
            });
        });
    </script>
</body>
</html>
