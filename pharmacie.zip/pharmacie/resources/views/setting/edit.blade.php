<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Utilisateur</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 dark:bg-gray-900">
    <!-- En-tête -->
    <header class="py-6 bg-white dark:bg-gray-800 shadow">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
                Profil
            </h2>
        </div>
    </header>

    <!-- Contenu principal -->
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">

            <!-- Mise à jour des informations de profil -->
            <div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                <div class="max-w-xl">
                    <section>
                        <header>
                            <h2 class="text-lg font-medium text-gray-900 dark:text-gray-100">
                                Informations du Profil
                            </h2>
                            <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
                                Mettez à jour les informations de profil et l'adresse email de votre compte.
                            </p>
                        </header>

                        <form id="update-profile-form" method="post" action="/profile/update" class="mt-6 space-y-6">
                            <div>
                                <label for="name" class="block text-sm font-medium text-gray-700 dark:text-gray-300">
                                    Nom
                                </label>
                                <input
                                    id="name"
                                    name="name"
                                    type="text"
                                    class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm dark:text-gray-800"
                                    value="Votre Nom"
                                    required
                                    autofocus
                                    autocomplete="name"
                                />
                                <span id="name-error" class="text-red-500 text-sm mt-2 hidden"></span>
                            </div>

                            <div>
                                <label for="email" class="block text-sm font-medium text-gray-700 dark:text-gray-300">
                                    Email
                                </label>
                                <input
                                    id="email"
                                    name="email"
                                    type="email"
                                    class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm dark:text-gray-800"
                                    value="VotreEmail@example.com"
                                    required
                                    autocomplete="username"
                                />
                                <span id="email-error" class="text-red-500 text-sm mt-2 hidden"></span>

                                <div id="verification-message" class="text-sm mt-2 text-gray-800 dark:text-gray-200 hidden">
                                    Votre adresse email n'est pas vérifiée.
                                    <button
                                        onclick="document.getElementById('send-verification').submit();"
                                        class="underline text-sm text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800"
                                    >
                                        Cliquez ici pour renvoyer l'email de vérification.
                                    </button>
                                </div>
                                <p id="verification-link-sent" class="mt-2 font-medium text-sm text-green-600 dark:text-green-400 hidden">
                                    Un nouveau lien de vérification a été envoyé à votre adresse email.
                                </p>
                            </div>

                            <div class="flex items-center gap-4">
                                <button
                                    type="submit"
                                    class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
                                >
                                    Enregistrer
                                </button>

                                <p
                                    id="status-message"
                                    class="text-sm text-gray-600 dark:text-gray-400 hidden"
                                >
                                    Enregistré.
                                </p>
                            </div>
                        </form>
                    </section>
                </div>
            </div>

            <!-- Mise à jour du mot de passe -->
            <div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                <div class="max-w-xl">
                    <section>
                        <header>
                            <h2 class="text-lg font-medium text-gray-900 dark:text-gray-100">
                                Mettre à Jour le Mot de Passe
                            </h2>
                            <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
                                Assurez-vous que votre compte utilise un mot de passe long et aléatoire pour rester sécurisé.
                            </p>
                        </header>

                        <form id="update-password-form" method="post" action="/password/update" class="mt-6 space-y-6">
                            <div>
                                <label for="current_password" class="block text-sm font-medium text-gray-700 dark:text-gray-300">
                                    Mot de Passe Actuel
                                </label>
                                <input
                                    id="current_password"
                                    name="current_password"
                                    type="password"
                                    class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm dark:text-gray-800"
                                    autocomplete="current-password"
                                    required
                                />
                                <span id="current-password-error" class="text-red-500 text-sm mt-2 hidden"></span>
                            </div>

                            <div>
                                <label for="password" class="block text-sm font-medium text-gray-700 dark:text-gray-300">
                                    Nouveau Mot de Passe
                                </label>
                                <input
                                    id="password"
                                    name="password"
                                    type="password"
                                    class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm dark:text-gray-800"
                                    autocomplete="new-password"
                                    required
                                />
                                <span id="password-error" class="text-red-500 text-sm mt-2 hidden"></span>
                            </div>

                            <div>
                                <label for="password_confirmation" class="block text-sm font-medium text-gray-700 dark:text-gray-300">
                                    Confirmer le Mot de Passe
                                </label>
                                <input
                                    id="password_confirmation"
                                    name="password_confirmation"
                                    type="password"
                                    class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm dark:text-gray-800"
                                    autocomplete="new-password"
                                    required
                                />
                                <span id="password-confirmation-error" class="text-red-500 text-sm mt-2 hidden"></span>
                            </div>

                            <div class="flex items-center gap-4">
                                <button
                                    type="submit"
                                    class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
                                >
                                    Enregistrer
                                </button>

                                <p
                                    id="password-status-message"
                                    class="text-sm text-gray-600 dark:text-gray-400 hidden"
                                >
                                    Mot de passe mis à jour.
                                </p>
                            </div>
                        </form>
                    </section>
                </div>
            </div>

            <!-- Suppression de l'utilisateur -->
            <div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                <div class="max-w-xl">
                    <section>
                        <header>
                            <h2 class="text-lg font-medium text-gray-900 dark:text-gray-100">
                                Supprimer le Compte
                            </h2>
                            <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
                                Une fois votre compte supprimé, toutes ses ressources et données seront définitivement supprimées. Avant de supprimer votre compte, téléchargez toutes les données ou informations que vous souhaitez conserver.
                            </p>
                        </header>

                        <form id="delete-user-form" method="post" action="/profile/destroy" class="mt-6 space-y-6">
                            <div>
                                <label for="delete_password" class="block text-sm font-medium text-gray-700 dark:text-gray-300 sr-only">
                                    Mot de Passe
                                </label>
                                <input
                                    id="delete_password"
                                    name="password"
                                    type="password"
                                    class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm dark:text-gray-800"
                                    placeholder="Mot de Passe"
                                    required
                                />
                                <span id="delete-password-error" class="text-red-500 text-sm mt-2 hidden"></span>
                            </div>

                            <div class="flex justify-end gap-4">
                                <button
                                    type="button"
                                    onclick="cancelDeletion()"
                                    class="bg-gray-500 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded"
                                >
                                    Annuler
                                </button>

                                <button
                                    type="submit"
                                    class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded"
                                >
                                    Supprimer le Compte
                                </button>
                            </div>
                        </form>
                    </section>
                </div>
            </div>

        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Mise à jour des informations de profil
            const profileForm = document.getElementById('update-profile-form');
            const nameInput = document.getElementById('name');
            const emailInput = document.getElementById('email');

            const nameError = document.getElementById('name-error');
            const emailError = document.getElementById('email-error');
            const statusMessage = document.getElementById('status-message');
            const verificationMessage = document.getElementById('verification-message');
            const verificationLinkSent = document.getElementById('verification-link-sent');

            profileForm.addEventListener('submit', function(event) {
                event.preventDefault(); // Empêche l'envoi par défaut du formulaire

                let hasError = false;

                // Valider le nom
                if (nameInput.value.trim() === '') {
                    nameError.textContent = 'Le nom est requis.';
                    nameError.classList.remove('hidden');
                    hasError = true;
                } else {
                    nameError.classList.add('hidden');
                }

                // Valider l'email
                if (emailInput.value.trim() === '') {
                    emailError.textContent = 'L\'email est requis.';
                    emailError.classList.remove('hidden');
                    hasError = true;
                } else if (!validateEmail(emailInput.value)) {
                    emailError.textContent = 'L\'email est invalide.';
                    emailError.classList.remove('hidden');
                    hasError = true;
                } else {
                    emailError.classList.add('hidden');
                }

                if (!hasError) {
                    // Soumettre le formulaire ou faire une requête AJAX
                    profileForm.submit(); // Ou utilisez une requête AJAX

                    // Afficher le message de succès
                    statusMessage.classList.remove('hidden');
                    setTimeout(() => {
                        statusMessage.classList.add('hidden');
                    }, 2000);
                }
            });

            // Validation de l'email
            function validateEmail(email) {
                const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                return re.test(email);
            }

            // Vérification de l'email (simulée)
            const userEmailVerified = false; // Remplacer par $user->hasVerifiedEmail()
            if (!userEmailVerified) {
                verificationMessage.classList.remove('hidden');
            }

            const verificationLinkSentStatus = false; // Remplacer par session('status') === 'verification-link-sent'
            if (verificationLinkSentStatus) {
                verificationLinkSent.classList.remove('hidden');
            }

            // Mise à jour du mot de passe
            const passwordForm = document.getElementById('update-password-form');
            const currentPasswordInput = document.getElementById('current_password');
            const passwordInput = document.getElementById('password');
            const passwordConfirmationInput = document.getElementById('password_confirmation');

            const currentPasswordError = document.getElementById('current-password-error');
            const passwordError = document.getElementById('password-error');
            const passwordConfirmationError = document.getElementById('password-confirmation-error');
            const passwordStatusMessage = document.getElementById('password-status-message');

            passwordForm.addEventListener('submit', function(event) {
                event.preventDefault(); // Empêche l'envoi par défaut du formulaire

                let hasError = false;

                // Valider le mot de passe actuel
                if (currentPasswordInput.value.trim() === '') {
                    currentPasswordError.textContent = 'Le mot de passe actuel est requis.';
                    currentPasswordError.classList.remove('hidden');
                    hasError = true;
                } else {
                    currentPasswordError.classList.add('hidden');
                }

                // Valider le nouveau mot de passe
                if (passwordInput.value.trim() === '') {
                    passwordError.textContent = 'Le nouveau mot de passe est requis.';
                    passwordError.classList.remove('hidden');
                    hasError = true;
                } else {
                    passwordError.classList.add('hidden');
                }

                // Valider la confirmation du mot de passe
                if (passwordConfirmationInput.value.trim() !== passwordInput.value.trim()) {
                    passwordConfirmationError.textContent = 'Les mots de passe ne correspondent pas.';
                    passwordConfirmationError.classList.remove('hidden');
                    hasError = true;
                } else {
                    passwordConfirmationError.classList.add('hidden');
                }

                if (!hasError) {

                    passwordForm.submit();

                    // Afficher le message de succès
                    passwordStatusMessage.classList.remove('hidden');
                    setTimeout(() => {
                        passwordStatusMessage.classList.add('hidden');
                    }, 2000);
                }
            });

            // Suppression de l'utilisateur
            const deleteUserForm = document.getElementById('delete-user-form');
            const deletePasswordInput = document.getElementById('delete_password');
            const deletePasswordError = document.getElementById('delete-password-error');

            deleteUserForm.addEventListener('submit', function(event) {
                event.preventDefault(); // Empêche l'envoi par défaut du formulaire

                if (deletePasswordInput.value.trim() === '') {
                    deletePasswordError.textContent = 'Le mot de passe est requis pour supprimer le compte.';
                    deletePasswordError.classList.remove('hidden');
                } else {
                    deletePasswordError.classList.add('hidden');


                    deleteUserForm.submit();
                }
            });

            // Annulation de la suppression
            window.cancelDeletion = function() {
                deletePasswordInput.value = '';
                deletePasswordError.classList.add('hidden');
            };
        });
    </script>
</body>
</html>
