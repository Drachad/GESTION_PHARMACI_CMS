<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mettre à jour le mot de passe</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css">
</head>
<body class="bg-gray-100 dark:bg-gray-900">
    <div class="container mx-auto py-8">
        <header>
            <h2 class="text-lg font-medium text-gray-900 dark:text-gray-100">
                Mettre à jour le mot de passe
            </h2>
            <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
                Assurez-vous que votre compte utilise un mot de passe long et aléatoire pour rester sécurisé.
            </p>
        </header>

        <form id="update-password-form" method="post" action="/password/update" class="mt-6 space-y-6">
            <!-- Ajouter le jeton CSRF et la méthode -->
            <input type="hidden" name="_token" value="YOUR_CSRF_TOKEN">
            <input type="hidden" name="_method" value="put">

            <div>
                <label for="update_password_current_password" class="block text-sm font-medium text-gray-700 dark:text-gray-300">
                    Mot de passe actuel
                </label>
                <input
                    id="update_password_current_password"
                    name="current_password"
                    type="password"
                    class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm dark:text-gray-800"
                    autocomplete="current-password"
                    required
                />
                <span id="current-password-error" class="text-red-500 text-sm mt-2 hidden"></span>
            </div>

            <div>
                <label for="update_password_password" class="block text-sm font-medium text-gray-700 dark:text-gray-300">
                    Nouveau mot de passe
                </label>
                <input
                    id="update_password_password"
                    name="password"
                    type="password"
                    class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm dark:text-gray-800"
                    autocomplete="new-password"
                    required
                />
                <span id="password-error" class="text-red-500 text-sm mt-2 hidden"></span>
            </div>

            <div>
                <label for="update_password_password_confirmation" class="block text-sm font-medium text-gray-700 dark:text-gray-300">
                    Confirmer le mot de passe
                </label>
                <input
                    id="update_password_password_confirmation"
                    name="password_confirmation"
                    type="password"
                    class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm dark:text-gray-800"
                    autocomplete="new-password"
                    required
                />
                <span id="password-confirmation-error" class="text-red-500 text-sm mt-2 hidden"></span>
            </div>

            <div class="flex items-center gap-4">
                <button
                    type="submit"
                    class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
                >
                    Enregistrer
                </button>

                <p
                    id="status-message"
                    class="text-sm text-gray-600 dark:text-gray-400 hidden"
                >
                    Enregistré.
                </p>
            </div>
        </form>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('update-password-form');
            const currentPasswordInput = document.getElementById('update_password_current_password');
            const newPasswordInput = document.getElementById('update_password_password');
            const confirmPasswordInput = document.getElementById('update_password_password_confirmation');

            const currentPasswordError = document.getElementById('current-password-error');
            const passwordError = document.getElementById('password-error');
            const passwordConfirmationError = document.getElementById('password-confirmation-error');
            const statusMessage = document.getElementById('status-message');

            form.addEventListener('submit', function(event) {
                event.preventDefault(); // Empêche l'envoi par défaut du formulaire

                let hasError = false;

                // Valider le mot de passe actuel
                if (currentPasswordInput.value.trim() === '') {
                    currentPasswordError.textContent = 'Le mot de passe actuel est requis.';
                    currentPasswordError.classList.remove('hidden');
                    hasError = true;
                } else {
                    currentPasswordError.classList.add('hidden');
                }

                // Valider le nouveau mot de passe
                if (newPasswordInput.value.trim() === '') {
                    passwordError.textContent = 'Le nouveau mot de passe est requis.';
                    passwordError.classList.remove('hidden');
                    hasError = true;
                } else {
                    passwordError.classList.add('hidden');
                }

                // Valider la confirmation du mot de passe
                if (confirmPasswordInput.value !== newPasswordInput.value) {
                    passwordConfirmationError.textContent = 'Les mots de passe ne correspondent pas.';
                    passwordConfirmationError.classList.remove('hidden');
                    hasError = true;
                } else {
                    passwordConfirmationError.classList.add('hidden');
                }

                if (!hasError) {
                    // Optionnellement, soumettre le formulaire en utilisant AJAX ici
                    // Exemple : submitForm();
                    form.submit(); // Poursuivre l'envoi du formulaire

                    // Afficher le message de succès
                    statusMessage.classList.remove('hidden');
                    setTimeout(() => {
                        statusMessage.classList.add('hidden');
                    }, 2000);
                }
            });
        });
    </script>
</body>
</html>
