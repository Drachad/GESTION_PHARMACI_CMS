<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Informations du Profil</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css">
</head>
<body class="bg-gray-100 dark:bg-gray-900">
    <div class="container mx-auto py-8">
        <header>
            <h2 class="text-lg font-medium text-gray-900 dark:text-gray-100">
                Informations du Profil
            </h2>
            <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
                Mettez à jour les informations de profil et l'adresse email de votre compte.
            </p>
        </header>

        <form id="send-verification" method="post" action="/verification/send">
            <!-- CSRF Token -->
            <input type="hidden" name="_token" value="YOUR_CSRF_TOKEN">
        </form>

        <form id="update-profile-form" method="post" action="/profile/update" class="mt-6 space-y-6">
            <!-- CSRF Token et méthode -->
            <input type="hidden" name="_token" value="YOUR_CSRF_TOKEN">
            <input type="hidden" name="_method" value="patch">

            <div>
                <label for="name" class="block text-sm font-medium text-gray-700 dark:text-gray-300">
                    Nom
                </label>
                <input
                    id="name"
                    name="name"
                    type="text"
                    class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm dark:text-gray-800"
                    value="Votre Nom" <!-- Remplacer par old('name', $user->name) si nécessaire -->
                    required
                    autofocus
                    autocomplete="name"
                />
                <span id="name-error" class="text-red-500 text-sm mt-2 hidden"></span>
            </div>

            <div>
                <label for="email" class="block text-sm font-medium text-gray-700 dark:text-gray-300">
                    Email
                </label>
                <input
                    id="email"
                    name="email"
                    type="email"
                    class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm dark:text-gray-800"
                    value="VotreEmail@example.com" <!-- Remplacer par old('email', $user->email) si nécessaire -->
                    required
                    autocomplete="username"
                />
                <span id="email-error" class="text-red-500 text-sm mt-2 hidden"></span>

                <div id="verification-message" class="text-sm mt-2 text-gray-800 dark:text-gray-200 hidden">
                    Votre adresse email n'est pas vérifiée.
                    <button
                        onclick="document.getElementById('send-verification').submit();"
                        class="underline text-sm text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800"
                    >
                        Cliquez ici pour renvoyer l'email de vérification.
                    </button>
                </div>
                <p id="verification-link-sent" class="mt-2 font-medium text-sm text-green-600 dark:text-green-400 hidden">
                    Un nouveau lien de vérification a été envoyé à votre adresse email.
                </p>
            </div>

            <div class="flex items-center gap-4">
                <button
                    type="submit"
                    class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
                >
                    Enregistrer
                </button>

                <p
                    id="status-message"
                    class="text-sm text-gray-600 dark:text-gray-400 hidden"
                >
                    Enregistré.
                </p>
            </div>
        </form>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('update-profile-form');
            const nameInput = document.getElementById('name');
            const emailInput = document.getElementById('email');

            const nameError = document.getElementById('name-error');
            const emailError = document.getElementById('email-error');
            const statusMessage = document.getElementById('status-message');
            const verificationMessage = document.getElementById('verification-message');
            const verificationLinkSent = document.getElementById('verification-link-sent');

            form.addEventListener('submit', function(event) {
                event.preventDefault(); // Empêche l'envoi par défaut du formulaire

                let hasError = false;

                // Valider le nom
                if (nameInput.value.trim() === '') {
                    nameError.textContent = 'Le nom est requis.';
                    nameError.classList.remove('hidden');
                    hasError = true;
                } else {
                    nameError.classList.add('hidden');
                }

                // Valider l'email
                if (emailInput.value.trim() === '') {
                    emailError.textContent = 'L\'email est requis.';
                    emailError.classList.remove('hidden');
                    hasError = true;
                } else if (!validateEmail(emailInput.value)) {
                    emailError.textContent = 'L\'email est invalide.';
                    emailError.classList.remove('hidden');
                    hasError = true;
                } else {
                    emailError.classList.add('hidden');
                }

                if (!hasError) {
                    // Soumettre le formulaire ou faire une requête AJAX
                    form.submit(); // Ou utilisez une requête AJAX

                    // Afficher le message de succès
                    statusMessage.classList.remove('hidden');
                    setTimeout(() => {
                        statusMessage.classList.add('hidden');
                    }, 2000);
                }
            });

            // Fonction de validation d'email
            function validateEmail(email) {
                const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                return re.test(email);
            }

            // Simulation de la vérification de l'email (à adapter à votre logique)
            const userEmailVerified = false; // Remplacer par $user->hasVerifiedEmail()
            if (!userEmailVerified) {
                verificationMessage.classList.remove('hidden');
            }

            // Simulation de l'état du lien de vérification envoyé (à adapter à votre logique)
            const verificationLinkSentStatus = false; // Remplacer par session('status') === 'verification-link-sent'
            if (verificationLinkSentStatus) {
                verificationLinkSent.classList.remove('hidden');
            }
        });
    </script>
</body>
</html>
