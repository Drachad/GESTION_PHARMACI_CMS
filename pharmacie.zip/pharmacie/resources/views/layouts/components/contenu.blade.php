{{-- @extends('layouts.base')
@section('title', 'Les Statistiques')

@section('content')

<main class="h-full overflow-y-auto">
    <div class="container px-6 mx-auto grid">
        <h2 class="my-6 text-2xl font-semibold text-gray-700 dark:text-gray-200">
            Dashboard
        </h2>
        <!-- CTA -->
        <a class="flex items-center justify-between p-4 mb-8 text-sm font-semibold text-purple-100 bg-purple-600 rounded-lg shadow-md focus:outline-none focus:shadow-outline-purple"
           href="#">
            <div class="flex items-center">
                <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                </svg>
                <span>STATISTIQUES DE LA PHARMACIE</span>
            </div>
            <span>View more &RightArrow;</span>
        </a>
        <!-- Cards -->

        <div class="container mx-auto px-4 py-8">
            <h1 class="text-2xl font-bold mb-4">Inventaire côté {{ $typeInventaire }} </h1>

            <!-- Graphique -->
            <div class="mb-8">
                <canvas id="inventoryChart"></canvas>
            </div>

            <!-- Table des résultats -->
            <table class="min-w-full divide-y divide-gray-200">
                <thead>
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Produit</th>

                            @if ($typeInventaire === 'approvisionnement' || $typeInventaire === 'perime' || $typeInventaire === 'stock' || $typeInventaire === 'vente')

                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Référence</th>
                        @endif

                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Prix
                        </th>

                        @if ($typeInventaire === 'approvisionnement'  || $typeInventaire ==='perime'  || $typeInventaire ==='stock'  || $typeInventaire ==='vente')
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Quantité</th>
                        @else
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Date de Vente</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Client</th>
                        @endif
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    @foreach ($resultats as $item)
                    <tr>
                        <td class="px-6 py-4 whitespace-nowrap">{{ $item->produit->nom ?? 'Non disponible' }}</td>

                        @if ( $typeInventaire ==='approvisionnement' )
                        <td class="px-6 py-4 whitespace-nowrap">
                            @php
                                // Chercher la référence spécifique liée à cet élément, par exemple par 'reference_id'
                                $specificReference = $item->lignes->references ?? null;
                            @endphp

                            {{ $specificReference->nom_complet ?? 'Non disponible' }}
                        </td>
                        @elseif ( $typeInventaire ==='perime' )
                        <td class="px-6 py-4 whitespace-nowrap">
                            @php
                                // Chercher la référence spécifique liée à cet élément, par exemple par 'reference_id'
                                $specificReference = $item->produit->references->where('id', $item->reference_id)->first();
                            @endphp

                            {{ $specificReference->nom_complet ?? 'Non disponible' }}
                        </td>

                        <td class="px-6 py-4 whitespace-nowrap">{{ $item->quantite ?? 'Non disponible' }}</td>
                        @else
                        <td class="px-6 py-4 whitespace-nowrap">{{ $item->date_vente ?? 'Non disponible' }}</td>
                        <td class="px-6 py-4 whitespace-nowrap">{{ $item->client->nom ?? 'Non disponible' }}</td>
                        @endif

                        <td class="px-6 py-4 whitespace-nowrap">{{ $item->prix }}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>

            <!-- Pagination -->
            <div class="mt-4">
                {{ $resultats->links() }}
            </div>
        </div>

        <script src="{{ asset('assets/js/chart.js') }}"></script>

        <script>
            // Configuration du graphique en barre
            const ctx = document.getElementById('inventoryChart').getContext('2d');

            // Initialiser le graphique en barre
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: @json($chartData['labels']), // Labels des produits
                    datasets: [{
                        label: '{{ ucfirst($typeInventaire) }}', // Étiquette du type d'inventaire
                        data: @json($chartData['datasets'][0]['data']), // Données correspondantes
                        backgroundColor: 'rgba(54, 162, 235, 0.5)',
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    },
                    plugins: {
                        legend: {
                            display: true,
                            position: 'top'
                        }
                    }
                }
            });
        </script>

</main>
@endsection --}}



@extends('layouts.base')
@section('title', 'les statistiques ')

@section('content')

    <main class="h-full overflow-y-auto">
        <div class="container px-6 mx-auto grid">
            <h2 class="my-6 text-2xl font-semibold text-gray-700 dark:text-gray-200">
                Dashboard
            </h2>
            <!-- CTA -->
            <a class="flex items-center justify-between p-4 mb-8 text-sm font-semibold text-purple-100 bg-purple-600 rounded-lg shadow-md focus:outline-none focus:shadow-outline-purple"
                href="#">
                <div class="flex items-center">
                    <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                        <path
                            d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z">
                        </path>
                    </svg>
                    <span>STATISTIQUES DE LA PHARMACIE </span>
                </div>
                <span>View more &RightArrow;</span>
            </a>
            <!-- Cards -->

            <div class="container mx-auto px-4 py-8">
                <h1 class="text-2xl font-bold mb-4">Inventaire côté {{  $typeInventaire }} </h1>


                <!-- Graphique -->
                <div class="mb-8">
                    <canvas id="inventoryChart"></canvas>
                </div>

                <!-- Table des résultats -->
                <table class="min-w-full divide-y divide-gray-200">
                    <thead>
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Produit</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Référence</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Prix
                            </th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Quantité</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        @foreach ($resultats as $item)
                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap">{{ $item->produit->nom ?? 'Non disponible' }}</td>
                                <td class="px-6 py-4 whitespace-nowrap">{{ $item->reference_id }}</td>
                                <td class="px-6 py-4 whitespace-nowrap">{{ $item->prix }}</td>
                                <td class="px-6 py-4 whitespace-nowrap">{{ $item->quantite ?? 'Non disponible' }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>

                <!-- Pagination -->
                <div class="mt-4">
                    {{ $resultats->links() }}
                </div>
            </div>

            <script src="{{ asset('assets/js/chart.js') }}"></script>

            <script>
                // Configuration du graphique en barre
                const ctx = document.getElementById('inventoryChart').getContext('2d');

                // Initialiser le graphique en barre
                new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: @json($chartData['labels']), // Labels des produits
                        datasets: [{
                            label: '{{ ucfirst($typeInventaire) }}', // Étiquette du type d'inventaire
                            data: @json($chartData['datasets'][0]['data']), // Données correspondantes
                            backgroundColor: 'rgba(54, 162, 235, 0.5)',
                            borderColor: 'rgba(54, 162, 235, 1)',
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        scales: {
                            y: {
                                beginAtZero: true
                            }
                        },
                        plugins: {
                            legend: {
                                display: true,
                                position: 'top'
                            }
                        }
                    }
                });
            </script>






    </main>
@endsection
