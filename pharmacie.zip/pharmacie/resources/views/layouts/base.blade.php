<!DOCTYPE html>
<html class="{ 'theme-dark': dark }" x-data="data()" lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title')</title>
    <link href="" rel="stylesheet" />
    @vite(['resources/css/app.css'])
    <script src="{{ asset('assets/js/jquery.min.js') }}"></script>

    <link href="{{ asset('assets/css/select2.min.css') }}" rel="stylesheet" />
    <script src="{{ asset('assets/js/select2.min.js') }}"></script>

    <link rel="stylesheet" href="{{ asset("assets/css/tailwind.output.css") }}" />
    <link rel="stylesheet" href="{{ asset("assets/css/talwind.min.css") }}">

</head>

<body>
    <div class="flex h-screen bg-gray-50 dark:bg-gray-900" class="{ 'overflow-hidden': isSideMenuOpen }">
        <!-- Desktop sidebar -->
        @include('layouts.components.sidebar')
        <!-- Mobile sidebar -->
        <!-- Backdrop -->

        <!-- Superposition -->
        <div x-show="isSideMenuOpen" x-transition:enter="transition ease-in-out duration-150"
            x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100"
            x-transition:leave="transition ease-in-out duration-150" x-transition:leave-start="opacity-100"
            x-transition:leave-end="opacity-0"
            class="fixed inset-0 z-10 flex items-end bg-black bg-opacity-50 sm:items-center sm:justify-center"
            style="display: none;"> <!-- Ajoutez style="display: none;" pour le débogage -->
        </div>

        @include('layouts.components.sidebar_mobile')
        <div class="flex flex-col flex-1 w-full">

            @include("layouts.components.header")
            <main class="h-full overflow-y-auto">
               @yield('content')

            </main>

        </div>
    </div>
</body>
<style>

</style>
<script src="{{ asset("assets/js/alpine.min.js") }}" defer></script>

<script src="{{ asset("assets/js/init-alpine.js") }}"></script>
<link rel="stylesheet" href="{{ asset("assets/css/chart.min.css") }}" />
<script src="{{ asset("assets/js/chart.min.js") }}" defer></script>
<script src="{{ asset("assets/js/charts-lines.js") }}" defer></script>
<script src="{{ asset("assets/js/charts-pie.js") }}" defer></script>


</html>
