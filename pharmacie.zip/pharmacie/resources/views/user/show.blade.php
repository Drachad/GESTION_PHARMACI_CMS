
 @extends('layouts.base')
@section('title', 'Voir Information')
@section('content')
@canany('users.view')
    <div class="max-w-7xl mx-auto p-8">
        <div class="flex items-start">


                <div class="flex-shrink-0 mr-8">
                    <img src="{{ asset("user.png") }}"  class="w-40 h-40 rounded-full border-4 border-gray-200 ">
                </div>

            <!-- Informations de l'utilisateur à droite -->
            <div class="space-y-4">
                <h1 class="text-3xl font-semibold mb-6">Détails de l'Utilisateur</h1>
                <p class="text-lg"><strong>Nom:</strong> {{ $user->name }}</p>
                <p class="text-lg"><strong>Rôle:</strong> {{ $user->roles->pluck('name')->implode(', ') }}</p>
                <p class="text-lg"><strong>Email:</strong> {{ $user->email }}</p>
            </div>
        </div>

        <div class="mt-8 flex space-x-4 justify-center">
            @canany('users.view')


            <a href="{{ route('user.index') }}" class="bg-gray-600 text-white px-6 py-3 rounded-lg shadow hover:bg-gray-700 transition">Retour à la liste</a>
            @endcanany
            @canany('users.edit')


            <a href="{{ route('user.edit', $user) }}" class="bg-yellow-600 text-white px-6 py-3 rounded-lg shadow hover:bg-yellow-700 transition" onclick="confirmCreate(event)"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                <path stroke-linecap="round" stroke-linejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0 3.181 3.183a8.25 8.25 0 0 0 13.803-3.7M4.031 9.865a8.25 8.25 0 0 1 13.803-3.7l3.181 3.182m0-4.991v4.99" />
              </svg>
              </a>

            @endcanany

        </div>
    </div>
    @endcanany

    <script src="{{ asset("assets/js/sweetalert2.min.js") }}"></script>

<script>

    function confirmCreate(event) {
        event.preventDefault();
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Vouslez vous mettre à jour  !",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, mettre à jour  !',
            cancelButtonText: 'Annuler'
        }).then((result) => {
            if (result.isConfirmed) {

                window.location.href = event.target.href;
            }
        });
    }






</script>
@endsection
