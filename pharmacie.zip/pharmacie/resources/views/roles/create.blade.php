@extends('layouts.base')

@section('title', 'Créer un rôle')

@section('content')
    <div class="container mx-auto py-8 px-4 sm:px-6 lg:px-8">
        <header class="mb-6">
            <h1 class="text-2xl font-bold text-gray-900 dark:text-white">Créer un rôle</h1>
        </header>

        @if ($errors->any())
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                <strong class="font-bold">Erreur!</strong>
                <ul class="list-disc pl-5 mt-2">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        @canany('roles.create')


        <form id="role-form" method="POST" action="{{ route('roles.store') }}" class="space-y-6">
            @csrf

            <div>
                <label for="name" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Nom du rôle</label>
                <input type="text" id="name" name="name"
                    class="mt-2 block w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                    required>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">Permissions</label>
                @foreach ($permissions as $permission)
                    <div class="flex items-center mt-2">
                        <input type="checkbox" id="permission_{{ $permission->id }}" name="permissions[]"
                            value="{{ $permission->id }}" class="mr-2 rounded border-gray-300 dark:border-gray-600 text-blue-600 focus:ring-blue-500">
                        <label for="permission_{{ $permission->id }}" class="text-gray-900 dark:text-gray-100">{{ $permission->name }}</label>
                    </div>
                @endforeach
            </div>

            <div class="flex items-center justify-between mt-6">
                <button type="submit" id="create-role-btn"
                    class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition-colors duration-300">
                    Enregistrer
                </button>
                @canany('roles.view')


                <a href="{{ route('roles.index') }}"
                    class="ml-4 bg-gray-600 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded-lg transition-colors duration-300">Annuler</a>
                    @endcanany
            </div>
        </form>
        @endcanany
    </div>

    <script src="{{ asset('assets/js/sweetalert2.min.js') }}"></script>
    <script>
        document.getElementById('role-form').addEventListener('submit', function(event) {
            event.preventDefault(); // Empêcher le formulaire de se soumettre immédiatement

            Swal.fire({
                title: 'Êtes-vous sûr?',
                text: "Vous êtes sur le point de créer un nouveau rôle.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Oui, créer!',
                cancelButtonText: 'Annuler'
            }).then((result) => {
                if (result.isConfirmed) {
                    this.submit(); // Soumettre le formulaire après confirmation
                }
            });
        });

        @if(session('success'))
            Swal.fire({
                icon: 'success',
                title: 'Succès',
                text: '{{ session('success') }}',
            });
        @endif

        @if(session('error'))
            Swal.fire({
                icon: 'error',
                title: 'Erreur',
                text: '{{ session('error') }}',
            });
        @endif
    </script>
@endsection
