@extends('layouts.base')
@section('title', 'Alertes de stock')
@section('content')
<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold text-center text-gray-800 mb-6">Alertes de Stock</h1>

    <div class="bg-white shadow-md rounded-lg overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-800 text-white">
                    <tr>
                        <th class="px-4 py-3 text-left text-sm font-semibold">Référence ID</th>
                        <th class="px-4 py-3 text-left text-sm font-semibold">Quantité</th>
                        <th class="px-4 py-3 text-left text-sm font-semibold">Seuil</th>
                        <th class="px-4 py-3 text-left text-sm font-semibold">Notification</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    @foreach($alertes as $alerte)
                    <tr>
                        <td class="px-4 py-4 whitespace-nowrap">{{ $alerte->references->nom_complet }}</td>
                        <td class="px-4 py-4 whitespace-nowrap">{{ $alerte->quantite }}</td>
                        <td class="px-4 py-4 whitespace-nowrap">{{ $alerte->quantite_seuil }}</td>
                        <td class="px-4 py-3 whitespace-nowrap text-gray-700">{{ $alerte->notification }}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>

    <div class="mt-8 text-center">
        <a href="{{ route('approvisionnements.create') }}" class="inline-block bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Faire L'approvisionnement</a>
    </div>
</div>
@endsection
