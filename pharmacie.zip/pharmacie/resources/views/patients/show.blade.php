@extends('layouts.base')

@section('title', 'Information d\'un patient')

@section('content')
@canany('patients.view')


<div class="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
    <div class="max-w-3xl mx-auto">
        <div class="bg-white shadow-md rounded-lg overflow-hidden">
            <div class="p-6 sm:p-8">
                <h2 class="text-3xl font-bold mb-6 text-center text-gray-800">Détails du patient</h2>

                <div class="space-y-4">
                    <div class="bg-gray-50 p-4 rounded-md">
                        <p class="text-gray-700"><span class="font-semibold">Nom :</span> {{ $patient->nom }}</p>
                    </div>
                    <div class="bg-gray-50 p-4 rounded-md">
                        <p class="text-gray-700"><span class="font-semibold">Prénom :</span> {{ $patient->prenom }}</p>
                    </div>
                    <div class="bg-gray-50 p-4 rounded-md">
                        <p class="text-gray-700"><span class="font-semibold">Contact :</span> {{ $patient->contact }}</p>
                    </div>
                </div>

                <div class="mt-8 flex flex-wrap justify-end space-x-2 space-y-2 sm:space-y-0">
                    @canany('patients.view')




                    <a href="{{ route('patients.index') }}"
                        class="bg-gray-500 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded transition duration-300 ease-in-out">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M6 18 18 6M6 6l12 12" />
                          </svg>

                    </a>
                    @endcanany
                    @canany('patients.edit')




                    <a href="{{ route('patients.edit', $patient) }}"
                        class="bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-2 px-4 rounded transition duration-300 ease-in-out">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0 3.181 3.183a8.25 8.25 0 0 0 13.803-3.7M4.031 9.865a8.25 8.25 0 0 1 13.803-3.7l3.181 3.182m0-4.991v4.99" />
                          </svg>

                    </a>
                    @endcanany



                    <button type="button" onclick="confirmeSupprimer()"
                        class="bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-4 rounded transition duration-300 ease-in-out">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                            <path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
                          </svg>

                    </button>

                </div>
            </div>
        </div>
    </div>
</div>
@endcanany
@canany('pateints.delete')


<form id="deleteForm" action="{{ route('patients.destroy', $patient) }}" method="POST" class="hidden">
    @csrf
    @method('DELETE')
</form>
@endcanany
<script src="{{ asset('assets/js/sweetalert2.min.js') }}"></script>
<script>
    function confirmeSupprimer() {
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Vous ne pourrez pas revenir en arrière !",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, supprimer !',
            cancelButtonText: 'Annuler'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('deleteForm').submit();
            }
        });
    }
</script>
@endsection
