@extends('layouts.base')

@section('title', 'Créer Une nouvelle vente')

@section('content')

<div class="container mx-auto mt-8 px-4">
    @canany('ventes.create')

    <form id="venteForm" action="{{ route('ventes.store') }}" method="POST">
        @csrf

        <div class="mb-6">
            <label for="patient_id" class="block text-gray-700">Patient (optionnel)</label>
            <select name="patient_id" id="patient_id" class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                <option value="">Sélectionnez un patient</option>
                @foreach($patients as $patient)
                    <option value="{{ $patient->id }}">{{ $patient->nom }} {{ $patient->prenom }}</option>
                @endforeach
            </select>
        </div>
        {{-- {{ $errors }} --}}
        <div class="bg-white p-6 rounded-md mb-4 shadow-lg">
            <h2 class="text-xl font-semibold mb-4">Ajouter un produit à la vente</h2>
            <div class="flex flex-col md:flex-row gap-4">
                <div class="flex-1">
                    <label for="produit" class="block text-sm font-medium text-gray-700">Produit</label>
                        <select id="produit" class="w-full px-2 py-0.5 border border-gray-300 rounded-lg">
                            @foreach($produits as $stockProduit)
                                <option value="{{ $stockProduit->reference_id }}"
                                        data-prix="{{ $stockProduit->prix }}"
                                        data-lot="{{ $stockProduit->lot }}"
                                        data-quantite="{{ $stockProduit->quantite }}">
                                    {{ $stockProduit->references->nom_complet }}
                                </option>
                            @endforeach
                        </select>
                </div>
                <div class="flex-1">
                    <label for="quantite" class="block text-sm font-medium text-gray-700">Quantité</label>
                    <input type="number" id="quantite" class="w-full px-2 py-0.5 border border-gray-300 rounded-lg">
                </div>

                <div class="flex items-end">
                    <button id="ajouterLigne" type="button" class="bg-green-500 text-white px-2 py-0.5 rounded-md w-full md:w-auto">
                        +
                    </button>
                </div>
            </div>
        </div>

        <div class="bg-white p-6 rounded-md shadow-md">
            <h2 class="text-xl font-semibold mb-4">Liste des produits</h2>
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white">
                    <thead>
                        <tr>
                            <th class="w-1/3 text-left py-3 px-4">Produit</th>
                            <th class="w-1/6 text-left py-3 px-4">Prix</th>
                            <th class="w-1/6 text-left py-3 px-4">Quantité</th>
                            <th class="w-1/6 text-left py-3 px-4">Total</th>
                            <th class="w-1/6 text-left py-3 px-4">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="ligneVenteBody">
                        <!-- Lignes ajoutées dynamiquement -->
                    </tbody>
                </table>
            </div>
        </div>

        <div class="mt-6">
            <button id="soumettreVente" type="button" class="bg-green-500 text-white px-4 py-2 rounded-md w-full md:w-auto">
                Valider la vente
            </button>
        </div>
        <input type="hidden" id="productOptions" value="{{ $produits->toJson() }}">
    </form>
    @endcanany
</div>


@vite('resources/js/ventes.js', ['defer' => true])

<script>
    $(document).ready(function() {
        $('#produit').select2({
            placeholder: "Sélectionnez une référence",
            allowClear: true,
            width: '100%',
            minimumResultsForSearch: 0
        });
    });

    $(document).ready(function() {
        $('#patient_id').select2({
            placeholder: "Sélectionnez un Patient",
            allowClear: true,
            width: '100%',
            minimumResultsForSearch: 0
        });
    });
</script>

<script src="{{ asset('assets/js/sweetalert2.min.js') }}"></script>
@endsection
