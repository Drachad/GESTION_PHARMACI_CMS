@extends('layouts.base')

@section('title', 'Modification Référence')

@section('content')
<div class="flex justify-center items-center min-h-screen bg-gray-100">
    <div class="form-container bg-white rounded-lg shadow-lg p-8 max-w-lg w-full relative">
        <!-- Bouton Retour sous forme de croix -->
        @canany('reference.view')
        <a href="{{ route('references.index') }}" class="close-button text-red-500 hover:text-red-700 text-2xl absolute top-3 right-3 transition duration-200 ease-in-out" onclick="confirmUpdate(event)">&times;</a>
        @endcanany

        <h2 class="text-3xl font-bold text-green-600 mb-6 text-center">Modifier la Référence</h2>
        @if ($errors->any())
            <div class="alert alert-danger bg-red-100 border border-red-300 text-red-700 rounded-lg p-4 mb-4">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        @canany('reference.edit')
        <form id="referenceupdate" action="{{ route('references.update', $reference->id) }}" method="POST" class="space-y-5">
            @csrf
            @method('PUT')
            <input type="hidden" name="redirect_to" value="{{ url()->previous() }}">

            <div class="form-group">
                <label for="nom" class="block text-gray-700 font-semibold mb-1">Nom</label>
                <input type="text" id="nom" name="nom" value="{{ old('nom', $reference->nom) }}" placeholder="Nom de la référence" required class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 transition duration-200 ease-in-out text-base shadow-sm">
            </div>

            <div class="form-group">
                <label for="produit" class="block text-gray-700 font-semibold mb-1">Produit</label>
                <div class="flex space-x-4">
                    <select id="produit_id" name="produit_id" class="form-control border-green-300 rounded-lg p-2 w-full">
                        <option value="">Sélectionner un produit</option>
                        @foreach($produits as $produit)
                            <option value="{{ $produit->id }}" {{ (old('produit_id') ?? $reference->produit_id) == $produit->id ? 'selected' : '' }}>
                                {{ $produit->nom }}
                            </option>
                        @endforeach
                    </select>
                    @canany('produits.create')
                    <a href="{{ route('produits.create') }}" class="text-white bg-blue-500 hover:bg-blue-600 font-bold py-2 px-4 rounded-lg transition duration-300 ease-in-out text-center shadow-sm" onclick="confirmcreate(event)">+</a>
                    @endcanany
                </div>
                @canany('produits.create')
                <p class="text-sm text-gray-500 mt-2">
                    Pas de produit correspondant ? <a href="{{ route('produits.create') }}" class="text-green-500 hover:text-green-700 font-medium transition duration-300 ease-in-out" onclick="confirmcreate(event)">Créer un nouveau produit</a>.
                </p>
                @endcanany
            </div>

            <div class="form-group">
                <label for="quantite_seuil" class="block text-gray-700 font-semibold mb-1">Quantité Seuil</label>
                <input type="number" id="quantite_seuil" name="quantite_seuil" value="{{ old('quantite_seuil', $reference->alerte->quantite_seuil) }}" placeholder="Quantité seuil" required min="0" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 transition duration-200 ease-in-out text-base shadow-sm">
            </div>

            <button type="button" id="submitButton" class="w-full bg-green-500 text-white font-semibold py-3 rounded-lg hover:bg-green-600 transition duration-200 ease-in-out text-base">
                Modifier Référence
            </button>
        </form>
        @endcanany
    </div>
</div>

<script src="{{ asset('assets/js/sweetalert2.min.js') }}"></script>
<script>
    $(document).ready(function() {
        $('#produit_id').select2({
            placeholder: "Sélectionnez un produit",
            allowClear: true,
            width: '100%',
            minimumResultsForSearch: 0,
            language: {
                noResults: function() {
                    // Retourner le lien HTML pour la création d'un nouvel article
                    return $('<span>').append(
                        $('<a>', {
                            href: '{{ route('produits.create') }}',
                            text: 'produit n\'est pas trouvé créer un nouveau',
                            class: 'text-blue-500 hover:underline',
                            target: '_blank'
                        })
                    );
                }
            }
        });
    });
</script>
<script>
    document.getElementById('submitButton').addEventListener('click', function(event) {
        event.preventDefault();
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Vous allez enregistrer cette référence !",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, enregistrer !',
            cancelButtonText: 'Annuler'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('referenceupdate').submit();
            }
        });
    });

    function confirmUpdate(event) {
        event.preventDefault();
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Voulez-vous Annuler !",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, Annuler !',
            cancelButtonText: 'Non '
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = event.target.href;
            }
        });
    }

    function confirmcreate(event) {
        event.preventDefault();
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Voulez-vous Créer !",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, créer !',
            cancelButtonText: 'Non '
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = event.target.href;
            }
        });
    }
</script>

@endsection
