<?php

use App\Http\Controllers\AlerteStockController;
use App\Http\Controllers\PatientController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ProduitController;
use App\Http\Controllers\CategorieController;
use App\Http\Controllers\ExpiredProductController;
use App\Http\Controllers\FournisseurController;
use App\Http\Controllers\ReferenceController;
use App\Http\Controllers\InventaireController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\VenteController;
use App\Http\Controllers\ApprovisionnementController;
use App\Http\Controllers\StockProduitController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RoleController;

Route::get('/', function () {
    return view('welcome');
})->name('welcome');
Route::get('/manuel', function () {
    return view('manuel');
})->name('manuel');
Route::middleware('auth')->group(function () {
Route::resource('stockProduits', StockProduitController::class);

Route::get('/alertes', [AlerteStockController::class, 'index'])->name('alertes.index');
    Route::resource('produits', ProduitController::class);
    Route::get('/produits/{id}/seuil', [StockProduitController::class, 'getSeuil'])->name('produits.seuil');

    Route::resource('categories', CategorieController::class);
    Route::resource('fournisseurs', FournisseurController::class);


    Route::middleware(['can:expired-products.view'])->group(function () {
        Route::get('/expired-products', [ExpiredProductController::class, 'index'])->name('expired.products.index');
    });

    Route::middleware(['can:expired-products.delete'])->group(function () {
        Route::delete('/expired-products/{id}', [ExpiredProductController::class, 'destroy'])->name('expired.products.destroy');
    });

    Route::resource('patients', PatientController::class);
    Route::resource('roles', RoleController::class);
    Route::resource('ventes', VenteController::class);
    Route::get("/ventes/{vente}/facture", [VenteController::class, 'generer_facture'])->name('generer_facture');
    Route::get('/inventaire', [InventaireController::class,   'index'])->name('inventaire.index');
    Route::post('/inventaire/action', [InventaireController::class,   'inventaire'])->name('inventaire.controle');
    Route::post('/genererInventairePDF', [InventaireController::class, 'genererInventairePDF'])->name('genererInventairePDF');
    Route::get('/dashboard', function () {
        return view('dashboard');
    })->middleware(['auth'])->name('dashboard');
    Route::resource('user', UserController::class);
    // Route pour afficher les produits expirés
    Route::resource('approvisionnements', ApprovisionnementController::class);
    Route::resource('references', ReferenceController::class);
    Route::middleware(['can:profile.view'])->group(function () {
        Route::get('/profile', [ProfileController::class, 'show'])->name('profile.show');
        Route::get('/profile/edit', [ProfileController::class, 'edit'])->name('profile.edit');
        Route::get('/profile/change-password', [ProfileController::class, 'showChangePasswordForm'])->name('profile.change-password');
        Route::get('/profile/delete-account', [ProfileController::class, 'showDeleteAccountForm'])->name('profile.delete-account');
        Route::get('/profile/action', [ProfileController::class, 'showActions'])->name('profile.action');
    });

    Route::middleware(['can:profile.edit'])->group(function () {
        Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    });

    Route::middleware(['can:profile.delete'])->group(function () {
        Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    });
});



// // Routes protégées par des permissions spécifiques
// Route::middleware(['auth', 'can:patients.view'])->group(function () {
//     Route::get('/patients', [PatientController::class, 'index'])->name('patients.index');
// });
// Route::middleware(['auth', 'can:patients.create'])->group(function () {
//     Route::get('/patients/create', [PatientController::class, 'create'])->name('patients.create');
//     Route::post('/patients', [PatientController::class, 'store'])->name('patients.store');
// });
// Route::middleware(['auth', 'can:patients.edit'])->group(function () {
//     Route::get('/patients/{patient}/edit', [PatientController::class, 'edit'])->name('patients.edit');
//     Route::put('/patients/{patient}', [PatientController::class, 'update'])->name('patients.update');
// });
// Route::middleware(['auth', 'can:patients.delete'])->group(function () {
//     Route::delete('/patients/{patient}', [PatientController::class, 'destroy'])->name('patients.destroy');
// });
// Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
// Route::get('/profile/edit', [ProfileController::class, 'edit'])->name('profile.edit');
// Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
// Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
// Route::get('/profile', [ProfileController::class, 'show'])->name('profile.show');
// Route::get('/profile/action', [ProfileController::class, 'showActions'])->name('profile.action');
// Route::get('/profile/change-password', [ProfileController::class, 'showChangePasswordForm'])->name('profile.change-password');
// Route::get('/profile/delete-account', [ProfileController::class, 'showDeleteAccountForm'])->name('profile.delete-account');
// Route::get('/roles/actions', function () {
//     return view('roles.role-actions');
// })->name('roles.actions');








require __DIR__ . '/auth.php';
